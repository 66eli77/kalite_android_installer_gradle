"""
environment.py specific to the this app
"""
from kalite.testing.base_environment import *
