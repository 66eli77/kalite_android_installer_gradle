require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"zone_management":[function(require,module,exports){
var $ = require("base/jQuery");
var force_sync = require("utils/force_sync");
var api = require("utils/api");
var messages = require("utils/messages");
var sprintf = require("sprintf-js").sprintf;

$(function () {
    $("#force-sync").click(function(ev){
        ev.preventDefault();
        force_sync(window.ZONE_ID, window.DEVICE_ID);
    });

    $(".facility-delete-link").click(function(event) {
        var facilityName = $.trim($(this).parent().prevAll().find('a.facility-name').text());
        var confirmDelete = prompt(sprintf(gettext("Are you sure you want to delete '%s'? You will lose all associated learner, group, and coach accounts. If you are sure, type the name of the facility into the box below and press OK."), facilityName));
        
        if (confirmDelete === null) {
            return false; // cancel
        }
        else if (confirmDelete === facilityName) {
            var delete_facility_url = event.target.getAttribute("value");
            var data = {facility_id: null};
            // MUST: provide the data argument to make this a POST request
            api.doRequest(delete_facility_url, data)
                .success(function() {
                    window.location.reload();
                });
        } else {
            messages.show_message("warning", gettext("The facility has not been deleted. Did you spell the facility name correctly?"));
        }
    });
});

},{"base/jQuery":45,"sprintf-js":581,"utils/api":124,"utils/force_sync":27,"utils/messages":128}],27:[function(require,module,exports){
var api = require("utils/api");
var sprintf = require("sprintf-js").sprintf;
var messages = require("utils/messages");

module.exports = function force_sync(zone_id, device_id) {
    // Simple function that calls the API endpoint to force a data sync,
    //   then shows a message for success/failure
    api.doRequest(window.Urls.api_force_sync())
        .success(function() {
            var msg = gettext("Successfully launched data syncing job.") + " ";
            msg += sprintf(gettext("After syncing completes, visit the <a href='%(devman_url)s'>device management page</a> to view results."), {
                devman_url: Urls.device_management(zone_id, device_id)
            });
            messages.show_message("success", msg);
        });
};
},{"sprintf-js":581,"utils/api":124,"utils/messages":128}]},{},["zone_management"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvY29udHJvbF9wYW5lbC9zdGF0aWMvanMvY29udHJvbF9wYW5lbC9idW5kbGVfbW9kdWxlcy96b25lX21hbmFnZW1lbnQuanMiLCJrYWxpdGUvY29udHJvbF9wYW5lbC9zdGF0aWMvanMvY29udHJvbF9wYW5lbC91dGlscy9mb3JjZV9zeW5jLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2hDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgJCA9IHJlcXVpcmUoXCJiYXNlL2pRdWVyeVwiKTtcbnZhciBmb3JjZV9zeW5jID0gcmVxdWlyZShcInV0aWxzL2ZvcmNlX3N5bmNcIik7XG52YXIgYXBpID0gcmVxdWlyZShcInV0aWxzL2FwaVwiKTtcbnZhciBtZXNzYWdlcyA9IHJlcXVpcmUoXCJ1dGlscy9tZXNzYWdlc1wiKTtcbnZhciBzcHJpbnRmID0gcmVxdWlyZShcInNwcmludGYtanNcIikuc3ByaW50ZjtcblxuJChmdW5jdGlvbiAoKSB7XG4gICAgJChcIiNmb3JjZS1zeW5jXCIpLmNsaWNrKGZ1bmN0aW9uKGV2KXtcbiAgICAgICAgZXYucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgZm9yY2Vfc3luYyh3aW5kb3cuWk9ORV9JRCwgd2luZG93LkRFVklDRV9JRCk7XG4gICAgfSk7XG5cbiAgICAkKFwiLmZhY2lsaXR5LWRlbGV0ZS1saW5rXCIpLmNsaWNrKGZ1bmN0aW9uKGV2ZW50KSB7XG4gICAgICAgIHZhciBmYWNpbGl0eU5hbWUgPSAkLnRyaW0oJCh0aGlzKS5wYXJlbnQoKS5wcmV2QWxsKCkuZmluZCgnYS5mYWNpbGl0eS1uYW1lJykudGV4dCgpKTtcbiAgICAgICAgdmFyIGNvbmZpcm1EZWxldGUgPSBwcm9tcHQoc3ByaW50ZihnZXR0ZXh0KFwiQXJlIHlvdSBzdXJlIHlvdSB3YW50IHRvIGRlbGV0ZSAnJXMnPyBZb3Ugd2lsbCBsb3NlIGFsbCBhc3NvY2lhdGVkIGxlYXJuZXIsIGdyb3VwLCBhbmQgY29hY2ggYWNjb3VudHMuIElmIHlvdSBhcmUgc3VyZSwgdHlwZSB0aGUgbmFtZSBvZiB0aGUgZmFjaWxpdHkgaW50byB0aGUgYm94IGJlbG93IGFuZCBwcmVzcyBPSy5cIiksIGZhY2lsaXR5TmFtZSkpO1xuICAgICAgICBcbiAgICAgICAgaWYgKGNvbmZpcm1EZWxldGUgPT09IG51bGwpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTsgLy8gY2FuY2VsXG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoY29uZmlybURlbGV0ZSA9PT0gZmFjaWxpdHlOYW1lKSB7XG4gICAgICAgICAgICB2YXIgZGVsZXRlX2ZhY2lsaXR5X3VybCA9IGV2ZW50LnRhcmdldC5nZXRBdHRyaWJ1dGUoXCJ2YWx1ZVwiKTtcbiAgICAgICAgICAgIHZhciBkYXRhID0ge2ZhY2lsaXR5X2lkOiBudWxsfTtcbiAgICAgICAgICAgIC8vIE1VU1Q6IHByb3ZpZGUgdGhlIGRhdGEgYXJndW1lbnQgdG8gbWFrZSB0aGlzIGEgUE9TVCByZXF1ZXN0XG4gICAgICAgICAgICBhcGkuZG9SZXF1ZXN0KGRlbGV0ZV9mYWNpbGl0eV91cmwsIGRhdGEpXG4gICAgICAgICAgICAgICAgLnN1Y2Nlc3MoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgICAgIHdpbmRvdy5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIG1lc3NhZ2VzLnNob3dfbWVzc2FnZShcIndhcm5pbmdcIiwgZ2V0dGV4dChcIlRoZSBmYWNpbGl0eSBoYXMgbm90IGJlZW4gZGVsZXRlZC4gRGlkIHlvdSBzcGVsbCB0aGUgZmFjaWxpdHkgbmFtZSBjb3JyZWN0bHk/XCIpKTtcbiAgICAgICAgfVxuICAgIH0pO1xufSk7XG4iLCJ2YXIgYXBpID0gcmVxdWlyZShcInV0aWxzL2FwaVwiKTtcbnZhciBzcHJpbnRmID0gcmVxdWlyZShcInNwcmludGYtanNcIikuc3ByaW50ZjtcbnZhciBtZXNzYWdlcyA9IHJlcXVpcmUoXCJ1dGlscy9tZXNzYWdlc1wiKTtcblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBmb3JjZV9zeW5jKHpvbmVfaWQsIGRldmljZV9pZCkge1xuICAgIC8vIFNpbXBsZSBmdW5jdGlvbiB0aGF0IGNhbGxzIHRoZSBBUEkgZW5kcG9pbnQgdG8gZm9yY2UgYSBkYXRhIHN5bmMsXG4gICAgLy8gICB0aGVuIHNob3dzIGEgbWVzc2FnZSBmb3Igc3VjY2Vzcy9mYWlsdXJlXG4gICAgYXBpLmRvUmVxdWVzdCh3aW5kb3cuVXJscy5hcGlfZm9yY2Vfc3luYygpKVxuICAgICAgICAuc3VjY2VzcyhmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHZhciBtc2cgPSBnZXR0ZXh0KFwiU3VjY2Vzc2Z1bGx5IGxhdW5jaGVkIGRhdGEgc3luY2luZyBqb2IuXCIpICsgXCIgXCI7XG4gICAgICAgICAgICBtc2cgKz0gc3ByaW50ZihnZXR0ZXh0KFwiQWZ0ZXIgc3luY2luZyBjb21wbGV0ZXMsIHZpc2l0IHRoZSA8YSBocmVmPSclKGRldm1hbl91cmwpcyc+ZGV2aWNlIG1hbmFnZW1lbnQgcGFnZTwvYT4gdG8gdmlldyByZXN1bHRzLlwiKSwge1xuICAgICAgICAgICAgICAgIGRldm1hbl91cmw6IFVybHMuZGV2aWNlX21hbmFnZW1lbnQoem9uZV9pZCwgZGV2aWNlX2lkKVxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBtZXNzYWdlcy5zaG93X21lc3NhZ2UoXCJzdWNjZXNzXCIsIG1zZyk7XG4gICAgICAgIH0pO1xufTsiXX0=
