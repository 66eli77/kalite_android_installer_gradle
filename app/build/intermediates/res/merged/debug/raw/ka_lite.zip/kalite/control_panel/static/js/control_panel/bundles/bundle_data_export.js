require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"data_export":[function(require,module,exports){
var $ = require("base/jQuery");
var DataExportView = require("data_export/views").DataExportView;
var DataExportStateModel = require("data_export/models").DataExportStateModel;

module.exports = {
	$: $,
	DataExportView: DataExportView,
	DataExportStateModel: DataExportStateModel
};
},{"base/jQuery":45,"data_export/models":25,"data_export/views":26}],26:[function(require,module,exports){
var Handlebars = require("base/handlebars");
var Backbone = require("base/backbone");
var $ = require("base/jQuery");

var Models = require("./models");

// Views
var DataExportView = Backbone.View.extend({
    // the containing view
    template: require('./hbtemplates/data-export-container.handlebars'),

    initialize: function(options) {

        this.options = options || {};

        this.zone_select_view = new ZoneSelectView({
            org_id: options.org_id,
            model: this.model
        });

        this.facility_select_view  = new FacilitySelectView({
            model: this.model
        });

        this.group_select_view = new GroupSelectView({
            model: this.model
        });

        this.render();
    },

    events: {
        "click #export-button": "export_data",
        "change #resource-id": "resource_changed"
    },

    render: function() {
        // render container
        this.$el.html(this.template(this.model.attributes));

        // append zone, facility & group select views.
        this.$('#student-select-container').append(this.zone_select_view.$el);
        this.$('#student-select-container').append(this.facility_select_view.$el);
        this.$('#student-select-container').append(this.group_select_view.$el);
    },

    resource_changed: function() {
        this.model.set({
            resource_id: this.$('#resource-id').val()
        });
    },

    resource_endpoint: function() {
        // Return the API url endpoint for the current resource id
        var resource_id = this.model.get("resource_id");
        switch  (resource_id) {
            case "facility_user":
                return FACILITY_USER_CSV_URL;
            case "test_log":
                return TEST_LOG_CSV_URL;
            case "attempt_log":
                return ATTEMPT_LOG_CSV_URL;
            case "exercise_log":
                return EXERCISE_LOG_CSV_URL;
            case "device_log":
                return DEVICE_LOG_CSV_URL;
            case "store_log":
                return STORE_LOG_CSV_URL;
            case "content_rating":
                return CONTENT_RATING_CSV_URL;
        }
    },

    export_data: function(ev) {
        ev.preventDefault();

        // Update export link based on currently selected paramters
        var zone_id = this.model.get("zone_id");
        var facility_id = this.model.get("facility_id");
        var group_id = this.model.get("group_id");
        var resource_endpoint = this.resource_endpoint();

        // If no zone_id, all is selected, so compile a comma seperated string
        // of zone ids to pass to endpoint
        var zone_ids = "";
        if (zone_id===undefined || zone_id==="") {
            zone_ids = _.map(this.zone_select_view.zone_list.models, function(zone) { return zone.get("id"); }).join();
        }

        var export_params = "?" + $.param({
            group_id: group_id,
            facility_id: facility_id,
            zone_id: zone_id,
            zone_ids: zone_ids,
            format:"csv",
            limit:0
        });

        var export_data_url = this.resource_endpoint() + export_params;
        window.location = export_data_url;
    }
});


var ZoneSelectView = Backbone.View.extend({

    template: require('./hbtemplates/zone-select.handlebars'),

    initialize: function() {
        // Create collections
        this.zone_list = new Models.ZoneCollection();

        // on central, this is a dynamic view
        // on distributed, this is a placeholder view,
        if (this.model.get("is_central")) {
            // Re-render self when fetch returns or model state changes
            this.listenTo(this.zone_list, 'sync', this.render);

            // Fetch collection by org_id
            this.zone_list.fetch({
                data: $.param({
                    "org_id": this.options.org_id,
                    "limit": 0
                })
            });
        }

        this.render();
    },

    render: function() {
        var rendered_html = this.template({
            zones: this.zone_list.toJSON(),
            selection: this.model.get("zone_id")
        });

        if (this.model.get("is_central")) {
            this.$el.html(rendered_html);
        } else {
            this.$el.html(rendered_html).hide();
        }
    },

    events: {
        "change": "zone_changed"
    },

    zone_changed: function(ev) {
        // Update state model
        var zone_id = this.$("select").val();
        this.model.set({
            facility_id: undefined,
            group_id: undefined,
            zone_id: zone_id
        });
    }
});

var FacilitySelectView = Backbone.View.extend({

    template: require('./hbtemplates/facility-select.handlebars'),

    initialize: function() {
        // Create collections
        this.facility_list = new Models.FacilityCollection();

        // Re-render self when the fetch returns or state model changes
        this.listenTo(this.facility_list, 'sync', this.render);
        this.listenTo(this.facility_list, 'reset', this.render);
        this.listenTo(this.model, 'change:resource_id', this.render);

        // on central, facilities depend on the zone selected
        // on distributed, zone is fixed
        if (this.model.get("is_central")) {
            // Listen for any changes on the zone model, when it happens, re-fetch self
            this.listenTo(this.model, 'change:zone_id', this.fetch_by_zone);
        }

        // Fetch collection, by fixed zone
        this.fetch_by_zone();

        // Render
        this.render();
    },

    render: function() {
        var template_context;

        if (this.model.get("facility_id") !== "") {
            template_context = {
                facilities: this.facility_list.toJSON(),
                selection: this.model.get("facility_id"),
                is_disabled: true
            };
        } else {
            template_context = {
                facilities: this.facility_list.toJSON(),
                selection: this.model.get("facility_id"),
                // Facility select is enabled only if zone_id has been set
                is_disabled: this.is_disabled()
            };
        }

        this.$el.html(this.template(template_context));

        return this;
    },

    is_disabled: function() {
        // Helper function to quickly check whether the facility select input
        // should be enabled or disabled based on conditions that matter to it.
        if (this.model.get("resource_id") === "device_log") {
            return true;
        }
        return ((this.model.get("zone_id") === undefined || this.model.get("zone_id") === "") && this.model.get("is_central"));
    },

    render_waiting: function() {
        var template_context = {
            is_disabled: true,
            loading: true
        };

        this.$el.html(this.template(template_context));
    },

    events: {
        "change": "facility_changed"
    },

    facility_changed: function(ev) {
        // Update state model
        var facility_id = this.$("select").val();

        this.model.set({
            group_id: undefined,
            facility_id: facility_id
        });
    },

    fetch_by_zone: function() {
        // First disable the select
        if (this.model.get("is_central")) {
            var zone_id = this.model.get("zone_id");

            // only fetch if a zone ID has been set
            if (zone_id) {
                this.render_waiting();
                this.facility_list.fetch({
                    data: $.param({
                        "zone_id": zone_id,
                        "limit": 0
                    })
                });
            } else {
                this.facility_list.reset();
            }
        } else {
            this.render_waiting();
            this.facility_list.fetch();
        }
    }
});

var GroupSelectView = Backbone.View.extend({

    template: require('./hbtemplates/group-select.handlebars'),

    initialize: function() {
        // Create collections
        this.group_list = new Models.GroupCollection();

        this.fetch_by_facility();
        // Re-render self when the fetch returns or state model changes
        this.listenTo(this.group_list, 'sync', this.render);
        this.listenTo(this.group_list, 'reset', this.render);
        this.listenTo(this.model, 'change:resource_id', this.render);

        // on central, groups depend on facilities which depend on the zone selected
        // on distributed, zone is fixed, so groups just depend on facilities
        // Regardless, wait for any changes on the facility model, and then re-fetch self
        this.listenTo(this.model, 'change:facility_id', this.fetch_by_facility);

        // Render
        this.render();
    },

    render: function() {
        var template_context = {
            groups: this.group_list.toJSON(),
            selection: this.model.get("group_id"),
            // Group select is enabled only if facility_id has been set
            is_disabled: this.is_disabled()
        };

        this.$el.html(this.template(template_context));

        return this;
    },

    is_disabled: function() {
        if (this.model.get("resource_id") === "device_log"){
            return true;
        }
        return !this.model.get("facility_id");
    },

    render_waiting: function() {
        var template_context = {
            is_disabled: true,
            loading: true
        };

        this.$el.html(this.template(template_context));
    },

    events: {
        "change": "group_changed"
    },

    group_changed: function(ev) {
        var group_id = this.$("select").val();
        this.model.set({ group_id: group_id });
    },

    fetch_by_facility: function() {
        var facility_id = this.model.get("facility_id");
        // only fetch if facility ID has been set
        if (facility_id) {
            this.render_waiting();
            this.group_list.fetch({
                data: $.param({
                    "facility_id": facility_id,
                    "limit": 0
                })
            });
        } else {
            this.group_list.reset();
        }
    }
});

module.exports = {
    DataExportView: DataExportView,
    ZoneSelectView: ZoneSelectView,
    FacilitySelectView: FacilitySelectView,
    GroupSelectView: GroupSelectView
};

},{"./hbtemplates/data-export-container.handlebars":21,"./hbtemplates/facility-select.handlebars":22,"./hbtemplates/group-select.handlebars":23,"./hbtemplates/zone-select.handlebars":24,"./models":25,"base/backbone":42,"base/handlebars":44,"base/jQuery":45}],25:[function(require,module,exports){
// Handles the data export functionality of the control panel
// TODO-blocker(dylanjbarth) 0.13: limit requests and handle pagination
var Backbone = require("base/backbone");


// Models
var ZoneModel = Backbone.Model.extend();

var FacilityModel = Backbone.Model.extend();

var GroupModel = Backbone.Model.extend();

var DataExportStateModel = Backbone.Model.extend();

// Collections
var ZoneCollection = Backbone.Collection.extend({
    model: ZoneModel,
    url: ALL_ZONES_URL
});

var FacilityCollection = Backbone.Collection.extend({
    model: FacilityModel,
    url: ALL_FACILITIES_URL
});

var GroupCollection = Backbone.Collection.extend({
    model: GroupModel,
    url: ALL_GROUPS_URL
});

module.exports = {
	ZoneModel: ZoneModel,
	FacilityModel: FacilityModel,
	GroupModel: GroupModel,
	DataExportStateModel: DataExportStateModel,
	ZoneCollection: ZoneCollection,
	FacilityCollection: FacilityCollection,
	GroupCollection: GroupCollection,
};

},{"base/backbone":42}],24:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data,depth1) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" ";
  stack1 = (helper = helpers.ifcond || (depth1 && depth1.ifcond),options={hash:{},inverse:self.noop,fn:self.program(2, program2, data),data:data},helper ? helper.call(depth0, (depth1 && depth1.selection), "===", (depth0 && depth0.id), options) : helperMissing.call(depth0, "ifcond", (depth1 && depth1.selection), "===", (depth0 && depth0.id), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n            ";
  return buffer;
  }
function program2(depth0,data) {
  
  
  return "selected";
  }

  buffer += "<div class=\"form-group\">\n    <label for=\"zone-name\" class=\"col-xs-2\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Zone", options) : helperMissing.call(depth0, "_", "Zone", options)))
    + "</label>\n    <div class=\"col-xs-8\">\n        <select class=\"form-control\" id=\"zone-name\">\n            <option value=\"\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "All", options) : helperMissing.call(depth0, "_", "All", options)))
    + "</option>\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.zones), {hash:{},inverse:self.noop,fn:self.programWithDepth(1, program1, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </select>\n    </div>\n</div>";
  return buffer;
  });

},{"hbsfy/runtime":354}],23:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  
  return "\n            <img src=\"/static/images/loading.gif\" class=\"float-center float-over-select loading\"/>\n        ";
  }

function program3(depth0,data) {
  
  
  return "loading-transparency";
  }

function program5(depth0,data) {
  
  
  return "disabled";
  }

function program7(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <option value=\"\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "All", options) : helperMissing.call(depth0, "_", "All", options)))
    + "</option>\n                ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.groups), {hash:{},inverse:self.noop,fn:self.programWithDepth(8, program8, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            ";
  return buffer;
  }
function program8(depth0,data,depth1) {
  
  var buffer = "", stack1, helper, options;
  buffer += escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "s", options) : helperMissing.call(depth0, "_", "s", options)))
    + "\n                    <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" ";
  stack1 = (helper = helpers.ifcond || (depth1 && depth1.ifcond),options={hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data},helper ? helper.call(depth0, (depth1 && depth1.selection), "===", (depth0 && depth0.id), options) : helperMissing.call(depth0, "ifcond", (depth1 && depth1.selection), "===", (depth0 && depth0.id), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n                ";
  return buffer;
  }
function program9(depth0,data) {
  
  
  return "selected";
  }

function program11(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                <option disabled>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "All", options) : helperMissing.call(depth0, "_", "All", options)))
    + "</option>\n            ";
  return buffer;
  }

  buffer += "<div class=\"form-group\">\n    <label for=\"group-name\" class=\"col-xs-2\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Group", options) : helperMissing.call(depth0, "_", "Group", options)))
    + "</label>\n    <div class=\"col-xs-8\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.loading), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        <select class=\"form-control ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.loading), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" id=\"group-name\" ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.is_disabled), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">\n            ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.groups), {hash:{},inverse:self.program(11, program11, data),fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </select>\n    </div>\n</div>";
  return buffer;
  });

},{"hbsfy/runtime":354}],22:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, self=this, helperMissing=helpers.helperMissing;

function program1(depth0,data) {
  
  
  return "\n            <img src=\"/static/images/loading.gif\" class=\"float-center float-over-select loading\"/>\n        ";
  }

function program3(depth0,data) {
  
  
  return "loading-transparency";
  }

function program5(depth0,data) {
  
  
  return "disabled";
  }

function program7(depth0,data,depth1) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <option value=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" ";
  stack1 = (helper = helpers.ifcond || (depth1 && depth1.ifcond),options={hash:{},inverse:self.noop,fn:self.program(8, program8, data),data:data},helper ? helper.call(depth0, (depth1 && depth1.selection), "===", (depth0 && depth0.id), options) : helperMissing.call(depth0, "ifcond", (depth1 && depth1.selection), "===", (depth0 && depth0.id), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">";
  if (helper = helpers.name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</option>\n            ";
  return buffer;
  }
function program8(depth0,data) {
  
  
  return "selected";
  }

  buffer += "<div class=\"form-group\">\n    <label for=\"facility-name\" class=\"col-xs-2\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Facility", options) : helperMissing.call(depth0, "_", "Facility", options)))
    + "</label>\n    <div class=\"col-xs-8\">\n        ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.loading), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        <select class=\"form-control ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.loading), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" id=\"facility-name\" ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.is_disabled), {hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">\n            <option value=\"\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "All", options) : helperMissing.call(depth0, "_", "All", options)))
    + "</option>\n            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.facilities), {hash:{},inverse:self.noop,fn:self.programWithDepth(7, program7, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n        </select>\n    </div>\n</div>";
  return buffer;
  });

},{"hbsfy/runtime":354}],21:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, self=this;

function program1(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                <option value=\"store_log\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Store Transaction Logs", options) : helperMissing.call(depth0, "_", "Store Transaction Logs", options)))
    + "</option>\n                <option value=\"test_log\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Test Logs", options) : helperMissing.call(depth0, "_", "Test Logs", options)))
    + "</option>\n                ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", helper, options;
  buffer += "\n                <option value=\"device_log\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Device Logs", options) : helperMissing.call(depth0, "_", "Device Logs", options)))
    + "</option>\n                ";
  return buffer;
  }

  buffer += "<form class=\"form-horizontal\" role=\"form\" id=\"data-export-form\" method=\"GET\">\n    <div id=\"student-select-container\"></div>\n    <div class=\"form-group\">\n        <label for=\"resource-name\" class=\"col-xs-2\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Resource", options) : helperMissing.call(depth0, "_", "Resource", options)))
    + "</label>\n        <div class=\"col-xs-8\">\n            <select class=\"form-control\" id=\"resource-id\">\n                <option value=\"facility_user\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Facility User Logs", options) : helperMissing.call(depth0, "_", "Facility User Logs", options)))
    + "</option>\n                <option value=\"attempt_log\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Attempt Logs", options) : helperMissing.call(depth0, "_", "Attempt Logs", options)))
    + "</option>\n                <option value=\"exercise_log\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Exercise Logs", options) : helperMissing.call(depth0, "_", "Exercise Logs", options)))
    + "</option>\n                <option value=\"content_rating\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Ratings", options) : helperMissing.call(depth0, "_", "Ratings", options)))
    + "</option>\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.is_nalanda), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.is_central), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </select>\n        </div>\n    </div>\n    <div class=\"form-group\">\n        <label for=\"data-type\" class=\"col-xs-2\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Data Type", options) : helperMissing.call(depth0, "_", "Data Type", options)))
    + "</label>\n        <div class=\"col-xs-8\">\n            <select class=\"form-control\" id=\"test-name\" disabled>\n                <option>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "CSV", options) : helperMissing.call(depth0, "_", "CSV", options)))
    + "</option>\n            </select>\n        </div>\n    </div>\n    <div class=\"form-group\">\n        <div class=\"col-xs-2\"></div>\n        <div class=\"col-xs-8\">\n            <button id=\"export-button\" class=\"btn btn-success\">\n                "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Export", options) : helperMissing.call(depth0, "_", "Export", options)))
    + "\n            </button>\n        </div>\n    </div>\n</form>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}]},{},["data_export"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvY29udHJvbF9wYW5lbC9zdGF0aWMvanMvY29udHJvbF9wYW5lbC9idW5kbGVfbW9kdWxlcy9kYXRhX2V4cG9ydC5qcyIsImthbGl0ZS9jb250cm9sX3BhbmVsL3N0YXRpYy9qcy9jb250cm9sX3BhbmVsL2RhdGFfZXhwb3J0L3ZpZXdzLmpzIiwia2FsaXRlL2NvbnRyb2xfcGFuZWwvc3RhdGljL2pzL2NvbnRyb2xfcGFuZWwvZGF0YV9leHBvcnQvbW9kZWxzLmpzIiwia2FsaXRlL2NvbnRyb2xfcGFuZWwvc3RhdGljL2pzL2NvbnRyb2xfcGFuZWwvZGF0YV9leHBvcnQvaGJ0ZW1wbGF0ZXMvem9uZS1zZWxlY3QuaGFuZGxlYmFycyIsImthbGl0ZS9jb250cm9sX3BhbmVsL3N0YXRpYy9qcy9jb250cm9sX3BhbmVsL2RhdGFfZXhwb3J0L2hidGVtcGxhdGVzL2dyb3VwLXNlbGVjdC5oYW5kbGViYXJzIiwia2FsaXRlL2NvbnRyb2xfcGFuZWwvc3RhdGljL2pzL2NvbnRyb2xfcGFuZWwvZGF0YV9leHBvcnQvaGJ0ZW1wbGF0ZXMvZmFjaWxpdHktc2VsZWN0LmhhbmRsZWJhcnMiLCJrYWxpdGUvY29udHJvbF9wYW5lbC9zdGF0aWMvanMvY29udHJvbF9wYW5lbC9kYXRhX2V4cG9ydC9oYnRlbXBsYXRlcy9kYXRhLWV4cG9ydC1jb250YWluZXIuaGFuZGxlYmFycyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNSQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUM1VkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdkNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDeENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0RkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNuRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgJCA9IHJlcXVpcmUoXCJiYXNlL2pRdWVyeVwiKTtcbnZhciBEYXRhRXhwb3J0VmlldyA9IHJlcXVpcmUoXCJkYXRhX2V4cG9ydC92aWV3c1wiKS5EYXRhRXhwb3J0VmlldztcbnZhciBEYXRhRXhwb3J0U3RhdGVNb2RlbCA9IHJlcXVpcmUoXCJkYXRhX2V4cG9ydC9tb2RlbHNcIikuRGF0YUV4cG9ydFN0YXRlTW9kZWw7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXHQkOiAkLFxuXHREYXRhRXhwb3J0VmlldzogRGF0YUV4cG9ydFZpZXcsXG5cdERhdGFFeHBvcnRTdGF0ZU1vZGVsOiBEYXRhRXhwb3J0U3RhdGVNb2RlbFxufTsiLCJ2YXIgSGFuZGxlYmFycyA9IHJlcXVpcmUoXCJiYXNlL2hhbmRsZWJhcnNcIik7XG52YXIgQmFja2JvbmUgPSByZXF1aXJlKFwiYmFzZS9iYWNrYm9uZVwiKTtcbnZhciAkID0gcmVxdWlyZShcImJhc2UvalF1ZXJ5XCIpO1xuXG52YXIgTW9kZWxzID0gcmVxdWlyZShcIi4vbW9kZWxzXCIpO1xuXG4vLyBWaWV3c1xudmFyIERhdGFFeHBvcnRWaWV3ID0gQmFja2JvbmUuVmlldy5leHRlbmQoe1xuICAgIC8vIHRoZSBjb250YWluaW5nIHZpZXdcbiAgICB0ZW1wbGF0ZTogcmVxdWlyZSgnLi9oYnRlbXBsYXRlcy9kYXRhLWV4cG9ydC1jb250YWluZXIuaGFuZGxlYmFycycpLFxuXG4gICAgaW5pdGlhbGl6ZTogZnVuY3Rpb24ob3B0aW9ucykge1xuXG4gICAgICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnMgfHwge307XG5cbiAgICAgICAgdGhpcy56b25lX3NlbGVjdF92aWV3ID0gbmV3IFpvbmVTZWxlY3RWaWV3KHtcbiAgICAgICAgICAgIG9yZ19pZDogb3B0aW9ucy5vcmdfaWQsXG4gICAgICAgICAgICBtb2RlbDogdGhpcy5tb2RlbFxuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLmZhY2lsaXR5X3NlbGVjdF92aWV3ICA9IG5ldyBGYWNpbGl0eVNlbGVjdFZpZXcoe1xuICAgICAgICAgICAgbW9kZWw6IHRoaXMubW9kZWxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5ncm91cF9zZWxlY3RfdmlldyA9IG5ldyBHcm91cFNlbGVjdFZpZXcoe1xuICAgICAgICAgICAgbW9kZWw6IHRoaXMubW9kZWxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcbiAgICB9LFxuXG4gICAgZXZlbnRzOiB7XG4gICAgICAgIFwiY2xpY2sgI2V4cG9ydC1idXR0b25cIjogXCJleHBvcnRfZGF0YVwiLFxuICAgICAgICBcImNoYW5nZSAjcmVzb3VyY2UtaWRcIjogXCJyZXNvdXJjZV9jaGFuZ2VkXCJcbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgLy8gcmVuZGVyIGNvbnRhaW5lclxuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUodGhpcy5tb2RlbC5hdHRyaWJ1dGVzKSk7XG5cbiAgICAgICAgLy8gYXBwZW5kIHpvbmUsIGZhY2lsaXR5ICYgZ3JvdXAgc2VsZWN0IHZpZXdzLlxuICAgICAgICB0aGlzLiQoJyNzdHVkZW50LXNlbGVjdC1jb250YWluZXInKS5hcHBlbmQodGhpcy56b25lX3NlbGVjdF92aWV3LiRlbCk7XG4gICAgICAgIHRoaXMuJCgnI3N0dWRlbnQtc2VsZWN0LWNvbnRhaW5lcicpLmFwcGVuZCh0aGlzLmZhY2lsaXR5X3NlbGVjdF92aWV3LiRlbCk7XG4gICAgICAgIHRoaXMuJCgnI3N0dWRlbnQtc2VsZWN0LWNvbnRhaW5lcicpLmFwcGVuZCh0aGlzLmdyb3VwX3NlbGVjdF92aWV3LiRlbCk7XG4gICAgfSxcblxuICAgIHJlc291cmNlX2NoYW5nZWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLm1vZGVsLnNldCh7XG4gICAgICAgICAgICByZXNvdXJjZV9pZDogdGhpcy4kKCcjcmVzb3VyY2UtaWQnKS52YWwoKVxuICAgICAgICB9KTtcbiAgICB9LFxuXG4gICAgcmVzb3VyY2VfZW5kcG9pbnQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAvLyBSZXR1cm4gdGhlIEFQSSB1cmwgZW5kcG9pbnQgZm9yIHRoZSBjdXJyZW50IHJlc291cmNlIGlkXG4gICAgICAgIHZhciByZXNvdXJjZV9pZCA9IHRoaXMubW9kZWwuZ2V0KFwicmVzb3VyY2VfaWRcIik7XG4gICAgICAgIHN3aXRjaCAgKHJlc291cmNlX2lkKSB7XG4gICAgICAgICAgICBjYXNlIFwiZmFjaWxpdHlfdXNlclwiOlxuICAgICAgICAgICAgICAgIHJldHVybiBGQUNJTElUWV9VU0VSX0NTVl9VUkw7XG4gICAgICAgICAgICBjYXNlIFwidGVzdF9sb2dcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gVEVTVF9MT0dfQ1NWX1VSTDtcbiAgICAgICAgICAgIGNhc2UgXCJhdHRlbXB0X2xvZ1wiOlxuICAgICAgICAgICAgICAgIHJldHVybiBBVFRFTVBUX0xPR19DU1ZfVVJMO1xuICAgICAgICAgICAgY2FzZSBcImV4ZXJjaXNlX2xvZ1wiOlxuICAgICAgICAgICAgICAgIHJldHVybiBFWEVSQ0lTRV9MT0dfQ1NWX1VSTDtcbiAgICAgICAgICAgIGNhc2UgXCJkZXZpY2VfbG9nXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIERFVklDRV9MT0dfQ1NWX1VSTDtcbiAgICAgICAgICAgIGNhc2UgXCJzdG9yZV9sb2dcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gU1RPUkVfTE9HX0NTVl9VUkw7XG4gICAgICAgICAgICBjYXNlIFwiY29udGVudF9yYXRpbmdcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gQ09OVEVOVF9SQVRJTkdfQ1NWX1VSTDtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBleHBvcnRfZGF0YTogZnVuY3Rpb24oZXYpIHtcbiAgICAgICAgZXYucHJldmVudERlZmF1bHQoKTtcblxuICAgICAgICAvLyBVcGRhdGUgZXhwb3J0IGxpbmsgYmFzZWQgb24gY3VycmVudGx5IHNlbGVjdGVkIHBhcmFtdGVyc1xuICAgICAgICB2YXIgem9uZV9pZCA9IHRoaXMubW9kZWwuZ2V0KFwiem9uZV9pZFwiKTtcbiAgICAgICAgdmFyIGZhY2lsaXR5X2lkID0gdGhpcy5tb2RlbC5nZXQoXCJmYWNpbGl0eV9pZFwiKTtcbiAgICAgICAgdmFyIGdyb3VwX2lkID0gdGhpcy5tb2RlbC5nZXQoXCJncm91cF9pZFwiKTtcbiAgICAgICAgdmFyIHJlc291cmNlX2VuZHBvaW50ID0gdGhpcy5yZXNvdXJjZV9lbmRwb2ludCgpO1xuXG4gICAgICAgIC8vIElmIG5vIHpvbmVfaWQsIGFsbCBpcyBzZWxlY3RlZCwgc28gY29tcGlsZSBhIGNvbW1hIHNlcGVyYXRlZCBzdHJpbmdcbiAgICAgICAgLy8gb2Ygem9uZSBpZHMgdG8gcGFzcyB0byBlbmRwb2ludFxuICAgICAgICB2YXIgem9uZV9pZHMgPSBcIlwiO1xuICAgICAgICBpZiAoem9uZV9pZD09PXVuZGVmaW5lZCB8fCB6b25lX2lkPT09XCJcIikge1xuICAgICAgICAgICAgem9uZV9pZHMgPSBfLm1hcCh0aGlzLnpvbmVfc2VsZWN0X3ZpZXcuem9uZV9saXN0Lm1vZGVscywgZnVuY3Rpb24oem9uZSkgeyByZXR1cm4gem9uZS5nZXQoXCJpZFwiKTsgfSkuam9pbigpO1xuICAgICAgICB9XG5cbiAgICAgICAgdmFyIGV4cG9ydF9wYXJhbXMgPSBcIj9cIiArICQucGFyYW0oe1xuICAgICAgICAgICAgZ3JvdXBfaWQ6IGdyb3VwX2lkLFxuICAgICAgICAgICAgZmFjaWxpdHlfaWQ6IGZhY2lsaXR5X2lkLFxuICAgICAgICAgICAgem9uZV9pZDogem9uZV9pZCxcbiAgICAgICAgICAgIHpvbmVfaWRzOiB6b25lX2lkcyxcbiAgICAgICAgICAgIGZvcm1hdDpcImNzdlwiLFxuICAgICAgICAgICAgbGltaXQ6MFxuICAgICAgICB9KTtcblxuICAgICAgICB2YXIgZXhwb3J0X2RhdGFfdXJsID0gdGhpcy5yZXNvdXJjZV9lbmRwb2ludCgpICsgZXhwb3J0X3BhcmFtcztcbiAgICAgICAgd2luZG93LmxvY2F0aW9uID0gZXhwb3J0X2RhdGFfdXJsO1xuICAgIH1cbn0pO1xuXG5cbnZhciBab25lU2VsZWN0VmlldyA9IEJhY2tib25lLlZpZXcuZXh0ZW5kKHtcblxuICAgIHRlbXBsYXRlOiByZXF1aXJlKCcuL2hidGVtcGxhdGVzL3pvbmUtc2VsZWN0LmhhbmRsZWJhcnMnKSxcblxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAvLyBDcmVhdGUgY29sbGVjdGlvbnNcbiAgICAgICAgdGhpcy56b25lX2xpc3QgPSBuZXcgTW9kZWxzLlpvbmVDb2xsZWN0aW9uKCk7XG5cbiAgICAgICAgLy8gb24gY2VudHJhbCwgdGhpcyBpcyBhIGR5bmFtaWMgdmlld1xuICAgICAgICAvLyBvbiBkaXN0cmlidXRlZCwgdGhpcyBpcyBhIHBsYWNlaG9sZGVyIHZpZXcsXG4gICAgICAgIGlmICh0aGlzLm1vZGVsLmdldChcImlzX2NlbnRyYWxcIikpIHtcbiAgICAgICAgICAgIC8vIFJlLXJlbmRlciBzZWxmIHdoZW4gZmV0Y2ggcmV0dXJucyBvciBtb2RlbCBzdGF0ZSBjaGFuZ2VzXG4gICAgICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMuem9uZV9saXN0LCAnc3luYycsIHRoaXMucmVuZGVyKTtcblxuICAgICAgICAgICAgLy8gRmV0Y2ggY29sbGVjdGlvbiBieSBvcmdfaWRcbiAgICAgICAgICAgIHRoaXMuem9uZV9saXN0LmZldGNoKHtcbiAgICAgICAgICAgICAgICBkYXRhOiAkLnBhcmFtKHtcbiAgICAgICAgICAgICAgICAgICAgXCJvcmdfaWRcIjogdGhpcy5vcHRpb25zLm9yZ19pZCxcbiAgICAgICAgICAgICAgICAgICAgXCJsaW1pdFwiOiAwXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHJlbmRlcmVkX2h0bWwgPSB0aGlzLnRlbXBsYXRlKHtcbiAgICAgICAgICAgIHpvbmVzOiB0aGlzLnpvbmVfbGlzdC50b0pTT04oKSxcbiAgICAgICAgICAgIHNlbGVjdGlvbjogdGhpcy5tb2RlbC5nZXQoXCJ6b25lX2lkXCIpXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGlmICh0aGlzLm1vZGVsLmdldChcImlzX2NlbnRyYWxcIikpIHtcbiAgICAgICAgICAgIHRoaXMuJGVsLmh0bWwocmVuZGVyZWRfaHRtbCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLiRlbC5odG1sKHJlbmRlcmVkX2h0bWwpLmhpZGUoKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBldmVudHM6IHtcbiAgICAgICAgXCJjaGFuZ2VcIjogXCJ6b25lX2NoYW5nZWRcIlxuICAgIH0sXG5cbiAgICB6b25lX2NoYW5nZWQ6IGZ1bmN0aW9uKGV2KSB7XG4gICAgICAgIC8vIFVwZGF0ZSBzdGF0ZSBtb2RlbFxuICAgICAgICB2YXIgem9uZV9pZCA9IHRoaXMuJChcInNlbGVjdFwiKS52YWwoKTtcbiAgICAgICAgdGhpcy5tb2RlbC5zZXQoe1xuICAgICAgICAgICAgZmFjaWxpdHlfaWQ6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIGdyb3VwX2lkOiB1bmRlZmluZWQsXG4gICAgICAgICAgICB6b25lX2lkOiB6b25lX2lkXG4gICAgICAgIH0pO1xuICAgIH1cbn0pO1xuXG52YXIgRmFjaWxpdHlTZWxlY3RWaWV3ID0gQmFja2JvbmUuVmlldy5leHRlbmQoe1xuXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoJy4vaGJ0ZW1wbGF0ZXMvZmFjaWxpdHktc2VsZWN0LmhhbmRsZWJhcnMnKSxcblxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAvLyBDcmVhdGUgY29sbGVjdGlvbnNcbiAgICAgICAgdGhpcy5mYWNpbGl0eV9saXN0ID0gbmV3IE1vZGVscy5GYWNpbGl0eUNvbGxlY3Rpb24oKTtcblxuICAgICAgICAvLyBSZS1yZW5kZXIgc2VsZiB3aGVuIHRoZSBmZXRjaCByZXR1cm5zIG9yIHN0YXRlIG1vZGVsIGNoYW5nZXNcbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh0aGlzLmZhY2lsaXR5X2xpc3QsICdzeW5jJywgdGhpcy5yZW5kZXIpO1xuICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMuZmFjaWxpdHlfbGlzdCwgJ3Jlc2V0JywgdGhpcy5yZW5kZXIpO1xuICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMubW9kZWwsICdjaGFuZ2U6cmVzb3VyY2VfaWQnLCB0aGlzLnJlbmRlcik7XG5cbiAgICAgICAgLy8gb24gY2VudHJhbCwgZmFjaWxpdGllcyBkZXBlbmQgb24gdGhlIHpvbmUgc2VsZWN0ZWRcbiAgICAgICAgLy8gb24gZGlzdHJpYnV0ZWQsIHpvbmUgaXMgZml4ZWRcbiAgICAgICAgaWYgKHRoaXMubW9kZWwuZ2V0KFwiaXNfY2VudHJhbFwiKSkge1xuICAgICAgICAgICAgLy8gTGlzdGVuIGZvciBhbnkgY2hhbmdlcyBvbiB0aGUgem9uZSBtb2RlbCwgd2hlbiBpdCBoYXBwZW5zLCByZS1mZXRjaCBzZWxmXG4gICAgICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMubW9kZWwsICdjaGFuZ2U6em9uZV9pZCcsIHRoaXMuZmV0Y2hfYnlfem9uZSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGZXRjaCBjb2xsZWN0aW9uLCBieSBmaXhlZCB6b25lXG4gICAgICAgIHRoaXMuZmV0Y2hfYnlfem9uZSgpO1xuXG4gICAgICAgIC8vIFJlbmRlclxuICAgICAgICB0aGlzLnJlbmRlcigpO1xuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgdGVtcGxhdGVfY29udGV4dDtcblxuICAgICAgICBpZiAodGhpcy5tb2RlbC5nZXQoXCJmYWNpbGl0eV9pZFwiKSAhPT0gXCJcIikge1xuICAgICAgICAgICAgdGVtcGxhdGVfY29udGV4dCA9IHtcbiAgICAgICAgICAgICAgICBmYWNpbGl0aWVzOiB0aGlzLmZhY2lsaXR5X2xpc3QudG9KU09OKCksXG4gICAgICAgICAgICAgICAgc2VsZWN0aW9uOiB0aGlzLm1vZGVsLmdldChcImZhY2lsaXR5X2lkXCIpLFxuICAgICAgICAgICAgICAgIGlzX2Rpc2FibGVkOiB0cnVlXG4gICAgICAgICAgICB9O1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGVtcGxhdGVfY29udGV4dCA9IHtcbiAgICAgICAgICAgICAgICBmYWNpbGl0aWVzOiB0aGlzLmZhY2lsaXR5X2xpc3QudG9KU09OKCksXG4gICAgICAgICAgICAgICAgc2VsZWN0aW9uOiB0aGlzLm1vZGVsLmdldChcImZhY2lsaXR5X2lkXCIpLFxuICAgICAgICAgICAgICAgIC8vIEZhY2lsaXR5IHNlbGVjdCBpcyBlbmFibGVkIG9ubHkgaWYgem9uZV9pZCBoYXMgYmVlbiBzZXRcbiAgICAgICAgICAgICAgICBpc19kaXNhYmxlZDogdGhpcy5pc19kaXNhYmxlZCgpXG4gICAgICAgICAgICB9O1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKHRlbXBsYXRlX2NvbnRleHQpKTtcblxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuXG4gICAgaXNfZGlzYWJsZWQ6IGZ1bmN0aW9uKCkge1xuICAgICAgICAvLyBIZWxwZXIgZnVuY3Rpb24gdG8gcXVpY2tseSBjaGVjayB3aGV0aGVyIHRoZSBmYWNpbGl0eSBzZWxlY3QgaW5wdXRcbiAgICAgICAgLy8gc2hvdWxkIGJlIGVuYWJsZWQgb3IgZGlzYWJsZWQgYmFzZWQgb24gY29uZGl0aW9ucyB0aGF0IG1hdHRlciB0byBpdC5cbiAgICAgICAgaWYgKHRoaXMubW9kZWwuZ2V0KFwicmVzb3VyY2VfaWRcIikgPT09IFwiZGV2aWNlX2xvZ1wiKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gKCh0aGlzLm1vZGVsLmdldChcInpvbmVfaWRcIikgPT09IHVuZGVmaW5lZCB8fCB0aGlzLm1vZGVsLmdldChcInpvbmVfaWRcIikgPT09IFwiXCIpICYmIHRoaXMubW9kZWwuZ2V0KFwiaXNfY2VudHJhbFwiKSk7XG4gICAgfSxcblxuICAgIHJlbmRlcl93YWl0aW5nOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHRlbXBsYXRlX2NvbnRleHQgPSB7XG4gICAgICAgICAgICBpc19kaXNhYmxlZDogdHJ1ZSxcbiAgICAgICAgICAgIGxvYWRpbmc6IHRydWVcbiAgICAgICAgfTtcblxuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUodGVtcGxhdGVfY29udGV4dCkpO1xuICAgIH0sXG5cbiAgICBldmVudHM6IHtcbiAgICAgICAgXCJjaGFuZ2VcIjogXCJmYWNpbGl0eV9jaGFuZ2VkXCJcbiAgICB9LFxuXG4gICAgZmFjaWxpdHlfY2hhbmdlZDogZnVuY3Rpb24oZXYpIHtcbiAgICAgICAgLy8gVXBkYXRlIHN0YXRlIG1vZGVsXG4gICAgICAgIHZhciBmYWNpbGl0eV9pZCA9IHRoaXMuJChcInNlbGVjdFwiKS52YWwoKTtcblxuICAgICAgICB0aGlzLm1vZGVsLnNldCh7XG4gICAgICAgICAgICBncm91cF9pZDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgZmFjaWxpdHlfaWQ6IGZhY2lsaXR5X2lkXG4gICAgICAgIH0pO1xuICAgIH0sXG5cbiAgICBmZXRjaF9ieV96b25lOiBmdW5jdGlvbigpIHtcbiAgICAgICAgLy8gRmlyc3QgZGlzYWJsZSB0aGUgc2VsZWN0XG4gICAgICAgIGlmICh0aGlzLm1vZGVsLmdldChcImlzX2NlbnRyYWxcIikpIHtcbiAgICAgICAgICAgIHZhciB6b25lX2lkID0gdGhpcy5tb2RlbC5nZXQoXCJ6b25lX2lkXCIpO1xuXG4gICAgICAgICAgICAvLyBvbmx5IGZldGNoIGlmIGEgem9uZSBJRCBoYXMgYmVlbiBzZXRcbiAgICAgICAgICAgIGlmICh6b25lX2lkKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5yZW5kZXJfd2FpdGluZygpO1xuICAgICAgICAgICAgICAgIHRoaXMuZmFjaWxpdHlfbGlzdC5mZXRjaCh7XG4gICAgICAgICAgICAgICAgICAgIGRhdGE6ICQucGFyYW0oe1xuICAgICAgICAgICAgICAgICAgICAgICAgXCJ6b25lX2lkXCI6IHpvbmVfaWQsXG4gICAgICAgICAgICAgICAgICAgICAgICBcImxpbWl0XCI6IDBcbiAgICAgICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5mYWNpbGl0eV9saXN0LnJlc2V0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnJlbmRlcl93YWl0aW5nKCk7XG4gICAgICAgICAgICB0aGlzLmZhY2lsaXR5X2xpc3QuZmV0Y2goKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuXG52YXIgR3JvdXBTZWxlY3RWaWV3ID0gQmFja2JvbmUuVmlldy5leHRlbmQoe1xuXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoJy4vaGJ0ZW1wbGF0ZXMvZ3JvdXAtc2VsZWN0LmhhbmRsZWJhcnMnKSxcblxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICAvLyBDcmVhdGUgY29sbGVjdGlvbnNcbiAgICAgICAgdGhpcy5ncm91cF9saXN0ID0gbmV3IE1vZGVscy5Hcm91cENvbGxlY3Rpb24oKTtcblxuICAgICAgICB0aGlzLmZldGNoX2J5X2ZhY2lsaXR5KCk7XG4gICAgICAgIC8vIFJlLXJlbmRlciBzZWxmIHdoZW4gdGhlIGZldGNoIHJldHVybnMgb3Igc3RhdGUgbW9kZWwgY2hhbmdlc1xuICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMuZ3JvdXBfbGlzdCwgJ3N5bmMnLCB0aGlzLnJlbmRlcik7XG4gICAgICAgIHRoaXMubGlzdGVuVG8odGhpcy5ncm91cF9saXN0LCAncmVzZXQnLCB0aGlzLnJlbmRlcik7XG4gICAgICAgIHRoaXMubGlzdGVuVG8odGhpcy5tb2RlbCwgJ2NoYW5nZTpyZXNvdXJjZV9pZCcsIHRoaXMucmVuZGVyKTtcblxuICAgICAgICAvLyBvbiBjZW50cmFsLCBncm91cHMgZGVwZW5kIG9uIGZhY2lsaXRpZXMgd2hpY2ggZGVwZW5kIG9uIHRoZSB6b25lIHNlbGVjdGVkXG4gICAgICAgIC8vIG9uIGRpc3RyaWJ1dGVkLCB6b25lIGlzIGZpeGVkLCBzbyBncm91cHMganVzdCBkZXBlbmQgb24gZmFjaWxpdGllc1xuICAgICAgICAvLyBSZWdhcmRsZXNzLCB3YWl0IGZvciBhbnkgY2hhbmdlcyBvbiB0aGUgZmFjaWxpdHkgbW9kZWwsIGFuZCB0aGVuIHJlLWZldGNoIHNlbGZcbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh0aGlzLm1vZGVsLCAnY2hhbmdlOmZhY2lsaXR5X2lkJywgdGhpcy5mZXRjaF9ieV9mYWNpbGl0eSk7XG5cbiAgICAgICAgLy8gUmVuZGVyXG4gICAgICAgIHRoaXMucmVuZGVyKCk7XG4gICAgfSxcblxuICAgIHJlbmRlcjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciB0ZW1wbGF0ZV9jb250ZXh0ID0ge1xuICAgICAgICAgICAgZ3JvdXBzOiB0aGlzLmdyb3VwX2xpc3QudG9KU09OKCksXG4gICAgICAgICAgICBzZWxlY3Rpb246IHRoaXMubW9kZWwuZ2V0KFwiZ3JvdXBfaWRcIiksXG4gICAgICAgICAgICAvLyBHcm91cCBzZWxlY3QgaXMgZW5hYmxlZCBvbmx5IGlmIGZhY2lsaXR5X2lkIGhhcyBiZWVuIHNldFxuICAgICAgICAgICAgaXNfZGlzYWJsZWQ6IHRoaXMuaXNfZGlzYWJsZWQoKVxuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMuJGVsLmh0bWwodGhpcy50ZW1wbGF0ZSh0ZW1wbGF0ZV9jb250ZXh0KSk7XG5cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfSxcblxuICAgIGlzX2Rpc2FibGVkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgaWYgKHRoaXMubW9kZWwuZ2V0KFwicmVzb3VyY2VfaWRcIikgPT09IFwiZGV2aWNlX2xvZ1wiKXtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiAhdGhpcy5tb2RlbC5nZXQoXCJmYWNpbGl0eV9pZFwiKTtcbiAgICB9LFxuXG4gICAgcmVuZGVyX3dhaXRpbmc6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgdGVtcGxhdGVfY29udGV4dCA9IHtcbiAgICAgICAgICAgIGlzX2Rpc2FibGVkOiB0cnVlLFxuICAgICAgICAgICAgbG9hZGluZzogdHJ1ZVxuICAgICAgICB9O1xuXG4gICAgICAgIHRoaXMuJGVsLmh0bWwodGhpcy50ZW1wbGF0ZSh0ZW1wbGF0ZV9jb250ZXh0KSk7XG4gICAgfSxcblxuICAgIGV2ZW50czoge1xuICAgICAgICBcImNoYW5nZVwiOiBcImdyb3VwX2NoYW5nZWRcIlxuICAgIH0sXG5cbiAgICBncm91cF9jaGFuZ2VkOiBmdW5jdGlvbihldikge1xuICAgICAgICB2YXIgZ3JvdXBfaWQgPSB0aGlzLiQoXCJzZWxlY3RcIikudmFsKCk7XG4gICAgICAgIHRoaXMubW9kZWwuc2V0KHsgZ3JvdXBfaWQ6IGdyb3VwX2lkIH0pO1xuICAgIH0sXG5cbiAgICBmZXRjaF9ieV9mYWNpbGl0eTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBmYWNpbGl0eV9pZCA9IHRoaXMubW9kZWwuZ2V0KFwiZmFjaWxpdHlfaWRcIik7XG4gICAgICAgIC8vIG9ubHkgZmV0Y2ggaWYgZmFjaWxpdHkgSUQgaGFzIGJlZW4gc2V0XG4gICAgICAgIGlmIChmYWNpbGl0eV9pZCkge1xuICAgICAgICAgICAgdGhpcy5yZW5kZXJfd2FpdGluZygpO1xuICAgICAgICAgICAgdGhpcy5ncm91cF9saXN0LmZldGNoKHtcbiAgICAgICAgICAgICAgICBkYXRhOiAkLnBhcmFtKHtcbiAgICAgICAgICAgICAgICAgICAgXCJmYWNpbGl0eV9pZFwiOiBmYWNpbGl0eV9pZCxcbiAgICAgICAgICAgICAgICAgICAgXCJsaW1pdFwiOiAwXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5ncm91cF9saXN0LnJlc2V0KCk7XG4gICAgICAgIH1cbiAgICB9XG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgRGF0YUV4cG9ydFZpZXc6IERhdGFFeHBvcnRWaWV3LFxuICAgIFpvbmVTZWxlY3RWaWV3OiBab25lU2VsZWN0VmlldyxcbiAgICBGYWNpbGl0eVNlbGVjdFZpZXc6IEZhY2lsaXR5U2VsZWN0VmlldyxcbiAgICBHcm91cFNlbGVjdFZpZXc6IEdyb3VwU2VsZWN0Vmlld1xufTtcbiIsIi8vIEhhbmRsZXMgdGhlIGRhdGEgZXhwb3J0IGZ1bmN0aW9uYWxpdHkgb2YgdGhlIGNvbnRyb2wgcGFuZWxcbi8vIFRPRE8tYmxvY2tlcihkeWxhbmpiYXJ0aCkgMC4xMzogbGltaXQgcmVxdWVzdHMgYW5kIGhhbmRsZSBwYWdpbmF0aW9uXG52YXIgQmFja2JvbmUgPSByZXF1aXJlKFwiYmFzZS9iYWNrYm9uZVwiKTtcblxuXG4vLyBNb2RlbHNcbnZhciBab25lTW9kZWwgPSBCYWNrYm9uZS5Nb2RlbC5leHRlbmQoKTtcblxudmFyIEZhY2lsaXR5TW9kZWwgPSBCYWNrYm9uZS5Nb2RlbC5leHRlbmQoKTtcblxudmFyIEdyb3VwTW9kZWwgPSBCYWNrYm9uZS5Nb2RlbC5leHRlbmQoKTtcblxudmFyIERhdGFFeHBvcnRTdGF0ZU1vZGVsID0gQmFja2JvbmUuTW9kZWwuZXh0ZW5kKCk7XG5cbi8vIENvbGxlY3Rpb25zXG52YXIgWm9uZUNvbGxlY3Rpb24gPSBCYWNrYm9uZS5Db2xsZWN0aW9uLmV4dGVuZCh7XG4gICAgbW9kZWw6IFpvbmVNb2RlbCxcbiAgICB1cmw6IEFMTF9aT05FU19VUkxcbn0pO1xuXG52YXIgRmFjaWxpdHlDb2xsZWN0aW9uID0gQmFja2JvbmUuQ29sbGVjdGlvbi5leHRlbmQoe1xuICAgIG1vZGVsOiBGYWNpbGl0eU1vZGVsLFxuICAgIHVybDogQUxMX0ZBQ0lMSVRJRVNfVVJMXG59KTtcblxudmFyIEdyb3VwQ29sbGVjdGlvbiA9IEJhY2tib25lLkNvbGxlY3Rpb24uZXh0ZW5kKHtcbiAgICBtb2RlbDogR3JvdXBNb2RlbCxcbiAgICB1cmw6IEFMTF9HUk9VUFNfVVJMXG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG5cdFpvbmVNb2RlbDogWm9uZU1vZGVsLFxuXHRGYWNpbGl0eU1vZGVsOiBGYWNpbGl0eU1vZGVsLFxuXHRHcm91cE1vZGVsOiBHcm91cE1vZGVsLFxuXHREYXRhRXhwb3J0U3RhdGVNb2RlbDogRGF0YUV4cG9ydFN0YXRlTW9kZWwsXG5cdFpvbmVDb2xsZWN0aW9uOiBab25lQ29sbGVjdGlvbixcblx0RmFjaWxpdHlDb2xsZWN0aW9uOiBGYWNpbGl0eUNvbGxlY3Rpb24sXG5cdEdyb3VwQ29sbGVjdGlvbjogR3JvdXBDb2xsZWN0aW9uLFxufTtcbiIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zLCBmdW5jdGlvblR5cGU9XCJmdW5jdGlvblwiLCBlc2NhcGVFeHByZXNzaW9uPXRoaXMuZXNjYXBlRXhwcmVzc2lvbiwgc2VsZj10aGlzLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZztcblxuZnVuY3Rpb24gcHJvZ3JhbTEoZGVwdGgwLGRhdGEsZGVwdGgxKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVxcXCJcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMuaWQpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAuaWQpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiXFxcIiBcIjtcbiAgc3RhY2sxID0gKGhlbHBlciA9IGhlbHBlcnMuaWZjb25kIHx8IChkZXB0aDEgJiYgZGVwdGgxLmlmY29uZCksb3B0aW9ucz17aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMiwgcHJvZ3JhbTIsIGRhdGEpLGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoZGVwdGgxICYmIGRlcHRoMS5zZWxlY3Rpb24pLCBcIj09PVwiLCAoZGVwdGgwICYmIGRlcHRoMC5pZCksIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJpZmNvbmRcIiwgKGRlcHRoMSAmJiBkZXB0aDEuc2VsZWN0aW9uKSwgXCI9PT1cIiwgKGRlcHRoMCAmJiBkZXB0aDAuaWQpLCBvcHRpb25zKSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCI+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLm5hbWUpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAubmFtZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCI8L29wdGlvbj5cXG4gICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTIoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIFxuICByZXR1cm4gXCJzZWxlY3RlZFwiO1xuICB9XG5cbiAgYnVmZmVyICs9IFwiPGRpdiBjbGFzcz1cXFwiZm9ybS1ncm91cFxcXCI+XFxuICAgIDxsYWJlbCBmb3I9XFxcInpvbmUtbmFtZVxcXCIgY2xhc3M9XFxcImNvbC14cy0yXFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiWm9uZVwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIlpvbmVcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L2xhYmVsPlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtOFxcXCI+XFxuICAgICAgICA8c2VsZWN0IGNsYXNzPVxcXCJmb3JtLWNvbnRyb2xcXFwiIGlkPVxcXCJ6b25lLW5hbWVcXFwiPlxcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XFxcIlxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIkFsbFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkFsbFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvb3B0aW9uPlxcbiAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzLmVhY2guY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLnpvbmVzKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtV2l0aERlcHRoKDEsIHByb2dyYW0xLCBkYXRhLCBkZXB0aDApLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICA8L3NlbGVjdD5cXG4gICAgPC9kaXY+XFxuPC9kaXY+XCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnMsIGhlbHBlck1pc3Npbmc9aGVscGVycy5oZWxwZXJNaXNzaW5nLCBlc2NhcGVFeHByZXNzaW9uPXRoaXMuZXNjYXBlRXhwcmVzc2lvbiwgZnVuY3Rpb25UeXBlPVwiZnVuY3Rpb25cIiwgc2VsZj10aGlzO1xuXG5mdW5jdGlvbiBwcm9ncmFtMShkZXB0aDAsZGF0YSkge1xuICBcbiAgXG4gIHJldHVybiBcIlxcbiAgICAgICAgICAgIDxpbWcgc3JjPVxcXCIvc3RhdGljL2ltYWdlcy9sb2FkaW5nLmdpZlxcXCIgY2xhc3M9XFxcImZsb2F0LWNlbnRlciBmbG9hdC1vdmVyLXNlbGVjdCBsb2FkaW5nXFxcIi8+XFxuICAgICAgICBcIjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtMyhkZXB0aDAsZGF0YSkge1xuICBcbiAgXG4gIHJldHVybiBcImxvYWRpbmctdHJhbnNwYXJlbmN5XCI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTUoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIFxuICByZXR1cm4gXCJkaXNhYmxlZFwiO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW03KGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVxcXCJcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJBbGxcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJBbGxcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L29wdGlvbj5cXG4gICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnMuZWFjaC5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZ3JvdXBzKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtV2l0aERlcHRoKDgsIHByb2dyYW04LCBkYXRhLCBkZXB0aDApLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cbmZ1bmN0aW9uIHByb2dyYW04KGRlcHRoMCxkYXRhLGRlcHRoMSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwic1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcInNcIiwgb3B0aW9ucykpKVxuICAgICsgXCJcXG4gICAgICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XFxcIlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5pZCkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5pZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXFwiIFwiO1xuICBzdGFjazEgPSAoaGVscGVyID0gaGVscGVycy5pZmNvbmQgfHwgKGRlcHRoMSAmJiBkZXB0aDEuaWZjb25kKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSg5LCBwcm9ncmFtOSwgZGF0YSksZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIChkZXB0aDEgJiYgZGVwdGgxLnNlbGVjdGlvbiksIFwiPT09XCIsIChkZXB0aDAgJiYgZGVwdGgwLmlkKSwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcImlmY29uZFwiLCAoZGVwdGgxICYmIGRlcHRoMS5zZWxlY3Rpb24pLCBcIj09PVwiLCAoZGVwdGgwICYmIGRlcHRoMC5pZCksIG9wdGlvbnMpKTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIj5cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMubmFtZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5uYW1lKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvb3B0aW9uPlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTkoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIFxuICByZXR1cm4gXCJzZWxlY3RlZFwiO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0xMShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgIDxvcHRpb24gZGlzYWJsZWQ+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIkFsbFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkFsbFwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvb3B0aW9uPlxcbiAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbiAgYnVmZmVyICs9IFwiPGRpdiBjbGFzcz1cXFwiZm9ybS1ncm91cFxcXCI+XFxuICAgIDxsYWJlbCBmb3I9XFxcImdyb3VwLW5hbWVcXFwiIGNsYXNzPVxcXCJjb2wteHMtMlxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIkdyb3VwXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiR3JvdXBcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L2xhYmVsPlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtOFxcXCI+XFxuICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAubG9hZGluZyksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxLCBwcm9ncmFtMSwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgIDxzZWxlY3QgY2xhc3M9XFxcImZvcm0tY29udHJvbCBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAubG9hZGluZyksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgzLCBwcm9ncmFtMywgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXFwiIGlkPVxcXCJncm91cC1uYW1lXFxcIiBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuaXNfZGlzYWJsZWQpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oNSwgcHJvZ3JhbTUsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiPlxcbiAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5ncm91cHMpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYucHJvZ3JhbSgxMSwgcHJvZ3JhbTExLCBkYXRhKSxmbjpzZWxmLnByb2dyYW0oNywgcHJvZ3JhbTcsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICA8L3NlbGVjdD5cXG4gICAgPC9kaXY+XFxuPC9kaXY+XCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnMsIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIGVzY2FwZUV4cHJlc3Npb249dGhpcy5lc2NhcGVFeHByZXNzaW9uLCBzZWxmPXRoaXMsIGhlbHBlck1pc3Npbmc9aGVscGVycy5oZWxwZXJNaXNzaW5nO1xuXG5mdW5jdGlvbiBwcm9ncmFtMShkZXB0aDAsZGF0YSkge1xuICBcbiAgXG4gIHJldHVybiBcIlxcbiAgICAgICAgICAgIDxpbWcgc3JjPVxcXCIvc3RhdGljL2ltYWdlcy9sb2FkaW5nLmdpZlxcXCIgY2xhc3M9XFxcImZsb2F0LWNlbnRlciBmbG9hdC1vdmVyLXNlbGVjdCBsb2FkaW5nXFxcIi8+XFxuICAgICAgICBcIjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtMyhkZXB0aDAsZGF0YSkge1xuICBcbiAgXG4gIHJldHVybiBcImxvYWRpbmctdHJhbnNwYXJlbmN5XCI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTUoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIFxuICByZXR1cm4gXCJkaXNhYmxlZFwiO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW03KGRlcHRoMCxkYXRhLGRlcHRoMSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cXFwiXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmlkKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLmlkKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIlxcXCIgXCI7XG4gIHN0YWNrMSA9IChoZWxwZXIgPSBoZWxwZXJzLmlmY29uZCB8fCAoZGVwdGgxICYmIGRlcHRoMS5pZmNvbmQpLG9wdGlvbnM9e2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDgsIHByb2dyYW04LCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKGRlcHRoMSAmJiBkZXB0aDEuc2VsZWN0aW9uKSwgXCI9PT1cIiwgKGRlcHRoMCAmJiBkZXB0aDAuaWQpLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsIChkZXB0aDEgJiYgZGVwdGgxLnNlbGVjdGlvbiksIFwiPT09XCIsIChkZXB0aDAgJiYgZGVwdGgwLmlkKSwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5uYW1lKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLm5hbWUpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiPC9vcHRpb24+XFxuICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cbmZ1bmN0aW9uIHByb2dyYW04KGRlcHRoMCxkYXRhKSB7XG4gIFxuICBcbiAgcmV0dXJuIFwic2VsZWN0ZWRcIjtcbiAgfVxuXG4gIGJ1ZmZlciArPSBcIjxkaXYgY2xhc3M9XFxcImZvcm0tZ3JvdXBcXFwiPlxcbiAgICA8bGFiZWwgZm9yPVxcXCJmYWNpbGl0eS1uYW1lXFxcIiBjbGFzcz1cXFwiY29sLXhzLTJcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJGYWNpbGl0eVwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkZhY2lsaXR5XCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9sYWJlbD5cXG4gICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLThcXFwiPlxcbiAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmxvYWRpbmcpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMSwgcHJvZ3JhbTEsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICA8c2VsZWN0IGNsYXNzPVxcXCJmb3JtLWNvbnRyb2wgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmxvYWRpbmcpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMywgcHJvZ3JhbTMsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxcIiBpZD1cXFwiZmFjaWxpdHktbmFtZVxcXCIgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmlzX2Rpc2FibGVkKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDUsIHByb2dyYW01LCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIj5cXG4gICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVxcXCJcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJBbGxcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJBbGxcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L29wdGlvbj5cXG4gICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVycy5lYWNoLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5mYWNpbGl0aWVzKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtV2l0aERlcHRoKDcsIHByb2dyYW03LCBkYXRhLCBkZXB0aDApLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICA8L3NlbGVjdD5cXG4gICAgPC9kaXY+XFxuPC9kaXY+XCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnMsIGhlbHBlck1pc3Npbmc9aGVscGVycy5oZWxwZXJNaXNzaW5nLCBlc2NhcGVFeHByZXNzaW9uPXRoaXMuZXNjYXBlRXhwcmVzc2lvbiwgc2VsZj10aGlzO1xuXG5mdW5jdGlvbiBwcm9ncmFtMShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XFxcInN0b3JlX2xvZ1xcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIlN0b3JlIFRyYW5zYWN0aW9uIExvZ3NcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJTdG9yZSBUcmFuc2FjdGlvbiBMb2dzXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9vcHRpb24+XFxuICAgICAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XFxcInRlc3RfbG9nXFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiVGVzdCBMb2dzXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiVGVzdCBMb2dzXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9vcHRpb24+XFxuICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0zKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cXFwiZGV2aWNlX2xvZ1xcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIkRldmljZSBMb2dzXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiRGV2aWNlIExvZ3NcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L29wdGlvbj5cXG4gICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuICBidWZmZXIgKz0gXCI8Zm9ybSBjbGFzcz1cXFwiZm9ybS1ob3Jpem9udGFsXFxcIiByb2xlPVxcXCJmb3JtXFxcIiBpZD1cXFwiZGF0YS1leHBvcnQtZm9ybVxcXCIgbWV0aG9kPVxcXCJHRVRcXFwiPlxcbiAgICA8ZGl2IGlkPVxcXCJzdHVkZW50LXNlbGVjdC1jb250YWluZXJcXFwiPjwvZGl2PlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJmb3JtLWdyb3VwXFxcIj5cXG4gICAgICAgIDxsYWJlbCBmb3I9XFxcInJlc291cmNlLW5hbWVcXFwiIGNsYXNzPVxcXCJjb2wteHMtMlxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIlJlc291cmNlXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiUmVzb3VyY2VcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L2xhYmVsPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLThcXFwiPlxcbiAgICAgICAgICAgIDxzZWxlY3QgY2xhc3M9XFxcImZvcm0tY29udHJvbFxcXCIgaWQ9XFxcInJlc291cmNlLWlkXFxcIj5cXG4gICAgICAgICAgICAgICAgPG9wdGlvbiB2YWx1ZT1cXFwiZmFjaWxpdHlfdXNlclxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIkZhY2lsaXR5IFVzZXIgTG9nc1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkZhY2lsaXR5IFVzZXIgTG9nc1wiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvb3B0aW9uPlxcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVxcXCJhdHRlbXB0X2xvZ1xcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIkF0dGVtcHQgTG9nc1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkF0dGVtcHQgTG9nc1wiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvb3B0aW9uPlxcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVxcXCJleGVyY2lzZV9sb2dcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJFeGVyY2lzZSBMb2dzXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiRXhlcmNpc2UgTG9nc1wiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvb3B0aW9uPlxcbiAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVxcXCJjb250ZW50X3JhdGluZ1xcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIlJhdGluZ3NcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJSYXRpbmdzXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9vcHRpb24+XFxuICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5pc19uYWxhbmRhKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDEsIHByb2dyYW0xLCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuaXNfY2VudHJhbCksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgzLCBwcm9ncmFtMywgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICA8L3NlbGVjdD5cXG4gICAgICAgIDwvZGl2PlxcbiAgICA8L2Rpdj5cXG4gICAgPGRpdiBjbGFzcz1cXFwiZm9ybS1ncm91cFxcXCI+XFxuICAgICAgICA8bGFiZWwgZm9yPVxcXCJkYXRhLXR5cGVcXFwiIGNsYXNzPVxcXCJjb2wteHMtMlxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIkRhdGEgVHlwZVwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkRhdGEgVHlwZVwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvbGFiZWw+XFxuICAgICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtOFxcXCI+XFxuICAgICAgICAgICAgPHNlbGVjdCBjbGFzcz1cXFwiZm9ybS1jb250cm9sXFxcIiBpZD1cXFwidGVzdC1uYW1lXFxcIiBkaXNhYmxlZD5cXG4gICAgICAgICAgICAgICAgPG9wdGlvbj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiQ1NWXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiQ1NWXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9vcHRpb24+XFxuICAgICAgICAgICAgPC9zZWxlY3Q+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuICAgIDxkaXYgY2xhc3M9XFxcImZvcm0tZ3JvdXBcXFwiPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTJcXFwiPjwvZGl2PlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLThcXFwiPlxcbiAgICAgICAgICAgIDxidXR0b24gaWQ9XFxcImV4cG9ydC1idXR0b25cXFwiIGNsYXNzPVxcXCJidG4gYnRuLXN1Y2Nlc3NcXFwiPlxcbiAgICAgICAgICAgICAgICBcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiRXhwb3J0XCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiRXhwb3J0XCIsIG9wdGlvbnMpKSlcbiAgICArIFwiXFxuICAgICAgICAgICAgPC9idXR0b24+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuPC9mb3JtPlxcblwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9KTtcbiJdfQ==
