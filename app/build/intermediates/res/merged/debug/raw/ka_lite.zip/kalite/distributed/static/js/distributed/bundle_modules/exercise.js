require("../perseus/build/perseus-3.css");
require("../../../css/distributed/exercise.less");

module.exports = require("exercises/views");