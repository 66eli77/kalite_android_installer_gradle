require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"learn":[function(require,module,exports){
var $ = require("base/jQuery");
var TopicChannelRouter = require("topics/router");
var Backbone = require("base/backbone");

require("../../../css/distributed/content-rating.less");

module.exports = {
	$: $,
	TopicChannelRouter: TopicChannelRouter,
	Backbone: Backbone
};
},{"../../../css/distributed/content-rating.less":29,"base/backbone":42,"base/jQuery":45,"topics/router":116}],116:[function(require,module,exports){
var _ = require("underscore");
var Backbone = require("base/backbone");
var $ = require("base/jQuery");
var Models = require("./models");
var Views = require("./views");
var sprintf = require("sprintf-js").sprintf;

TopicChannelRouter = Backbone.Router.extend({
    initialize: function(options) {
        _.bindAll(this, "navigate_default_channel", "intercept_learn_nav", "navigate_channel", "add_slug", "url_back", "navigate_splat", "set_page_title", "trigger_navigation_callback");
        this.default_channel = options.default_channel;
        $("#nav_learn").click(this.intercept_learn_nav);
    },

    routes: {
        "":   "navigate_default_channel",
        // This will catch any navigation events to other content items, and...
        ":channel/(*splat)":    "navigate_channel",
        // ...this will catch any other navigation events. We want to make sure
        // points are updated correctly in either case.
        "/(.*)/": "trigger_navigation_callback"
    },

    navigate_default_channel: function() {
        var addParam;
        if (window.location.toString().split("?").length > 1) {
            addParam = "?" + window.location.toString().split("?")[1];
        } else {
            addParam = "";
        }
        this.navigate(this.default_channel + "/" + addParam, {trigger: true, replace: true});
    },

    intercept_learn_nav: function(event){
        this.navigate(this.default_channel + "/", {trigger: true});
        return false;
    },

    navigate_channel: function(channel, splat) {
        if (this.channel!==channel) {
            this.control_view = new Views.SidebarView({
                channel: channel,
                entity_key: "children",
                entity_collection: Models.TopicCollection
            });
            this.channel = channel;
        }
        this.navigate_splat(splat);
    },

    add_slug: function(slug) {
        this.navigate(Backbone.history.getFragment() + slug + "/", {trigger: true});
    },

    url_back: function() {
        var current_url = Backbone.history.getFragment();
        var fragments = current_url.split("/").slice(0,-1);
        if (fragments.length > 0) {
            this.navigate(fragments.slice(0,-1).join("/") + "/", {trigger: true});
        }
    },

    navigate_splat: function(splat) {
        splat = splat || "/";
        if (splat.indexOf("/", splat.length - 1)==-1) {
            splat += "/";
            this.navigate(Backbone.history.getFragment() + "/");
        }
        this.control_view.navigate_paths(splat.split("/").slice(0,-1), this.set_page_title);
    },

    set_page_title: function(title) {
        document.title = document.title.replace(/(\w+)( |:[^|]*)(\|)/, sprintf("$1: %s $3", title));
    },

    trigger_navigation_callback: function() {
        this.trigger("navigation");
    }
});

module.exports = TopicChannelRouter;
},{"./models":115,"./views":117,"base/backbone":42,"base/jQuery":45,"sprintf-js":581,"underscore":582}],117:[function(require,module,exports){
var BaseView = require("base/baseview");
var _ = require("underscore");
var $ = require("base/jQuery");
require("jquery-slimscroll/jquery.slimscroll");
var Backbone = require("base/backbone");
var messages = require("utils/messages");
var $script = require("scriptjs");

require("../../../css/distributed/sidebar.less");

var ContentViews = require("content/views");
var Models = require("./models");

var RatingView = require("rating/views");
var RatingModels = require("rating/models");
var RatingModel = RatingModels.RatingModel;
var ContentRatingCollection = RatingModels.ContentRatingCollection;

// Views

var ContentAreaView = BaseView.extend({

    template: require("./hbtemplates/content-area.handlebars"),

    initialize: function() {
        this.model = new Backbone.Model();
        this.render();

        this.content_rating_collection = new ContentRatingCollection();
        var self = this;
        this.content_rating_collection.url = function() {
            return sessionModel.get("CONTENT_RATING_LIST_URL") + "/?" + $.param({
                "user": window.statusModel.get("user_id"),
                "content_kind": self.model.get("kind"),
                "content_id": self.model.get("id")
            });
        };
        this.listenTo(window.statusModel, "change:user_id", this.show_rating);
        _.bindAll(this, "show_rating");
    },

    render: function() {
        this.$el.html(this.template(this.model.attributes));
        return this;
    },

    show_view: function(view) {
        // hide any messages being shown for the old view
        messages.clear_messages();

        this.close();
        // set the new view as the current view
        this.currently_shown_view = view;

        // show the view
        this.$(".content").html("").append(view.$el);
    },

    should_show_rating: function() {
        /*
        This function determines whether a rating should be shown for the content item.
        returns: true or false
        */
        var entry_available = (typeof this.model !== "undefined") && !!this.model.get("available");
        var logged_in = window.statusModel.has("user_id");
        return logged_in && entry_available;
    },

    remove_rating_view: function() {
        // Remove the rating view if it exists.
        if (typeof this.rating_view !== "undefined") {
            this.rating_view.remove();
            delete this.rating_view;
        }
    },

    show_rating: function() {
        // First, determine whether we should show the rating at all.
        // If it should not be shown, be sure to remove the rating_view; subsequent logic depends on that.
        if ( !this.should_show_rating() ) {
            this.remove_rating_view();
            return;
        }

        // Secondly, if the rating_view is previously deleted or never shown before at all, then define it.
        if( typeof this.rating_view === "undefined" ) {
            this.rating_view = this.add_subview(RatingView, {});
            this.$("#rating-container-wrapper").append(this.rating_view.el);
        }

        // Finally, handle the actual display logic
        if( this.rating_view.model === null || this.rating_view.model.get("content_id") !== this.model.get("id") ) {
            var self = this;
            this.content_rating_collection.fetch().done(function(){
                // Queue up a save on the model we're about to switch out, in case it hasn't been synced.
                if (self.rating_view.model !== null && self.rating_view.model.hasChanged()) {
                    self.rating_view.model.debounced_save();
                }
                if(self.content_rating_collection.models.length === 1) {
                    self.rating_view.model = self.content_rating_collection.pop();
                    self.rating_view.render();
                } else if ( self.content_rating_collection.models.length === 0 ) {
                    self.rating_view.model = new RatingModel({
                            "user": window.statusModel.get("user_uri"),
                            "content_kind": self.model.get("kind"),
                            "content_id": self.model.get("id")
                    });
                    self.rating_view.render();
                } else {
                    messages.show_message("error", "Server Error: More than one rating found for this user and content item!", "too-many-ratings-msg");
                    self.remove_rating_view();
                }
            }).error(function(){
                console.log("content rating collection failed to fetch");
            });
        }
    },

    close: function() {
        // This does not actually close this view. If you *really* want to get rid of this view,
        // you should call .remove()!
        // This is to allow the child view currently_shown_view to act consistently with other
        // inner_views for the sidebar InnerTopicsView.
        if (this.currently_shown_view) {
            // try calling the close method if available, otherwise remove directly
            if (_.isFunction(this.currently_shown_view.close)) {
                this.currently_shown_view.close();
            } else {
                this.currently_shown_view.remove();
            }
        }
    }

});

var SidebarView = BaseView.extend({
    el: "#sidebar-container",
    template: require("./hbtemplates/sidebar.handlebars"),

    events: {
        "click .sidebar-tab": "toggle_sidebar",
        "click .sidebar-fade": "check_external_click",
        "click .sidebar-back": "sidebar_back_one_level"
    },

    initialize: function(options) {
        var self = this;
        var navbarCollapsed = true;

        // Fancy algorithm to run a resize sidebar when window width 
        // changes significantly (100px steps) to avoid unnecessary computation
        var windowWidth = $(window).width();
        $(window).on("resize", function() {
            newWindowWidth = $(window).width();
            if (Math.floor(newWindowWidth/100) != Math.floor(windowWidth/100)) {
                self.resize_sidebar();
                windowWidth = $(window).width();
            }

            if ($(window).width() > 768) {
                self.show_sidebar_tab();
            }

            else {
                if (navbarCollapsed) {
                    self.show_sidebar_tab();
                }
                else {
                    self.hide_sidebar_tab();   
                }
            }
        });

        $(".navbar-collapse").on("show.bs.collapse", function() {
            self.hide_sidebar_tab();
            navbarCollapsed = false;
        }).on("hide.bs.collapse", function() {
            self.show_sidebar_tab();
            navbarCollapsed = true;
        });

        this.entity_key = options.entity_key;
        this.entity_collection = options.entity_collection;

        this.channel = options.channel;

        this.state_model = new Backbone.Model({
            open: false,
            current_level: 0,
            channel: this.channel
        });

        this.render();

        this.listenTo(this.state_model, "change:open", this.update_sidebar_visibility);
        this.listenTo(this.state_model, "change:current_level", this.resize_sidebar);
    },

    render: function() {
        var self = this;

        this.$el.html(this.template());

        this.sidebar = this.$(".sidebar-panel");
        this.sidebarTab = this.$(".sidebar-tab");
        this.sidebarBack = this.$(".sidebar-back");

        _.defer(function() {
            self.show_sidebar();
        });

        this.topic_node_view = new TopicContainerOuterView({
            channel: this.channel,
            model: this.model,
            entity_key: this.entity_key,
            entity_collection: this.entity_collection,
            state_model: this.state_model
        });
        this.listenTo(this.topic_node_view, "hideSidebar", this.hide_sidebar);
        this.listenTo(this.topic_node_view, "showSidebar", this.show_sidebar);

        this.$('.sidebar-content').append(this.topic_node_view.el);

        this.set_sidebar_back();

        return this;
    },

    resize_sidebar: function() {
        if (this.state_model.get("open")) {
            if ($(window).width() < 1260) {
                this.resize_for_narrow();
            } else {
                this.resize_for_wide();
            }
        }
    },

    resize_for_narrow: _.debounce(function() {
        var current_level = this.state_model.get("current_level");
        var column_width = this.$(".topic-container-inner").width();
        var last_column_width = this.$(".topic-container-inner:last-child").width();
        // Hack to give the last child of .topic-container-inner to be 1.5 times the 
        // width of their parents. Also, sidebar overflow out of the left side of screen
        // is computed and set here.

        // THE magic variable that controls number of visible panels
        var numOfPanelsToShow = 4;

        if ($(window).width() < 1120)
            numOfPanelsToShow = 3;

        if ($(window).width() < 920)
            numOfPanelsToShow = 2;

        if ($(window).width() < 620)
            numOfPanelsToShow = 1;

        // Used to get left value in number form
        var sidebarPanelPosition = this.sidebar.position();
        var sidebarPanelLeft = sidebarPanelPosition.left;

        this.width = (current_level - 1) * column_width + last_column_width + 10;
        this.sidebar.width(this.width);
        var sidebarPanelNewLeft = -(column_width * (current_level - numOfPanelsToShow)) + this.sidebarBack.width();
        if (sidebarPanelNewLeft > 0) sidebarPanelNewLeft = 0;

        // Signature color flash (also hides a slight UI glitch)
        var originalBackColor = this.sidebarBack.css('background-color');
        this.sidebarBack.css('background-color', this.sidebarTab.css('background-color')).animate({'background-color': originalBackColor});
        
        var self = this;
        this.sidebar.animate({"left": sidebarPanelNewLeft}, 115, function() {
            self.set_sidebar_back();
        });

        this.sidebarTab.animate({left: this.sidebar.width() + sidebarPanelNewLeft}, 115);
    }, 100),

    // Pretty much the code for pre-back-button sidebar resize
    resize_for_wide: _.debounce(function() {
        var current_level = this.state_model.get("current_level");
        var column_width = this.$(".topic-container-inner").width();
        var last_column_width = 400;
        
        this.width = (current_level-1) * column_width + last_column_width + 10;
        this.sidebar.width(this.width);
        this.sidebar.css({left: 0});
        this.sidebarTab.css({left: this.width});
        
        this.set_sidebar_back();
    }, 100),

    check_external_click: function(ev) {
        if (this.state_model.get("open")) {
            this.state_model.set("open", false);
        }
    },

    toggle_sidebar: function(ev) {
        this.state_model.set("open", !this.state_model.get("open"));

        // TODO (rtibbles): Get render to only run after all listenTos have been bound and remove this.
        if (ev !== undefined) {
            ev.preventDefault();
        }
        return false;
    },

    update_sidebar_visibility: _.debounce(function() {
        if (this.state_model.get("open")) {
            // Used to get left value in number form
            var sidebarPanelPosition = this.sidebar.position();
            this.sidebar.css({left: 0});
            this.resize_sidebar();
            this.sidebarTab.css({left: this.sidebar.width() + sidebarPanelPosition.left}).html('<span class="icon-circle-left"></span>');
            this.$(".sidebar-fade").show();
        } else {
            this.sidebar.css({left: - this.width});
            this.sidebarTab.css({left: 0}).html('<span class="icon-circle-right"></span>');
            this.$(".sidebar-fade").hide();
        }

        this.set_sidebar_back();
    }, 100),

    set_sidebar_back: function() {
        if (!this.state_model.get("open")) {
            this.sidebarBack.offset({left: -(this.sidebarBack.width())});
            
            this.sidebarBack.hover(
            function() {
                $(this).addClass("sidebar-back-hover");
            },
            function() {
                $(this).removeClass("sidebar-back-hover");
            });

            return;
        }

        // Used to get left value in number form
        var sidebarPanelPosition = this.sidebar.position();
        if (sidebarPanelPosition.left !== 0) {
            this.sidebarBack.offset({left: 0});
        }
        else {
            this.sidebarBack.offset({left: -(this.sidebarBack.width())});
        }

        // Disable or enable the back button depending on whether it is visible or not.
        if (this.sidebarBack.position().left <= 0) {
            this.disable_back_button();
        } else {
            this.enable_back_button();
        }
    },

    enable_back_button: function() {
        this.sidebarBack.find("button").removeAttr("disabled");
    },

    disable_back_button: function() {
        this.sidebarBack.find("button").attr("disabled", "disabled");
    },

    sidebar_back_one_level: function() {
        this.topic_node_view.back_to_parent();
    },

    show_sidebar: function() {
        this.state_model.set("open", true);
    },

    hide_sidebar: function() {
        this.state_model.set("open", false);
    },

    show_sidebar_tab: function() {
        this.sidebarTab.fadeIn(115);
    },

    hide_sidebar_tab: function() {
        this.sidebarTab.fadeOut(115);
    },

    navigate_paths: function(paths, callback) {
        // Allow callback here to let the 'title' of the node be returned to the router
        // This will allow the title of the page to be updated during navigation events
        this.topic_node_view.defer_navigate_paths(paths, callback);
    }

});

var TopicContainerInnerView = BaseView.extend({
    className: "topic-container-inner",
    template: require("./hbtemplates/sidebar-content.handlebars"),

    initialize: function(options) {

        _.bindAll.apply(_, [this].concat(_.functions(this)));

        var self = this;

        this.state_model = options.state_model;
        this.entity_key = options.entity_key;
        this.entity_collection = options.entity_collection;
        this.level = options.level;
        this._entry_views = [];
        this.has_parent = options.has_parent;

        this.collection = new this.entity_collection({parent: this.model.get("id"), channel: this.state_model.get("channel")});

        this.collection.fetch().then(this.add_all_entries);

        this.state_model.set("current_level", options.level);

        // resize the scrollable part of sidebar to the page height
        $(window).resize(self.window_resize_callback);

        // When scrolling, increase the height of the element
        // until it fills up the sidebar panel
        $(window).scroll(self.window_scroll_callback);
    },

    window_scroll_callback: _.throttle(function() {
        var sidebarHeight = $(".sidebar-panel").height();
        var deltaHeight = $(window).scrollTop() + self.$(".slimScrollDiv, .sidebar").height();
        var height = Math.min(sidebarHeight, deltaHeight);
        self.$(".slimScrollDiv, .sidebar").height(height);
    }, 200),

    window_resize_callback: _.throttle(function() {
        var height = $(window).height();
        self.$(".slimScrollDiv, .sidebar").height(height);
    }, 200),

    render: function() {
        var self = this;

        this.$el.html(this.template(this.model.attributes));

        $(this.$(".sidebar")).slimScroll({
            color: "#083505",
            opacity: 0.2,
            size: "6px",
            distance: "1px",
            alwaysVisible: true
        });

        // Ensure these are called once in order to get the right size initially.
        _.defer( function() {
            self.window_resize_callback();
            self.window_scroll_callback();
        });

        return this;
    },

    add_new_entry: function(entry) {
        var view = new SidebarEntryView({model: entry});
        this.listenTo(view, "hideSidebar", this.hide_sidebar);
        this.listenTo(view, "showSidebar", this.show_sidebar);
        this._entry_views.push(view);
        this.$(".sidebar").append(view.render().$el);
    },

    add_all_entries: function() {
        this.render();
        this.collection.forEach(this.add_new_entry, this);
    },

    show: function() {
        this.$el.show();
    },

    hide: function() {
        this.$el.hide();
    },

    hide_sidebar: function() {
        this.trigger("hideSidebar");
    },

    show_sidebar: function() {
        this.trigger("showSidebar");
    },

    deferred_node_by_slug: function(slug, callback) {
        // Convenience method to return a node by a passed in slug
        if (this.collection.loaded === true) {
            this.node_by_slug(slug, callback);
        } else {
            var self = this;
            this.listenToOnce(this.collection, "sync", function() {self.node_by_slug(slug, callback);});
        }
    },

    node_by_slug: function(slug, callback) {
        callback(this.collection.findWhere({slug: slug}));
    },

    close: function() {
        _.each(this._entry_views, function(view) {
            view.model.set("active", false);
        });
        this.remove();
    }

});

var SidebarEntryView = BaseView.extend({

    tagName: "li",

    template: require("./hbtemplates/sidebar-entry.handlebars"),

    events: {
        "click": "clicked"
    },

    initialize: function() {

        _.bindAll(this, "render");

        this.listenTo(this.model, "change", this.render);

    },

    render: function() {
        this.$el.html(this.template(this.model.attributes));
        return this;
    },

    clicked: function(ev) {
        ev.preventDefault();
        if (!this.model.get("active")) {
            window.channel_router.navigate(this.model.get("path"), {trigger: true});
        } else if (this.model.get("kind") !== "Topic") {
            this.trigger("hideSidebar");
        }
        return false;
    }

});


var TopicContainerOuterView = BaseView.extend({

    initialize: function(options) {

        this.render = _.bind(this.render, this);

        this.state_model = options.state_model;

        this.entity_key = options.entity_key;
        this.entity_collection = options.entity_collection;

        this.model = new Models.TopicNode({"id": "root", "title": "Khan"});

        this.inner_views = [];
        this.render();
        this.content_view = new ContentAreaView({
            el: "#content-area"
        });

    },

    render: function() {
        this.show_new_topic(this.model);
        this.trigger("render_complete");
    },

    show_new_topic: function(node) {

        var new_topic = this.add_new_topic_view(node);

        this.$el.append(new_topic.el);

        this.trigger("inner_view_added");

        // Listeners
        this.listenTo(new_topic, 'hideSidebar', this.hide_sidebar);
        this.listenTo(new_topic, 'showSidebar', this.show_sidebar);
    },

    add_new_topic_view: function(node) {

        this.state_model.set("current_level", this.state_model.get("current_level") + 1);

        var data = {
            model: node,
            has_parent: this.inner_views.length >= 1,
            entity_key: this.entity_key,
            entity_collection: this.entity_collection,
            state_model: this.state_model,
            level: this.state_model.get("current_level")
        };

        var new_topic = new TopicContainerInnerView(data);

        this.inner_views.unshift(new_topic);

        this.trigger("length_" + this.inner_views.length);

        return new_topic;
    },

    defer_navigate_paths: function(paths, callback) {
        if (this.inner_views.length === 0){
            var self = this;
            this.listenToOnce(this, "render_complete", function() {self.navigate_paths(paths, callback);});
        } else {
            this.navigate_paths(paths, callback);
        }
    },

    navigate_paths: function(paths, callback) {

        var self = this;

        var check_views = [];
        for (var i = this.inner_views.length - 2; i >=0; i--) {
            check_views.push(this.inner_views[i]);
        }
        // Should only ever remove a bunch of inner_views once during the whole iteration
        var pruned = false;
        for (i = 0; i < paths.length; i++) {
            var check_view = check_views[i];
            if (paths[i]!=="") {
                if (check_view!==undefined) {
                    if (check_view.model.get("slug")==paths[i]) {
                        continue;
                    } else {
                        check_view.model.set("active", false);
                        if (!pruned) {
                            this.remove_topic_views(check_views.length - i);
                            pruned = true;
                        }
                    }
                }
                this.defer_add_topic(paths[i], i);
            } else if (!pruned) {
                if (check_view!==undefined) {
                    check_view.model.set("active", false);
                    this.remove_topic_views(check_views.length - i);
                }
            }
        }
        if (!pruned && (paths.length < check_views.length)) {
            // Double check that paths and check_views are the same length
            this.remove_topic_views(check_views.length - paths.length);
        }
        if (callback) {
            this.stopListening(this, "inner_view_added");

            this.listenTo(this, "inner_view_added", function() {
                callback(self.inner_views[0].model.get("title"));
            });
        }
    },

    defer_add_topic: function(path, view_length) {
        var self = this;
        if (this.inner_views.length==view_length + 1) {
            this.add_topic_from_inner_view(path);
        } else {
            this.listenToOnce(this, "length_" + (view_length + 1), function() {self.add_topic_from_inner_view(path);});
        }
    },

    add_topic_from_inner_view: function(path) {
        var self = this;

        this.inner_views[0].deferred_node_by_slug(path, function(node){
            if (node!==undefined) {
                if (node.get("kind")==="Topic") {
                    self.show_new_topic(node);
                } else {
                    self.entry_requested(node);
                }
                node.set("active", true);
            }
        });
    },

    remove_topic_views: function(number) {
        for (var i=0; i < number; i++) {
            if (this.inner_views[0]) {
                this.inner_views[0].model.set("active", false);
                if (_.isFunction(this.inner_views[0].close)) {
                    this.inner_views[0].close();
                } else {
                    this.inner_views[0].remove();
                }
                this.inner_views.shift();
            }
        }
        if (this.state_model.get("content_displayed")) {
            number--;
            this.state_model.set("content_displayed", false);
        }
        this.state_model.set("current_level", this.state_model.get("current_level") - number);
        this.show_sidebar();
    },

    back_to_parent: function() {
        window.channel_router.url_back();
    },

    entry_requested: function(entry) {
        var kind = entry.get("kind") || entry.get("entity_kind");
        var id = entry.get("id") || entry.get("entity_id");

        this.content_view.model = entry;
        // The rating subview depends on the content_view.model, but we can't just listen to events on the model
        // to trigger show_rating, since the actual object is swapped out here. We must call it explicitly.
        this.content_view.show_rating();
        var self = this;

        var view = new ContentViews.ContentWrapperView({
            id: id,
            kind: kind,
            context_id: this.model.get("id"),
            channel: window.channel_router.channel
        });

        this.content_view.show_view(view);

        this.inner_views.unshift(this.content_view);
        this.trigger("inner_view_added");
        this.state_model.set("content_displayed", true);
        this.hide_sidebar();
    },

    hide_sidebar: function() {
        this.trigger("hideSidebar");
    },

    show_sidebar: function() {
        this.trigger("showSidebar");
    }
});

module.exports = {
    SidebarView: SidebarView,
    SidebarEntryView: SidebarEntryView,
    TopicContainerInnerView: TopicContainerInnerView,
    TopicContainerOuterView: TopicContainerOuterView,
    ContentAreaView: ContentAreaView
};

},{"../../../css/distributed/sidebar.less":37,"./hbtemplates/content-area.handlebars":111,"./hbtemplates/sidebar-content.handlebars":112,"./hbtemplates/sidebar-entry.handlebars":113,"./hbtemplates/sidebar.handlebars":114,"./models":115,"base/backbone":42,"base/baseview":43,"base/jQuery":45,"content/views":50,"jquery-slimscroll/jquery.slimscroll":361,"rating/models":105,"rating/views":106,"scriptjs":571,"underscore":582,"utils/messages":128}],361:[function(require,module,exports){
/*! Copyright (c) 2011 Piotr Rochala (http://rocha.la)
 * Dual licensed under the MIT (http://www.opensource.org/licenses/mit-license.php)
 * and GPL (http://www.opensource.org/licenses/gpl-license.php) licenses.
 *
 * Version: 1.3.6
 *
 */
(function($) {

  $.fn.extend({
    slimScroll: function(options) {

      var defaults = {

        // width in pixels of the visible scroll area
        width : 'auto',

        // height in pixels of the visible scroll area
        height : '250px',

        // width in pixels of the scrollbar and rail
        size : '7px',

        // scrollbar color, accepts any hex/color value
        color: '#000',

        // scrollbar position - left/right
        position : 'right',

        // distance in pixels between the side edge and the scrollbar
        distance : '1px',

        // default scroll position on load - top / bottom / $('selector')
        start : 'top',

        // sets scrollbar opacity
        opacity : .4,

        // enables always-on mode for the scrollbar
        alwaysVisible : false,

        // check if we should hide the scrollbar when user is hovering over
        disableFadeOut : false,

        // sets visibility of the rail
        railVisible : false,

        // sets rail color
        railColor : '#333',

        // sets rail opacity
        railOpacity : .2,

        // whether  we should use jQuery UI Draggable to enable bar dragging
        railDraggable : true,

        // defautlt CSS class of the slimscroll rail
        railClass : 'slimScrollRail',

        // defautlt CSS class of the slimscroll bar
        barClass : 'slimScrollBar',

        // defautlt CSS class of the slimscroll wrapper
        wrapperClass : 'slimScrollDiv',

        // check if mousewheel should scroll the window if we reach top/bottom
        allowPageScroll : false,

        // scroll amount applied to each mouse wheel step
        wheelStep : 20,

        // scroll amount applied when user is using gestures
        touchScrollStep : 200,

        // sets border radius
        borderRadius: '7px',

        // sets border radius of the rail
        railBorderRadius : '7px'
      };

      var o = $.extend(defaults, options);

      // do it for every element that matches selector
      this.each(function(){

      var isOverPanel, isOverBar, isDragg, queueHide, touchDif,
        barHeight, percentScroll, lastScroll,
        divS = '<div></div>',
        minBarHeight = 30,
        releaseScroll = false;

        // used in event handlers and for better minification
        var me = $(this);

        // ensure we are not binding it again
        if (me.parent().hasClass(o.wrapperClass))
        {
            // start from last bar position
            var offset = me.scrollTop();

            // find bar and rail
            bar = me.closest('.' + o.barClass);
            rail = me.closest('.' + o.railClass);

            getBarHeight();

            // check if we should scroll existing instance
            if ($.isPlainObject(options))
            {
              // Pass height: auto to an existing slimscroll object to force a resize after contents have changed
              if ( 'height' in options && options.height == 'auto' ) {
                me.parent().css('height', 'auto');
                me.css('height', 'auto');
                var height = me.parent().parent().height();
                me.parent().css('height', height);
                me.css('height', height);
              }

              if ('scrollTo' in options)
              {
                // jump to a static point
                offset = parseInt(o.scrollTo);
              }
              else if ('scrollBy' in options)
              {
                // jump by value pixels
                offset += parseInt(o.scrollBy);
              }
              else if ('destroy' in options)
              {
                // remove slimscroll elements
                bar.remove();
                rail.remove();
                me.unwrap();
                return;
              }

              // scroll content by the given offset
              scrollContent(offset, false, true);
            }

            return;
        }
        else if ($.isPlainObject(options))
        {
            if ('destroy' in options)
            {
            	return;
            }
        }

        // optionally set height to the parent's height
        o.height = (o.height == 'auto') ? me.parent().height() : o.height;

        // wrap content
        var wrapper = $(divS)
          .addClass(o.wrapperClass)
          .css({
            position: 'relative',
            overflow: 'hidden',
            width: o.width,
            height: o.height
          });

        // update style for the div
        me.css({
          overflow: 'hidden',
          width: o.width,
          height: o.height
        });

        // create scrollbar rail
        var rail = $(divS)
          .addClass(o.railClass)
          .css({
            width: o.size,
            height: '100%',
            position: 'absolute',
            top: 0,
            display: (o.alwaysVisible && o.railVisible) ? 'block' : 'none',
            'border-radius': o.railBorderRadius,
            background: o.railColor,
            opacity: o.railOpacity,
            zIndex: 90
          });

        // create scrollbar
        var bar = $(divS)
          .addClass(o.barClass)
          .css({
            background: o.color,
            width: o.size,
            position: 'absolute',
            top: 0,
            opacity: o.opacity,
            display: o.alwaysVisible ? 'block' : 'none',
            'border-radius' : o.borderRadius,
            BorderRadius: o.borderRadius,
            MozBorderRadius: o.borderRadius,
            WebkitBorderRadius: o.borderRadius,
            zIndex: 99
          });

        // set position
        var posCss = (o.position == 'right') ? { right: o.distance } : { left: o.distance };
        rail.css(posCss);
        bar.css(posCss);

        // wrap it
        me.wrap(wrapper);

        // append to parent div
        me.parent().append(bar);
        me.parent().append(rail);

        // make it draggable and no longer dependent on the jqueryUI
        if (o.railDraggable){
          bar.bind("mousedown", function(e) {
            var $doc = $(document);
            isDragg = true;
            t = parseFloat(bar.css('top'));
            pageY = e.pageY;

            $doc.bind("mousemove.slimscroll", function(e){
              currTop = t + e.pageY - pageY;
              bar.css('top', currTop);
              scrollContent(0, bar.position().top, false);// scroll content
            });

            $doc.bind("mouseup.slimscroll", function(e) {
              isDragg = false;hideBar();
              $doc.unbind('.slimscroll');
            });
            return false;
          }).bind("selectstart.slimscroll", function(e){
            e.stopPropagation();
            e.preventDefault();
            return false;
          });
        }

        // on rail over
        rail.hover(function(){
          showBar();
        }, function(){
          hideBar();
        });

        // on bar over
        bar.hover(function(){
          isOverBar = true;
        }, function(){
          isOverBar = false;
        });

        // show on parent mouseover
        me.hover(function(){
          isOverPanel = true;
          showBar();
          hideBar();
        }, function(){
          isOverPanel = false;
          hideBar();
        });

        // support for mobile
        me.bind('touchstart', function(e,b){
          if (e.originalEvent.touches.length)
          {
            // record where touch started
            touchDif = e.originalEvent.touches[0].pageY;
          }
        });

        me.bind('touchmove', function(e){
          // prevent scrolling the page if necessary
          if(!releaseScroll)
          {
  		      e.originalEvent.preventDefault();
		      }
          if (e.originalEvent.touches.length)
          {
            // see how far user swiped
            var diff = (touchDif - e.originalEvent.touches[0].pageY) / o.touchScrollStep;
            // scroll content
            scrollContent(diff, true);
            touchDif = e.originalEvent.touches[0].pageY;
          }
        });

        // set up initial height
        getBarHeight();

        // check start position
        if (o.start === 'bottom')
        {
          // scroll content to bottom
          bar.css({ top: me.outerHeight() - bar.outerHeight() });
          scrollContent(0, true);
        }
        else if (o.start !== 'top')
        {
          // assume jQuery selector
          scrollContent($(o.start).position().top, null, true);

          // make sure bar stays hidden
          if (!o.alwaysVisible) { bar.hide(); }
        }

        // attach scroll events
        attachWheel(this);

        function _onWheel(e)
        {
          // use mouse wheel only when mouse is over
          if (!isOverPanel) { return; }

          var e = e || window.event;

          var delta = 0;
          if (e.wheelDelta) { delta = -e.wheelDelta/120; }
          if (e.detail) { delta = e.detail / 3; }

          var target = e.target || e.srcTarget || e.srcElement;
          if ($(target).closest('.' + o.wrapperClass).is(me.parent())) {
            // scroll content
            scrollContent(delta, true);
          }

          // stop window scroll
          if (e.preventDefault && !releaseScroll) { e.preventDefault(); }
          if (!releaseScroll) { e.returnValue = false; }
        }

        function scrollContent(y, isWheel, isJump)
        {
          releaseScroll = false;
          var delta = y;
          var maxTop = me.outerHeight() - bar.outerHeight();

          if (isWheel)
          {
            // move bar with mouse wheel
            delta = parseInt(bar.css('top')) + y * parseInt(o.wheelStep) / 100 * bar.outerHeight();

            // move bar, make sure it doesn't go out
            delta = Math.min(Math.max(delta, 0), maxTop);

            // if scrolling down, make sure a fractional change to the
            // scroll position isn't rounded away when the scrollbar's CSS is set
            // this flooring of delta would happened automatically when
            // bar.css is set below, but we floor here for clarity
            delta = (y > 0) ? Math.ceil(delta) : Math.floor(delta);

            // scroll the scrollbar
            bar.css({ top: delta + 'px' });
          }

          // calculate actual scroll amount
          percentScroll = parseInt(bar.css('top')) / (me.outerHeight() - bar.outerHeight());
          delta = percentScroll * (me[0].scrollHeight - me.outerHeight());

          if (isJump)
          {
            delta = y;
            var offsetTop = delta / me[0].scrollHeight * me.outerHeight();
            offsetTop = Math.min(Math.max(offsetTop, 0), maxTop);
            bar.css({ top: offsetTop + 'px' });
          }

          // scroll content
          me.scrollTop(delta);

          // fire scrolling event
          me.trigger('slimscrolling', ~~delta);

          // ensure bar is visible
          showBar();

          // trigger hide when scroll is stopped
          hideBar();
        }

        function attachWheel(target)
        {
          if (window.addEventListener)
          {
            target.addEventListener('DOMMouseScroll', _onWheel, false );
            target.addEventListener('mousewheel', _onWheel, false );
          }
          else
          {
            document.attachEvent("onmousewheel", _onWheel)
          }
        }

        function getBarHeight()
        {
          // calculate scrollbar height and make sure it is not too small
          barHeight = Math.max((me.outerHeight() / me[0].scrollHeight) * me.outerHeight(), minBarHeight);
          bar.css({ height: barHeight + 'px' });

          // hide scrollbar if content is not long enough
          var display = barHeight == me.outerHeight() ? 'none' : 'block';
          bar.css({ display: display });
        }

        function showBar()
        {
          // recalculate bar height
          getBarHeight();
          clearTimeout(queueHide);

          // when bar reached top or bottom
          if (percentScroll == ~~percentScroll)
          {
            //release wheel
            releaseScroll = o.allowPageScroll;

            // publish approporiate event
            if (lastScroll != percentScroll)
            {
                var msg = (~~percentScroll == 0) ? 'top' : 'bottom';
                me.trigger('slimscroll', msg);
            }
          }
          else
          {
            releaseScroll = false;
          }
          lastScroll = percentScroll;

          // show only when required
          if(barHeight >= me.outerHeight()) {
            //allow window scroll
            releaseScroll = true;
            return;
          }
          bar.stop(true,true).fadeIn('fast');
          if (o.railVisible) { rail.stop(true,true).fadeIn('fast'); }
        }

        function hideBar()
        {
          // only hide when options allow it
          if (!o.alwaysVisible)
          {
            queueHide = setTimeout(function(){
              if (!(o.disableFadeOut && isOverPanel) && !isOverBar && !isDragg)
              {
                bar.fadeOut('slow');
                rail.fadeOut('slow');
              }
            }, 1000);
          }
        }

      });

      // maintain chainability
      return this;
    }
  });

  $.fn.extend({
    slimscroll: $.fn.slimScroll
  });

})(jQuery);

},{}],115:[function(require,module,exports){
var Backbone = require("base/backbone");
var get_params = require("utils/get_params");
var sprintf = require("sprintf-js").sprintf;

// Models
var TopicNode = Backbone.Model.extend({

    initialize: function(options) {
        
        if (this.get("entity_kind")===undefined && this.get("kind")!==undefined){
            this.set("entity_kind", this.get("kind"));
        }
    }
});

// Collections
var TopicCollection = Backbone.Collection.extend({
    model: TopicNode,

    initialize: function(options) {

        var self = this;
        
        this.parent = options.parent;

        this.channel = options.channel;

        this.listenToOnce(this, "sync", function() {self.loaded = true;});
    },

    url: function() {
        return ("ALL_TOPICS_URL" in window)? get_params.setGetParam(sprintf(ALL_TOPICS_URL, {channel_name: this.channel}), "parent", this.parent) : null;
    }
});

module.exports = {
    TopicNode: TopicNode,
    TopicCollection: TopicCollection
};
},{"base/backbone":42,"sprintf-js":581,"utils/get_params":127}],114:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "";


  buffer += "<div class=\"sidebar-tab\"></div>\n\n<nav class=\"sidebar-panel\" role=\"navigation\" aria-label=\"Topic sidebar menu\">\n    \n    <div class=\"sidebar-back\">\n        <button class=\"simple-button green glyphicon glyphicon-arrow-left\"></button>\n    </div>\n    <div class=\"sidebar-content\"></div>\n</nav>\n\n<div class=\"sidebar-fade\"></div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],113:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n<span class=\"sidebar-entry sidebar-divider\">";
  if (helper = helpers.entity_id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.entity_id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n<a class=\"sidebar-entry sidebar-entry-link ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.active), {hash:{},inverse:self.noop,fn:self.program(4, program4, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += " ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.available), {hash:{},inverse:self.noop,fn:self.program(6, program6, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\" href=\"#\" title=\"";
  if (helper = helpers.description) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.description); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">\n    <div class=\"sidebar-entry-header\">\n\n        <span class=\"sidebar-icon icon-";
  if (helper = helpers.entity_kind) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.entity_kind); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" data-content-id=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"></span>\n        <span class=\"sidebar-title\" data-content-id=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n    </div>\n\n    ";
  stack1 = helpers.unless.call(depth0, (depth0 && depth0.organization), {hash:{},inverse:self.program(10, program10, data),fn:self.program(8, program8, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n    <span class=\"sidebar-description sidebar-topic-description\" data-content-id=\"";
  if (helper = helpers.id) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.id); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\">";
  stack1 = (helper = helpers.truncate || (depth0 && depth0.truncate),options={hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.description), 100, options) : helperMissing.call(depth0, "truncate", (depth0 && depth0.description), 100, options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "</span>\n</a>\n";
  return buffer;
  }
function program4(depth0,data) {
  
  
  return "active-entry";
  }

function program6(depth0,data) {
  
  
  return "missing";
  }

function program8(depth0,data) {
  
  
  return "\n        <span class=\"sidebar-space-holder\">  </span>\n    ";
  }

function program10(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n        <span class=\"sidebar-organization\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "by:", options) : helperMissing.call(depth0, "_", "by:", options)))
    + " ";
  if (helper = helpers.organization) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.organization); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n    ";
  return buffer;
  }

function program12(depth0,data) {
  
  var buffer = "";
  return buffer;
  }

  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.program(3, program3, data),fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.entity_kind), "==", "Divider", options) : helperMissing.call(depth0, "ifcond", (depth0 && depth0.entity_kind), "==", "Divider", options));
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  });

},{"hbsfy/runtime":354}],112:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  


  return "<ul class=\"sidebar\">\n\n</ul>";
  });

},{"hbsfy/runtime":354}],111:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "";


  buffer += "\n<div class=\"content\"></div>\n<div id=\"rating-container-wrapper\" class=\"container\"></div>";
  return buffer;
  });

},{"hbsfy/runtime":354}],106:[function(require,module,exports){
var Backbone = require("../base/backbone");
var $ = require("../base/jQuery");
var _ = require("underscore");
var BaseView = require("../base/baseview");
var Handlebars = require("../base/handlebars");

/*
    Container view for feedback form.
    See the design document here: https://docs.google.com/a/learningequality.org/document/d/1W_2vv1cZU5wZp_MLjvPy6jHwkRVPW_iTJhHEpSOYrCs/edit?usp=drive_web
*/
module.exports = BaseView.extend({

    template: require("./hbtemplates/rating.handlebars"),

    events: {
        "click .rating-delete": "delete_callback"
    },

    initialize: function(options) {
        /*
            Prepare self and subviews.
        */
        this.model = options.model || null;
        _.bindAll(this, "delete_callback", "renderAll", "renderSequence", "render");
        this.quality_label_values = {
            1:  gettext("Poor quality"),
            2:  gettext("Somewhat poor"),
            3:  gettext("Average"),
            4:  gettext("Somewhat high"),
            5:  gettext("High quality")
        };
        this.difficulty_label_values = {
            1:  gettext("Very easy"),
            2:  gettext("Easy"),
            3:  gettext("Average"),
            4:  gettext("Hard"),
            5:  gettext("Very hard")
        };
    },

    render: function() {
        /*
            If the model is new (never been synced) or empty (such as if it was deleted) render each component in
            sequence. Otherwise, render all components together, for review.
        */
        if( this.model.isNew() || this.model.get("quality") === 0 || this.model.get("difficulty") === 0) {
            this.renderSequence();
        } else {
            this.renderAll();
        }
    },

    renderSequence: function() {
        /*
            Present each rating widget one by one, waiting for user interaction before growing to show the next.
            Then once the user has filled out the rating completely, call renderAll to allow review/editing.
        */
        this.$el.html(this.template());
        this.$(".rating-delete").hide();

        this.star_view_quality = this.add_subview(StarView, {title: gettext("Quality"), el: this.$("#star-container-quality"), model: this.model, rating_attr: "quality", label_values: this.quality_label_values});

        var self = this;
        var callback = function() {
            self.star_view_difficulty = self.add_subview(StarView, {title: gettext("Difficulty"), el: self.$("#star-container-difficulty"), model: self.model, rating_attr: "difficulty", label_values: this.difficulty_label_values});
            self.$(".rating-delete").show();
        };
        // If the "quality" is already set, display "difficulty" immediately. Otherwise wait.
        if (!this.model.get("quality") || parseInt(this.model.get("quality")) === 0) {
            this.listenToOnce(this.model, "change:quality", callback);
        } else {
            callback();
        }

        this.listenToOnce(this.model, "change:difficulty", this.renderAll);

    },

    renderAll: function() {
        /*
            Renders itself, then attaches all subviews.
            Called when: 1) The view's model is fetched successfully or
                         2) The view's model is not fetched, and the user finishes filling out the new form.
        */
        this.$el.html(this.template());
        var views_and_opts = [
            ["star_view_quality", StarView, {title: gettext("Quality"), el: this.$("#star-container-quality"), model: this.model, rating_attr: "quality", label_values: this.quality_label_values}],
            ["star_view_difficulty", StarView, {title: gettext("Difficulty"), el: this.$("#star-container-difficulty"), model: this.model, rating_attr: "difficulty", label_values: this.difficulty_label_values}],
            ["text_view", TextView, {el: this.$("#text-container"), model: this.model}]
        ];
        var self = this;
        _.each(views_and_opts, function(el, ind, list){
            self[el[0]] = self.add_subview(el[1], el[2]);
        });
    },

    delete_callback: function() {
        var self = this;
        this.$el.html("Deleting your review...");
        // Don't simply clear & destroy the model, we wish to remember some attributes (like content_kind and user_uri)
        this.model.save({
            quality: 0,
            difficulty: 0,
            text: ""
        },
        {
            error: function(){
                console.log("failed to clear rating model attributes...");
            },
            success: function(){
                self.renderSequence();
            },
            patch: true
        });
    }
});


/*
    Widget to rate something from 1 to 5 stars.
*/
var StarView = BaseView.extend({

    template: require("./hbtemplates/star.handlebars"),

    events: {
        "click .star-rating-option": "rate_value_callback",
        "click .star-rating-option >": "rate_value_callback",
        "mouseenter .star-rating-option >": "mouse_enter_callback",
        "mouseenter .star-rating-option": "mouse_enter_callback",
        "mouseleave .star-rating-option": "mouse_leave_callback"
    },

    label_values: {
        1: gettext("Very Low"),
        2: gettext("Low"),
        3: gettext("Normal"),
        4: gettext("High"),
        5: gettext("Very High")
    },

    initialize: function(options) {
        this.model = options.model || new Backbone.Model();
        this.title = options.title || "";
        this.label_values = options.label_values || this.label_values;
        this.rating_attr = options.rating_attr || "rating";
        _.bindAll(this, "rate_value_callback", "rating_change");

        this.model.on("change:"+this.rating_attr, this.rating_change);

        this.render();
    },

    render: function() {
        var template_options = {};
        _.extend(template_options, this.model.attributes, {title: this.title, lowest_value: this.label_values[1], highest_value: this.label_values[5]});
        this.$el.html(this.template(template_options));
        this.rating_change();
    },

    // Debounced with immediate=true option, so that it's triggered _at most_ once per 100 ms, since it
    //   could be called by clicking on a child element as well.
    rate_value_callback: _.debounce(function(ev) {
        // The target event could be either the .star-rating-option or a child element, so whatever the case get the
        // parent .star-rating-option element.
        var target = $(ev.target).hasClass("star-rating-option") ? $(ev.target) : $(ev.target).parents(".star-rating-option")[0];
        var val = $(target).attr("data-val");
        this.model.set(this.rating_attr, val);
        this.model.debounced_save();
    }, 100, true),

    mouse_enter_callback: function(ev) {
        // The target event could be either the .star-rating-option or a child element, so whatever the case get the
        // parent .star-rating-option element.
        var target = $(ev.target).hasClass("star-rating-option") ? $(ev.target) : $(ev.target).parents(".star-rating-option")[0];
        var val = $(target).attr("data-val");
        this.$(".rating-label").text(this.label_values[val]);
    },

    mouse_leave_callback: function(ev) {
        this.$(".rating-label").text("");
    },

    rating_change: function() {
        opts = this.$(".star-rating-option");
        _.each(opts, function(opt, index, list) {
            $opt = $(opt);
            $opt.toggleClass("activated", parseInt($opt.attr("data-val")) <= parseInt(this.model.get(this.rating_attr)));
        }, this);
    }
});


/*
    Widget to accept/display free-form text input.
*/
var TextView = BaseView.extend({

    template: require("./hbtemplates/text.handlebars"),

    events: {
        "keyup .rating-text-feedback": "text_changed"
    },

    initialize: function(options) {
        this.model = options.model || new Backbone.Model();
        _.bindAll(this, "text_changed");
        this.model.on("change:text", this.text_changed);
        this.render();
    },

    render: function() {
        this.$el.html(this.template(this.model.attributes));
        return this;
    },

    text_changed: function() {
        this.model.set("text", this.$(".rating-text-feedback")[0].value);
        this.model.debounced_save();
    }
});

},{"../base/backbone":42,"../base/baseview":43,"../base/handlebars":44,"../base/jQuery":45,"./hbtemplates/rating.handlebars":102,"./hbtemplates/star.handlebars":103,"./hbtemplates/text.handlebars":104,"underscore":582}],105:[function(require,module,exports){
var Backbone = require("../base/backbone");

var RatingModel = Backbone.Model.extend({
    urlRoot: "/api/content_rating",

    initialize: function(){
        _.bindAll(this, "debounced_save");
    },

    debounced_save: _.debounce(function(){
        this.save();
    }, 2000)
});

var ContentRatingCollection = Backbone.Collection.extend({
    model: RatingModel
});

module.exports = {
    "RatingModel": RatingModel,
    "ContentRatingCollection": ContentRatingCollection
};

},{"../base/backbone":42}],104:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function";


  buffer += "<div class=\"container\">\r\n    <div class=\"row\">\r\n        <label class=\"text-feedback-label col-md-2 col-md-offset-2 col-xs-12\"><h3>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Your comments:", options) : helperMissing.call(depth0, "_", "Your comments:", options)))
    + "</h3></label>\r\n    </div>\r\n    <div class=\"row\">\r\n        <textarea class=\"form-control rating-text-feedback col-xs-8 col-xs-offset-2\">";
  if (helper = helpers.text) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.text); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</textarea>\r\n    </div>\r\n</div>";
  return buffer;
  });

},{"hbsfy/runtime":354}],103:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, functionType="function", escapeExpression=this.escapeExpression;


  buffer += "<center class=\"star-rating-inner-wrapper\">\r\n    <h2><span class=\"star-title-label label label-default\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span></h2>\r\n\r\n    <div class=\"row rating-row\">\r\n        <div class=\"col-md-1 col-md-offset-3 lowest-label\">";
  if (helper = helpers.lowest_value) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.lowest_value); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\r\n\r\n        <div class=\"col-md-4\">\r\n            <div class=\"star-rating-option btn btn-star\" data-val=\"1\">\r\n                <span class=\"glyphicon glyphicon-star-empty\"></span>\r\n            </div>\r\n            <div class=\"star-rating-option btn btn-star\" data-val=\"2\">\r\n                <span class=\"glyphicon glyphicon-star-empty\"></span>\r\n            </div>\r\n            <div class=\"star-rating-option btn btn-star\" data-val=\"3\">\r\n                <span class=\"glyphicon glyphicon-star-empty\"></span>\r\n            </div>\r\n            <div class=\"star-rating-option btn btn-star\" data-val=\"4\">\r\n                <span class=\"glyphicon glyphicon-star-empty\"></span>\r\n            </div>\r\n            <div class=\"star-rating-option btn btn-star\" data-val=\"5\">\r\n                <span class=\"glyphicon glyphicon-star-empty\"></span>\r\n            </div>\r\n        </div>\r\n\r\n        <div class=\"col-md-1 highest-label\">";
  if (helper = helpers.highest_value) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.highest_value); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\r\n    </div>\r\n\r\n    <div class=\"rating-label center-block\"></div>\r\n</center>";
  return buffer;
  });

},{"hbsfy/runtime":354}],102:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", helper, options, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression;


  buffer += "<div id=\"rating-container\" class=\"row\">\r\n    <div class=\"col-xs-12\">\r\n        <div class=\"panel panel-kalite-rating\">\r\n            <div class=\"row panel-heading\">\r\n                <div class=\"col-md-8\">\r\n                    <h1 class=\"panel-title\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "What did you think?", options) : helperMissing.call(depth0, "_", "What did you think?", options)))
    + "</h1>\r\n                    <span>"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Your feedback will help us make better content for future learners!", options) : helperMissing.call(depth0, "_", "Your feedback will help us make better content for future learners!", options)))
    + "</span>\r\n                </div>\r\n                <div class=\"col-md-2 col-md-offset-2\">\r\n                    <div class=\"btn btn-danger rating-delete\"><span class=\"glyphicon glyphicon-trash\"></span> "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Delete my review", options) : helperMissing.call(depth0, "_", "Delete my review", options)))
    + "</div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel-body\">\r\n                <div id=\"star-container-quality\">\r\n                    <!--star.handlebars will be rendered here.-->\r\n                </div>\r\n                <div id=\"star-container-difficulty\">\r\n                    <!-- star-container-2. Same deal. -->\r\n                </div>\r\n                <div id=\"text-container\">\r\n                    <!--text-container. Uses text.handlebars.-->\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n</div>";
  return buffer;
  });

},{"hbsfy/runtime":354}],50:[function(require,module,exports){
var _ = require("underscore");
var BaseView = require("base/baseview");
var Handlebars = require("base/handlebars");
var Models = require("./models");
var VideoModels = require("video/models");
var $script = require("scriptjs");

var ContentBaseView = require("./baseview");
var ExerciseModels = require("exercises/models");

require("../../../css/distributed/content.less");

var ContentWrapperView = BaseView.extend({

    events: {
        "click .download-link": "set_full_progress"
    },

    template: require("./hbtemplates/content-wrapper.handlebars"),

    initialize: function(options) {

        _.bindAll(this, "user_data_loaded", "set_full_progress", "render", "add_content_view", "setup_content_environment");

        var self = this;

        // load the info about the content itself
        if (options.kind == "Exercise") {
            this.data_model = new ExerciseModels.ExerciseDataModel({id: options.id, channel: options.channel});
        } else {
            this.data_model = new Models.ContentDataModel({id: options.id, channel: options.channel});
        }

        if (this.data_model.get("id")) {
            this.data_model.fetch().then(function() {
                window.statusModel.loaded.then(self.setup_content_environment);
            });
        }
    },

    setup_content_environment: function() {

        // This is a hack to support the legacy VideoLog, separate from other ContentLog
        // TODO-BLOCKER (rtibbles) 0.14: Remove this

        if (this.data_model.get("kind") == "Video") {
            LogCollection = VideoModels.VideoLogCollection;
        } else if (this.data_model.get("kind") == "Exercise") {
            LogCollection = ExerciseModels.ExerciseLogCollection;
        } else {
            LogCollection = Models.ContentLogCollection;
        }

        this.log_collection = new LogCollection([], {content_model: this.data_model});

        if (window.statusModel.get("is_logged_in")) {

            this.log_collection.fetch().then(this.user_data_loaded);

        } else {
            this.user_data_loaded();
        }

        this.listenToOnce(window.statusModel, "change:is_logged_in", this.setup_content_environment);

    },

    user_data_loaded: function() {
        this.log_model = this.log_collection.get_first_log_or_new_log();
        this.render();
    },

    set_full_progress: function() {
        if (this.data_model.get("kind") === "Document" && !("PDFJS" in window)) {
            this.content_view.set_progress(1);
            this.content_view.log_model.save();
        }
    },

    render: function() {

        this.$el.html(this.template(this.data_model.attributes));

        // Do this to prevent browserify from bundling what we want to be external dependencies.
        var external = require;

        var self = this;

        switch(this.data_model.get("kind")) {

            case "Audio":
                $script(window.sessionModel.get("STATIC_URL") + "js/distributed/bundles/bundle_audio.js", function(){
                    self.add_content_view(external("audio").AudioPlayerView);
                });
                break;

            case "Document":
                if ("PDFJS" in window) {
                    $script(window.sessionModel.get("STATIC_URL") + "js/distributed/bundles/bundle_document.js", function(){
                        self.add_content_view(external("document").PDFViewerView);
                    });
                } else {
                    self.add_content_view(ContentBaseView);
                }
                break;

            case "Video":
                $script(window.sessionModel.get("STATIC_URL") + "js/distributed/bundles/bundle_video.js", function(){
                    self.add_content_view(external("video").VideoPlayerView);
                });
                break;

            case "Exercise":
                $script(window.sessionModel.get("STATIC_URL") + "js/distributed/bundles/bundle_exercise.js", function(){
                    self.add_content_view(external("exercise").ExercisePracticeView);
                });
                break;

        }
    },

    add_content_view: function(ContentView) {

        this.content_view = this.add_subview(ContentView, {
            data_model: this.data_model,
            log_model: this.log_model
        });

        this.content_view.render();

        this.$(".content-player-container").append(this.content_view.el);

        this.points_view = this.add_subview(ContentPointsView, {
            model: this.log_model
        });

        this.points_view.render();

        this.$(".points-wrapper").append(this.points_view.el);

        this.log_model.set("views", this.log_model.get("views") + 1);
    }

});

var ContentPointsView = BaseView.extend({

    template: require("./hbtemplates/content-points.handlebars"),

    initialize: function() {
        this.starting_points = this.model.get("points") || 0;
        this.listenTo(this.model, "change", this.render);
    },

    render: function() {
        this.$el.html(this.template(this.model.attributes));
        window.statusModel.update_total_points(this.model.get("points") - this.starting_points);
        this.starting_points = this.model.get("points");
    }
});

module.exports = {
    ContentWrapperView: ContentWrapperView,
    ContentPointsView: ContentPointsView
};

},{"../../../css/distributed/content.less":30,"./baseview":46,"./hbtemplates/content-points.handlebars":47,"./hbtemplates/content-wrapper.handlebars":48,"./models":49,"base/baseview":43,"base/handlebars":44,"exercises/models":67,"scriptjs":571,"underscore":582,"video/models":132}],132:[function(require,module,exports){
var ContentModels = require("content/models");


var VideoLogModel = ContentModels.ContentLogModel.extend({

    urlRoot: function() {
        return window.sessionModel.get("GET_VIDEO_LOGS_URL");
    }

});

var VideoLogCollection = ContentModels.ContentLogCollection.extend({

    model: VideoLogModel,

    model_id_key: "video_id"

});

module.exports = {
	VideoLogModel: VideoLogModel,
	VideoLogCollection: VideoLogCollection
};
},{"content/models":49}],48:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var buffer = "", stack1, helper, options, functionType="function", escapeExpression=this.escapeExpression, helperMissing=helpers.helperMissing, self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                        <a href=\""
    + escapeExpression(((stack1 = ((stack1 = (depth0 && depth0.content_urls)),stack1 == null || stack1 === false ? stack1 : stack1.stream)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" class=\"btn btn-primary download-link pull-right\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Open PDF Reader", options) : helperMissing.call(depth0, "_", "Open PDF Reader", options)))
    + "</a>\n                        ";
  return buffer;
  }

function program3(depth0,data) {
  
  var buffer = "", stack1;
  buffer += "\n                    <h3>\n                        <select class=\"content-language-selector\">\n                            ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.availability), {hash:{},inverse:self.noop,fn:self.programWithDepth(4, program4, data, depth0),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        </select>\n                    </h3>\n                    ";
  return buffer;
  }
function program4(depth0,data,depth1) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                            <option value=\""
    + escapeExpression(((stack1 = (data == null || data === false ? data : data.key)),typeof stack1 === functionType ? stack1.apply(depth0) : stack1))
    + "\" ";
  stack1 = (helper = helpers.ifcond || (depth1 && depth1.ifcond),options={hash:{},inverse:self.noop,fn:self.program(5, program5, data),data:data},helper ? helper.call(depth0, (data == null || data === false ? data : data.key), "==", (depth1 && depth1.selected_language), options) : helperMissing.call(depth0, "ifcond", (data == null || data === false ? data : data.key), "==", (depth1 && depth1.selected_language), options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += ">\n                                ";
  if (helper = helpers.language_name) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.language_name); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\n                            </option>\n                            ";
  return buffer;
  }
function program5(depth0,data) {
  
  
  return "selected";
  }

function program7(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                        <span class=\"organization\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "by:", options) : helperMissing.call(depth0, "_", "by:", options)))
    + " ";
  if (helper = helpers.organization) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.organization); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                    ";
  return buffer;
  }

function program9(depth0,data) {
  
  var buffer = "", stack1, helper;
  buffer += "\n                    <div class=\"content-description\">";
  if (helper = helpers.description) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.description); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</div>\n                    ";
  return buffer;
  }

function program11(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <div class=\"panel-footer\">\n                    <h3>\n                        "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Related content:", options) : helperMissing.call(depth0, "_", "Related content:", options)))
    + "\n                    </h3>\n                    <div class=\"row\">\n                        ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.related_content), {hash:{},inverse:self.noop,fn:self.program(12, program12, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    </div>\n                </div>\n                ";
  return buffer;
  }
function program12(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                            <div class=\"col-xs-4\">\n                                <a href=\"/learn/";
  if (helper = helpers.path) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.path); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" title=\"";
  if (helper = helpers.description) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.description); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\" class=\"btn btn-success btn-related-content\">\n                                    <div class=\"related-content-header\">\n                                        <span aria-hidden=\"true\"><i class=\"icon-";
  if (helper = helpers.kind) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.kind); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "\"></i></span>\n                                        <span class=\"sr-only\">";
  if (helper = helpers.kind) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.kind); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                                        <span class=\"related-content-title\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                                    </div>\n                                    <div class=\"related-content-body\">\n                                        <p>\n                                            ";
  stack1 = (helper = helpers.truncate || (depth0 && depth0.truncate),options={hash:{},inverse:self.noop,fn:self.program(13, program13, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.description), 100, options) : helperMissing.call(depth0, "truncate", (depth0 && depth0.description), 100, options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                                        </p>\n                                    </div>\n                                </a>\n                            </div>\n                        ";
  return buffer;
  }
function program13(depth0,data) {
  
  var buffer = "";
  return buffer;
  }

function program15(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n                <div class=\"panel-footer\">\n                    <h3>\n                        "
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Tags:", options) : helperMissing.call(depth0, "_", "Tags:", options)))
    + "\n                    </h3>\n                    ";
  stack1 = helpers.each.call(depth0, (depth0 && depth0.tags), {hash:{},inverse:self.noop,fn:self.program(16, program16, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                </div>\n                ";
  return buffer;
  }
function program16(depth0,data) {
  
  var buffer = "";
  buffer += "\n                        <a href=\"/search/?query="
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\">\n                            <span class=\"btn btn-tag\">\n                            "
    + escapeExpression((typeof depth0 === functionType ? depth0.apply(depth0) : depth0))
    + "\n                            </span>\n                        </a>\n                    ";
  return buffer;
  }

  buffer += "<div class=\"container\">\n    <div class=\"row\">\n        <div class=\"col-xs-12\">\n            <div class=\"panel panel-default\">\n                <div class=\"panel-heading\">\n                    <div class=\"pull-right\">\n                        <div class=\"points-wrapper\"></div>\n                        \n                        ";
  stack1 = (helper = helpers.ifcond || (depth0 && depth0.ifcond),options={hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data},helper ? helper.call(depth0, (depth0 && depth0.kind), "==", "Document", options) : helperMissing.call(depth0, "ifcond", (depth0 && depth0.kind), "==", "Document", options));
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                        <div class=\"clear\"></div>\n                    </div>\n\n                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.dubs_available), {hash:{},inverse:self.noop,fn:self.program(3, program3, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n                    <span class=\"title\">";
  if (helper = helpers.title) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.title); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span>\n                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.organization), {hash:{},inverse:self.noop,fn:self.program(7, program7, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                    ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.description), {hash:{},inverse:self.noop,fn:self.program(9, program9, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n\n                    <div class=\"clear\"></div>\n\n                    <div class=\"borderwrapper\"></div>\n                </div>\n                <div class=\"panel-body\">\n                    <div class=\"content-player-container\"></div>\n                </div>\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.related_content), {hash:{},inverse:self.noop,fn:self.program(11, program11, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n                ";
  stack1 = helpers['if'].call(depth0, (depth0 && depth0.tags), {hash:{},inverse:self.noop,fn:self.program(15, program15, data),data:data});
  if(stack1 || stack1 === 0) { buffer += stack1; }
  buffer += "\n            </div>\n        </div>\n    </div>\n</div>\n";
  return buffer;
  });

},{"hbsfy/runtime":354}],47:[function(require,module,exports){
// hbsfy compiled Handlebars template
var HandlebarsCompiler = require('hbsfy/runtime');
module.exports = HandlebarsCompiler.template(function (Handlebars,depth0,helpers,partials,data) {
  this.compilerInfo = [4,'>= 1.0.0'];
helpers = this.merge(helpers, Handlebars.helpers); data = data || {};
  var stack1, helperMissing=helpers.helperMissing, escapeExpression=this.escapeExpression, functionType="function", self=this;

function program1(depth0,data) {
  
  var buffer = "", stack1, helper, options;
  buffer += "\n    <span class=\"motivational-feature points-container\">"
    + escapeExpression((helper = helpers._ || (depth0 && depth0._),options={hash:{},data:data},helper ? helper.call(depth0, "Points", options) : helperMissing.call(depth0, "_", "Points", options)))
    + ":\n        <span class=\"points\">";
  if (helper = helpers.points) { stack1 = helper.call(depth0, {hash:{},data:data}); }
  else { helper = (depth0 && depth0.points); stack1 = typeof helper === functionType ? helper.call(depth0, {hash:{},data:data}) : helper; }
  buffer += escapeExpression(stack1)
    + "</span><br>\n    </span>\n";
  return buffer;
  }

  stack1 = helpers['if'].call(depth0, (depth0 && depth0.points), {hash:{},inverse:self.noop,fn:self.program(1, program1, data),data:data});
  if(stack1 || stack1 === 0) { return stack1; }
  else { return ''; }
  });

},{"hbsfy/runtime":354}],37:[function(require,module,exports){
(function() { var head = document.getElementsByTagName('head')[0]; var style = document.createElement('style'); style.type = 'text/css';var css = ".sidebar-icon{font-size:.7em;padding-right:10px;background-color:rgba(219,219,219,0.19);border-radius:3px;padding:7px}.sidebar-icon.partial{opacity:.45}.sidebar-icon.complete{opacity:.15}.sidebar-title.complete{opacity:.45}.sidebar-panel{-webkit-transform:translateZ(0);background:#5aa685;z-index:9999;position:fixed;height:100%;border-right:1px solid rgba(0,0,0,0.3);top:0;bottom:0;font-size:100%}div.sidebar-fade{position:absolute;left:0;top:0;background-color:black;-moz-opacity:.7;opacity:.7;filter:alpha(opacity=70);width:100%;height:100%;z-index:9998}.sidebar-panel ul{list-style-type:none;margin-left:-40px}.sidebar-panel li{border-bottom:1px solid rgba(0,0,0,0.3)}.sidebar-panel .sidebar-entry{display:block;padding:1.1em 1em;font-size:1.2em}.missing{opacity:.4;background:#93bfac}.sidebar-panel a:link,.sidebar-panel a:visited{color:#fff;display:block;margin:3px 3px 3px 0}.sidebar-panel .active-entry{background-color:rgba(0,0,0,0.3)}.sidebar-divider{color:#bcb;font-weight:bolder;background:rgba(116,116,116,0.5)}.sidebar-tab{z-index:10000;position:fixed;left:0;top:40%;background:#5aa685;color:#fff;font-weight:bold;font-size:1.9em;padding:30px 10px;padding-left:14px;border-width:1px 1px 1px 0;border-top-right-radius:5px;border-bottom-right-radius:5px;cursor:pointer;box-shadow:inset 3px 0 8px rgba(0,0,0,0.3)}.sidebar-tab:hover{padding-left:20px}.sidebar-tab a{display:block;text-decoration:none}.sidebar-nav-container .title{display:block;float:left;width:160px;padding-left:26px;padding-top:20px;padding-bottom:20px;border-left:2px solid #587448;font-size:2em;font-weight:bold;color:#ccc}.sidebar-back{height:100%;width:2em;text-align:center;color:#fff;background-color:#467471;font-size:1.5em;border-right:1px solid rgba(0,0,0,0.3);position:absolute;z-index:10000}.sidebar-back button{height:3em;padding:0;width:1.8em;top:40%}.sidebar-back-hover{background-color:#3d6663 !important}.topic-container-inner{float:left;width:200px;border-right:1px solid rgba(0,0,0,0.3)}.topic-container-inner:last-child{width:400px}.topic-container-inner .sidebar-topic-description{display:none;font-size:.9em;margin-top:15px}.topic-container-inner:last-child .sidebar-description{display:block;line-height:1.1em;margin-bottom:-10px;padding-top:10px;color:#add3c2;word-wrap:break-word}.topic-container-inner:last-child .sidebar-organization{display:block;line-height:1.1em;margin-top:-7px;color:#aaacaa;word-wrap:break-word}.topic-container-inner:last-child .sidebar-space-holder{display:block;line-height:1.1em;margin-top:-12px;color:#a3cca3;word-wrap:break-word}.sidebar-entry-header{display:table;max-height:2.5em;margin-bottom:-10px;margin-top:-10px}.topic-container-inner:last-child .sidebar-entry-header{display:table;margin-bottom:12px}.sidebar-entry-header>.sidebar-icon{height:100%;margin-top:2px}.sidebar-entry-header>.sidebar-title{line-height:1em;display:table-cell;vertical-align:middle;white-space:inherit;text-overflow:inherit;padding-left:8px;padding-top:0;padding-bottom:0}.topic-container-inner:last-child .sidebar-entry-header>.sidebar-title{display:table-cell;vertical-align:middle;white-space:inherit;text-overflow:inherit;padding-top:0;padding-bottom:0}.topic-container-inner:last-child .sidebar-entry-header>.sidebar-icon{height:100%;margin-top:2px;display:table-cell;vertical-align:middle}@media only screen and (max-width:768px){.sidebar-tab{top:55px;height:2em;padding:9px}}@media only screen and (max-width:720px){.sidebar-panel{font-size:85%}.topic-container-inner:last-child{width:300px}}@media only screen and (min-width:720px){.sidebar-panel{font-size:90%}.topic-container-inner:last-child{width:300px}}@media only screen and (min-width:1000px){.sidebar-panel{font-size:100%}.topic-container-inner:last-child{width:400px}}@media only screen and (min-width:1300px){.sidebar-panel{font-size:105%}.topic-container-inner:last-child{width:400px}}";if (style.styleSheet){ style.styleSheet.cssText = css; } else { style.appendChild(document.createTextNode(css)); } head.appendChild(style);}())
},{}],30:[function(require,module,exports){
(function() { var head = document.getElementsByTagName('head')[0]; var style = document.createElement('style'); style.type = 'text/css';var css = ".content-wrapper{border:2px solid #f0f0f0;border-radius:5px;padding:20px;background-color:#f8f8f8}.points-wrapper{font-size:20px;margin-bottom:10px}.download-link{margin-bottom:10px}.panel-heading-right-column{float:right;text-align:right}.points-wrapper span.points-container{margin:5px 0;float:right;background-color:white;border:2px solid rgba(255,255,255,0.5);position:relative;color:#77b05d;font-weight:400;border-radius:4px}.btn.btn-primary.download-link.pull-right{font-size:20px;font-weight:800;padding:15px;margin:15px;color:white;background-color:#5aa685;border:2px solid #5aa685}.btn.btn-primary.download-link.pull-right:hover{background-color:white;color:#77b05d;border:2px solid white}.organization{display:block;margin-top:-3px;margin-bottom:5px;color:#6d726b;word-wrap:break-word;font-size:20px}.btn-related-content{text-align:left;white-space:normal;background-color:#8dc63f;border-color:#8dc63f}.btn-related-content:hover{background-color:#5aa685;border-color:#5aa685}.related-content-header{font-size:14px;padding-bottom:5px}.related-content-title{font-weight:400;font-size:1.2em;margin-left:10px;position:relative;top:5px}.panel-footer h3{color:#6d726b;margin-top:0;font-size:20px;font-weight:400}.btn-tag{font-size:1.2em;font-weight:400;background-color:#8dc63f;border-color:#8dc63f;color:white}.btn-tag:hover{background-color:#5aa685;border-color:#5aa685;color:white}";if (style.styleSheet){ style.styleSheet.cssText = css; } else { style.appendChild(document.createTextNode(css)); } head.appendChild(style);}())
},{}],29:[function(require,module,exports){
(function() { var head = document.getElementsByTagName('head')[0]; var style = document.createElement('style'); style.type = 'text/css';var css = ".panel-kalite-rating{border-style:solid;border-color:grey;border-width:1px;padding:1em}.panel-kalite-rating .panel-heading{border-bottom-style:solid;border-bottom-color:black;border-bottom-px:4px}.panel-kalite-rating .panel-heading .panel-title{font-size:2em}.panel-kalite-rating .panel-body{background:inherit}.star-rating-inner-wrapper{padding-top:.5em;margin:0 auto}.star-rating-inner-wrapper .lowest-label,.star-rating-inner-wrapper .highest-label{padding-top:1.8em}.star-rating-inner-wrapper .rating-row>div{padding-left:0;padding-right:0}.star-rating-inner-wrapper .btn-star{font-size:3em;border-style:solid;border-width:1px;border-color:black}.star-rating-inner-wrapper .btn-star .glyphicon-star-empty{top:5px;left:2px}.star-rating-inner-wrapper .btn-star{background:#fff}.star-rating-inner-wrapper .btn-star:active{background:#ff6}.star-rating-inner-wrapper .btn-star.activated{background:#c60}.star-rating-inner-wrapper .btn-star.activated:active{background:#630}.star-rating-inner-wrapper .btn-star:hover{background:#eee}.star-rating-inner-wrapper .btn-star.activated:hover{background:#b50}.star-rating-inner-wrapper .star-title-label{background:inherit;color:inherit}.star-rating-inner-wrapper .rating-label{height:1em;font-size:1em}#text-container .rating-text-feedback{max-width:60%}#text-container .text-feedback-label{padding-left:0}";if (style.styleSheet){ style.styleSheet.cssText = css; } else { style.appendChild(document.createTextNode(css)); } head.appendChild(style);}())
},{}]},{},["learn"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL2J1bmRsZV9tb2R1bGVzL2xlYXJuLmpzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC90b3BpY3Mvcm91dGVyLmpzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC90b3BpY3Mvdmlld3MuanMiLCJub2RlX21vZHVsZXMvanF1ZXJ5LXNsaW1zY3JvbGwvanF1ZXJ5LnNsaW1zY3JvbGwuanMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3RvcGljcy9tb2RlbHMuanMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3RvcGljcy9oYnRlbXBsYXRlcy9zaWRlYmFyLmhhbmRsZWJhcnMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3RvcGljcy9oYnRlbXBsYXRlcy9zaWRlYmFyLWVudHJ5LmhhbmRsZWJhcnMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3RvcGljcy9oYnRlbXBsYXRlcy9zaWRlYmFyLWNvbnRlbnQuaGFuZGxlYmFycyIsImthbGl0ZS9kaXN0cmlidXRlZC9zdGF0aWMvanMvZGlzdHJpYnV0ZWQvdG9waWNzL2hidGVtcGxhdGVzL2NvbnRlbnQtYXJlYS5oYW5kbGViYXJzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9yYXRpbmcvdmlld3MuanMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3JhdGluZy9tb2RlbHMuanMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3JhdGluZy9oYnRlbXBsYXRlcy90ZXh0LmhhbmRsZWJhcnMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3JhdGluZy9oYnRlbXBsYXRlcy9zdGFyLmhhbmRsZWJhcnMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2pzL2Rpc3RyaWJ1dGVkL3JhdGluZy9oYnRlbXBsYXRlcy9yYXRpbmcuaGFuZGxlYmFycyIsImthbGl0ZS9kaXN0cmlidXRlZC9zdGF0aWMvanMvZGlzdHJpYnV0ZWQvY29udGVudC92aWV3cy5qcyIsImthbGl0ZS9kaXN0cmlidXRlZC9zdGF0aWMvanMvZGlzdHJpYnV0ZWQvdmlkZW8vbW9kZWxzLmpzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50L2hidGVtcGxhdGVzL2NvbnRlbnQtd3JhcHBlci5oYW5kbGViYXJzIiwia2FsaXRlL2Rpc3RyaWJ1dGVkL3N0YXRpYy9qcy9kaXN0cmlidXRlZC9jb250ZW50L2hidGVtcGxhdGVzL2NvbnRlbnQtcG9pbnRzLmhhbmRsZWJhcnMiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2Nzcy9kaXN0cmlidXRlZC9zaWRlYmFyLmxlc3MiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2Nzcy9kaXN0cmlidXRlZC9jb250ZW50Lmxlc3MiLCJrYWxpdGUvZGlzdHJpYnV0ZWQvc3RhdGljL2Nzcy9kaXN0cmlidXRlZC9jb250ZW50LXJhdGluZy5sZXNzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDaEZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDL3VCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDdGRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ1hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDWEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQzdOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3RCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUNyS0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUN0QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FDcktBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQ3hCQTs7QUNBQTs7QUNBQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgJCA9IHJlcXVpcmUoXCJiYXNlL2pRdWVyeVwiKTtcbnZhciBUb3BpY0NoYW5uZWxSb3V0ZXIgPSByZXF1aXJlKFwidG9waWNzL3JvdXRlclwiKTtcbnZhciBCYWNrYm9uZSA9IHJlcXVpcmUoXCJiYXNlL2JhY2tib25lXCIpO1xuXG5yZXF1aXJlKFwiLi4vLi4vLi4vY3NzL2Rpc3RyaWJ1dGVkL2NvbnRlbnQtcmF0aW5nLmxlc3NcIik7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuXHQkOiAkLFxuXHRUb3BpY0NoYW5uZWxSb3V0ZXI6IFRvcGljQ2hhbm5lbFJvdXRlcixcblx0QmFja2JvbmU6IEJhY2tib25lXG59OyIsInZhciBfID0gcmVxdWlyZShcInVuZGVyc2NvcmVcIik7XG52YXIgQmFja2JvbmUgPSByZXF1aXJlKFwiYmFzZS9iYWNrYm9uZVwiKTtcbnZhciAkID0gcmVxdWlyZShcImJhc2UvalF1ZXJ5XCIpO1xudmFyIE1vZGVscyA9IHJlcXVpcmUoXCIuL21vZGVsc1wiKTtcbnZhciBWaWV3cyA9IHJlcXVpcmUoXCIuL3ZpZXdzXCIpO1xudmFyIHNwcmludGYgPSByZXF1aXJlKFwic3ByaW50Zi1qc1wiKS5zcHJpbnRmO1xuXG5Ub3BpY0NoYW5uZWxSb3V0ZXIgPSBCYWNrYm9uZS5Sb3V0ZXIuZXh0ZW5kKHtcbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbihvcHRpb25zKSB7XG4gICAgICAgIF8uYmluZEFsbCh0aGlzLCBcIm5hdmlnYXRlX2RlZmF1bHRfY2hhbm5lbFwiLCBcImludGVyY2VwdF9sZWFybl9uYXZcIiwgXCJuYXZpZ2F0ZV9jaGFubmVsXCIsIFwiYWRkX3NsdWdcIiwgXCJ1cmxfYmFja1wiLCBcIm5hdmlnYXRlX3NwbGF0XCIsIFwic2V0X3BhZ2VfdGl0bGVcIiwgXCJ0cmlnZ2VyX25hdmlnYXRpb25fY2FsbGJhY2tcIik7XG4gICAgICAgIHRoaXMuZGVmYXVsdF9jaGFubmVsID0gb3B0aW9ucy5kZWZhdWx0X2NoYW5uZWw7XG4gICAgICAgICQoXCIjbmF2X2xlYXJuXCIpLmNsaWNrKHRoaXMuaW50ZXJjZXB0X2xlYXJuX25hdik7XG4gICAgfSxcblxuICAgIHJvdXRlczoge1xuICAgICAgICBcIlwiOiAgIFwibmF2aWdhdGVfZGVmYXVsdF9jaGFubmVsXCIsXG4gICAgICAgIC8vIFRoaXMgd2lsbCBjYXRjaCBhbnkgbmF2aWdhdGlvbiBldmVudHMgdG8gb3RoZXIgY29udGVudCBpdGVtcywgYW5kLi4uXG4gICAgICAgIFwiOmNoYW5uZWwvKCpzcGxhdClcIjogICAgXCJuYXZpZ2F0ZV9jaGFubmVsXCIsXG4gICAgICAgIC8vIC4uLnRoaXMgd2lsbCBjYXRjaCBhbnkgb3RoZXIgbmF2aWdhdGlvbiBldmVudHMuIFdlIHdhbnQgdG8gbWFrZSBzdXJlXG4gICAgICAgIC8vIHBvaW50cyBhcmUgdXBkYXRlZCBjb3JyZWN0bHkgaW4gZWl0aGVyIGNhc2UuXG4gICAgICAgIFwiLyguKikvXCI6IFwidHJpZ2dlcl9uYXZpZ2F0aW9uX2NhbGxiYWNrXCJcbiAgICB9LFxuXG4gICAgbmF2aWdhdGVfZGVmYXVsdF9jaGFubmVsOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGFkZFBhcmFtO1xuICAgICAgICBpZiAod2luZG93LmxvY2F0aW9uLnRvU3RyaW5nKCkuc3BsaXQoXCI/XCIpLmxlbmd0aCA+IDEpIHtcbiAgICAgICAgICAgIGFkZFBhcmFtID0gXCI/XCIgKyB3aW5kb3cubG9jYXRpb24udG9TdHJpbmcoKS5zcGxpdChcIj9cIilbMV07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBhZGRQYXJhbSA9IFwiXCI7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5uYXZpZ2F0ZSh0aGlzLmRlZmF1bHRfY2hhbm5lbCArIFwiL1wiICsgYWRkUGFyYW0sIHt0cmlnZ2VyOiB0cnVlLCByZXBsYWNlOiB0cnVlfSk7XG4gICAgfSxcblxuICAgIGludGVyY2VwdF9sZWFybl9uYXY6IGZ1bmN0aW9uKGV2ZW50KXtcbiAgICAgICAgdGhpcy5uYXZpZ2F0ZSh0aGlzLmRlZmF1bHRfY2hhbm5lbCArIFwiL1wiLCB7dHJpZ2dlcjogdHJ1ZX0pO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSxcblxuICAgIG5hdmlnYXRlX2NoYW5uZWw6IGZ1bmN0aW9uKGNoYW5uZWwsIHNwbGF0KSB7XG4gICAgICAgIGlmICh0aGlzLmNoYW5uZWwhPT1jaGFubmVsKSB7XG4gICAgICAgICAgICB0aGlzLmNvbnRyb2xfdmlldyA9IG5ldyBWaWV3cy5TaWRlYmFyVmlldyh7XG4gICAgICAgICAgICAgICAgY2hhbm5lbDogY2hhbm5lbCxcbiAgICAgICAgICAgICAgICBlbnRpdHlfa2V5OiBcImNoaWxkcmVuXCIsXG4gICAgICAgICAgICAgICAgZW50aXR5X2NvbGxlY3Rpb246IE1vZGVscy5Ub3BpY0NvbGxlY3Rpb25cbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgdGhpcy5jaGFubmVsID0gY2hhbm5lbDtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLm5hdmlnYXRlX3NwbGF0KHNwbGF0KTtcbiAgICB9LFxuXG4gICAgYWRkX3NsdWc6IGZ1bmN0aW9uKHNsdWcpIHtcbiAgICAgICAgdGhpcy5uYXZpZ2F0ZShCYWNrYm9uZS5oaXN0b3J5LmdldEZyYWdtZW50KCkgKyBzbHVnICsgXCIvXCIsIHt0cmlnZ2VyOiB0cnVlfSk7XG4gICAgfSxcblxuICAgIHVybF9iYWNrOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGN1cnJlbnRfdXJsID0gQmFja2JvbmUuaGlzdG9yeS5nZXRGcmFnbWVudCgpO1xuICAgICAgICB2YXIgZnJhZ21lbnRzID0gY3VycmVudF91cmwuc3BsaXQoXCIvXCIpLnNsaWNlKDAsLTEpO1xuICAgICAgICBpZiAoZnJhZ21lbnRzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHRoaXMubmF2aWdhdGUoZnJhZ21lbnRzLnNsaWNlKDAsLTEpLmpvaW4oXCIvXCIpICsgXCIvXCIsIHt0cmlnZ2VyOiB0cnVlfSk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgbmF2aWdhdGVfc3BsYXQ6IGZ1bmN0aW9uKHNwbGF0KSB7XG4gICAgICAgIHNwbGF0ID0gc3BsYXQgfHwgXCIvXCI7XG4gICAgICAgIGlmIChzcGxhdC5pbmRleE9mKFwiL1wiLCBzcGxhdC5sZW5ndGggLSAxKT09LTEpIHtcbiAgICAgICAgICAgIHNwbGF0ICs9IFwiL1wiO1xuICAgICAgICAgICAgdGhpcy5uYXZpZ2F0ZShCYWNrYm9uZS5oaXN0b3J5LmdldEZyYWdtZW50KCkgKyBcIi9cIik7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jb250cm9sX3ZpZXcubmF2aWdhdGVfcGF0aHMoc3BsYXQuc3BsaXQoXCIvXCIpLnNsaWNlKDAsLTEpLCB0aGlzLnNldF9wYWdlX3RpdGxlKTtcbiAgICB9LFxuXG4gICAgc2V0X3BhZ2VfdGl0bGU6IGZ1bmN0aW9uKHRpdGxlKSB7XG4gICAgICAgIGRvY3VtZW50LnRpdGxlID0gZG9jdW1lbnQudGl0bGUucmVwbGFjZSgvKFxcdyspKCB8OltefF0qKShcXHwpLywgc3ByaW50ZihcIiQxOiAlcyAkM1wiLCB0aXRsZSkpO1xuICAgIH0sXG5cbiAgICB0cmlnZ2VyX25hdmlnYXRpb25fY2FsbGJhY2s6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIoXCJuYXZpZ2F0aW9uXCIpO1xuICAgIH1cbn0pO1xuXG5tb2R1bGUuZXhwb3J0cyA9IFRvcGljQ2hhbm5lbFJvdXRlcjsiLCJ2YXIgQmFzZVZpZXcgPSByZXF1aXJlKFwiYmFzZS9iYXNldmlld1wiKTtcbnZhciBfID0gcmVxdWlyZShcInVuZGVyc2NvcmVcIik7XG52YXIgJCA9IHJlcXVpcmUoXCJiYXNlL2pRdWVyeVwiKTtcbnJlcXVpcmUoXCJqcXVlcnktc2xpbXNjcm9sbC9qcXVlcnkuc2xpbXNjcm9sbFwiKTtcbnZhciBCYWNrYm9uZSA9IHJlcXVpcmUoXCJiYXNlL2JhY2tib25lXCIpO1xudmFyIG1lc3NhZ2VzID0gcmVxdWlyZShcInV0aWxzL21lc3NhZ2VzXCIpO1xudmFyICRzY3JpcHQgPSByZXF1aXJlKFwic2NyaXB0anNcIik7XG5cbnJlcXVpcmUoXCIuLi8uLi8uLi9jc3MvZGlzdHJpYnV0ZWQvc2lkZWJhci5sZXNzXCIpO1xuXG52YXIgQ29udGVudFZpZXdzID0gcmVxdWlyZShcImNvbnRlbnQvdmlld3NcIik7XG52YXIgTW9kZWxzID0gcmVxdWlyZShcIi4vbW9kZWxzXCIpO1xuXG52YXIgUmF0aW5nVmlldyA9IHJlcXVpcmUoXCJyYXRpbmcvdmlld3NcIik7XG52YXIgUmF0aW5nTW9kZWxzID0gcmVxdWlyZShcInJhdGluZy9tb2RlbHNcIik7XG52YXIgUmF0aW5nTW9kZWwgPSBSYXRpbmdNb2RlbHMuUmF0aW5nTW9kZWw7XG52YXIgQ29udGVudFJhdGluZ0NvbGxlY3Rpb24gPSBSYXRpbmdNb2RlbHMuQ29udGVudFJhdGluZ0NvbGxlY3Rpb247XG5cbi8vIFZpZXdzXG5cbnZhciBDb250ZW50QXJlYVZpZXcgPSBCYXNlVmlldy5leHRlbmQoe1xuXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoXCIuL2hidGVtcGxhdGVzL2NvbnRlbnQtYXJlYS5oYW5kbGViYXJzXCIpLFxuXG4gICAgaW5pdGlhbGl6ZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMubW9kZWwgPSBuZXcgQmFja2JvbmUuTW9kZWwoKTtcbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcblxuICAgICAgICB0aGlzLmNvbnRlbnRfcmF0aW5nX2NvbGxlY3Rpb24gPSBuZXcgQ29udGVudFJhdGluZ0NvbGxlY3Rpb24oKTtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICB0aGlzLmNvbnRlbnRfcmF0aW5nX2NvbGxlY3Rpb24udXJsID0gZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICByZXR1cm4gc2Vzc2lvbk1vZGVsLmdldChcIkNPTlRFTlRfUkFUSU5HX0xJU1RfVVJMXCIpICsgXCIvP1wiICsgJC5wYXJhbSh7XG4gICAgICAgICAgICAgICAgXCJ1c2VyXCI6IHdpbmRvdy5zdGF0dXNNb2RlbC5nZXQoXCJ1c2VyX2lkXCIpLFxuICAgICAgICAgICAgICAgIFwiY29udGVudF9raW5kXCI6IHNlbGYubW9kZWwuZ2V0KFwia2luZFwiKSxcbiAgICAgICAgICAgICAgICBcImNvbnRlbnRfaWRcIjogc2VsZi5tb2RlbC5nZXQoXCJpZFwiKVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH07XG4gICAgICAgIHRoaXMubGlzdGVuVG8od2luZG93LnN0YXR1c01vZGVsLCBcImNoYW5nZTp1c2VyX2lkXCIsIHRoaXMuc2hvd19yYXRpbmcpO1xuICAgICAgICBfLmJpbmRBbGwodGhpcywgXCJzaG93X3JhdGluZ1wiKTtcbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKHRoaXMubW9kZWwuYXR0cmlidXRlcykpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuXG4gICAgc2hvd192aWV3OiBmdW5jdGlvbih2aWV3KSB7XG4gICAgICAgIC8vIGhpZGUgYW55IG1lc3NhZ2VzIGJlaW5nIHNob3duIGZvciB0aGUgb2xkIHZpZXdcbiAgICAgICAgbWVzc2FnZXMuY2xlYXJfbWVzc2FnZXMoKTtcblxuICAgICAgICB0aGlzLmNsb3NlKCk7XG4gICAgICAgIC8vIHNldCB0aGUgbmV3IHZpZXcgYXMgdGhlIGN1cnJlbnQgdmlld1xuICAgICAgICB0aGlzLmN1cnJlbnRseV9zaG93bl92aWV3ID0gdmlldztcblxuICAgICAgICAvLyBzaG93IHRoZSB2aWV3XG4gICAgICAgIHRoaXMuJChcIi5jb250ZW50XCIpLmh0bWwoXCJcIikuYXBwZW5kKHZpZXcuJGVsKTtcbiAgICB9LFxuXG4gICAgc2hvdWxkX3Nob3dfcmF0aW5nOiBmdW5jdGlvbigpIHtcbiAgICAgICAgLypcbiAgICAgICAgVGhpcyBmdW5jdGlvbiBkZXRlcm1pbmVzIHdoZXRoZXIgYSByYXRpbmcgc2hvdWxkIGJlIHNob3duIGZvciB0aGUgY29udGVudCBpdGVtLlxuICAgICAgICByZXR1cm5zOiB0cnVlIG9yIGZhbHNlXG4gICAgICAgICovXG4gICAgICAgIHZhciBlbnRyeV9hdmFpbGFibGUgPSAodHlwZW9mIHRoaXMubW9kZWwgIT09IFwidW5kZWZpbmVkXCIpICYmICEhdGhpcy5tb2RlbC5nZXQoXCJhdmFpbGFibGVcIik7XG4gICAgICAgIHZhciBsb2dnZWRfaW4gPSB3aW5kb3cuc3RhdHVzTW9kZWwuaGFzKFwidXNlcl9pZFwiKTtcbiAgICAgICAgcmV0dXJuIGxvZ2dlZF9pbiAmJiBlbnRyeV9hdmFpbGFibGU7XG4gICAgfSxcblxuICAgIHJlbW92ZV9yYXRpbmdfdmlldzogZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIFJlbW92ZSB0aGUgcmF0aW5nIHZpZXcgaWYgaXQgZXhpc3RzLlxuICAgICAgICBpZiAodHlwZW9mIHRoaXMucmF0aW5nX3ZpZXcgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgICAgIHRoaXMucmF0aW5nX3ZpZXcucmVtb3ZlKCk7XG4gICAgICAgICAgICBkZWxldGUgdGhpcy5yYXRpbmdfdmlldztcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBzaG93X3JhdGluZzogZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIEZpcnN0LCBkZXRlcm1pbmUgd2hldGhlciB3ZSBzaG91bGQgc2hvdyB0aGUgcmF0aW5nIGF0IGFsbC5cbiAgICAgICAgLy8gSWYgaXQgc2hvdWxkIG5vdCBiZSBzaG93biwgYmUgc3VyZSB0byByZW1vdmUgdGhlIHJhdGluZ192aWV3OyBzdWJzZXF1ZW50IGxvZ2ljIGRlcGVuZHMgb24gdGhhdC5cbiAgICAgICAgaWYgKCAhdGhpcy5zaG91bGRfc2hvd19yYXRpbmcoKSApIHtcbiAgICAgICAgICAgIHRoaXMucmVtb3ZlX3JhdGluZ192aWV3KCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cblxuICAgICAgICAvLyBTZWNvbmRseSwgaWYgdGhlIHJhdGluZ192aWV3IGlzIHByZXZpb3VzbHkgZGVsZXRlZCBvciBuZXZlciBzaG93biBiZWZvcmUgYXQgYWxsLCB0aGVuIGRlZmluZSBpdC5cbiAgICAgICAgaWYoIHR5cGVvZiB0aGlzLnJhdGluZ192aWV3ID09PSBcInVuZGVmaW5lZFwiICkge1xuICAgICAgICAgICAgdGhpcy5yYXRpbmdfdmlldyA9IHRoaXMuYWRkX3N1YnZpZXcoUmF0aW5nVmlldywge30pO1xuICAgICAgICAgICAgdGhpcy4kKFwiI3JhdGluZy1jb250YWluZXItd3JhcHBlclwiKS5hcHBlbmQodGhpcy5yYXRpbmdfdmlldy5lbCk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBGaW5hbGx5LCBoYW5kbGUgdGhlIGFjdHVhbCBkaXNwbGF5IGxvZ2ljXG4gICAgICAgIGlmKCB0aGlzLnJhdGluZ192aWV3Lm1vZGVsID09PSBudWxsIHx8IHRoaXMucmF0aW5nX3ZpZXcubW9kZWwuZ2V0KFwiY29udGVudF9pZFwiKSAhPT0gdGhpcy5tb2RlbC5nZXQoXCJpZFwiKSApIHtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHRoaXMuY29udGVudF9yYXRpbmdfY29sbGVjdGlvbi5mZXRjaCgpLmRvbmUoZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAvLyBRdWV1ZSB1cCBhIHNhdmUgb24gdGhlIG1vZGVsIHdlJ3JlIGFib3V0IHRvIHN3aXRjaCBvdXQsIGluIGNhc2UgaXQgaGFzbid0IGJlZW4gc3luY2VkLlxuICAgICAgICAgICAgICAgIGlmIChzZWxmLnJhdGluZ192aWV3Lm1vZGVsICE9PSBudWxsICYmIHNlbGYucmF0aW5nX3ZpZXcubW9kZWwuaGFzQ2hhbmdlZCgpKSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYucmF0aW5nX3ZpZXcubW9kZWwuZGVib3VuY2VkX3NhdmUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYoc2VsZi5jb250ZW50X3JhdGluZ19jb2xsZWN0aW9uLm1vZGVscy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5yYXRpbmdfdmlldy5tb2RlbCA9IHNlbGYuY29udGVudF9yYXRpbmdfY29sbGVjdGlvbi5wb3AoKTtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5yYXRpbmdfdmlldy5yZW5kZXIoKTtcbiAgICAgICAgICAgICAgICB9IGVsc2UgaWYgKCBzZWxmLmNvbnRlbnRfcmF0aW5nX2NvbGxlY3Rpb24ubW9kZWxzLmxlbmd0aCA9PT0gMCApIHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5yYXRpbmdfdmlldy5tb2RlbCA9IG5ldyBSYXRpbmdNb2RlbCh7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJ1c2VyXCI6IHdpbmRvdy5zdGF0dXNNb2RlbC5nZXQoXCJ1c2VyX3VyaVwiKSxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcImNvbnRlbnRfa2luZFwiOiBzZWxmLm1vZGVsLmdldChcImtpbmRcIiksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXCJjb250ZW50X2lkXCI6IHNlbGYubW9kZWwuZ2V0KFwiaWRcIilcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYucmF0aW5nX3ZpZXcucmVuZGVyKCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZXMuc2hvd19tZXNzYWdlKFwiZXJyb3JcIiwgXCJTZXJ2ZXIgRXJyb3I6IE1vcmUgdGhhbiBvbmUgcmF0aW5nIGZvdW5kIGZvciB0aGlzIHVzZXIgYW5kIGNvbnRlbnQgaXRlbSFcIiwgXCJ0b28tbWFueS1yYXRpbmdzLW1zZ1wiKTtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5yZW1vdmVfcmF0aW5nX3ZpZXcoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KS5lcnJvcihmdW5jdGlvbigpe1xuICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nKFwiY29udGVudCByYXRpbmcgY29sbGVjdGlvbiBmYWlsZWQgdG8gZmV0Y2hcIik7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBjbG9zZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIFRoaXMgZG9lcyBub3QgYWN0dWFsbHkgY2xvc2UgdGhpcyB2aWV3LiBJZiB5b3UgKnJlYWxseSogd2FudCB0byBnZXQgcmlkIG9mIHRoaXMgdmlldyxcbiAgICAgICAgLy8geW91IHNob3VsZCBjYWxsIC5yZW1vdmUoKSFcbiAgICAgICAgLy8gVGhpcyBpcyB0byBhbGxvdyB0aGUgY2hpbGQgdmlldyBjdXJyZW50bHlfc2hvd25fdmlldyB0byBhY3QgY29uc2lzdGVudGx5IHdpdGggb3RoZXJcbiAgICAgICAgLy8gaW5uZXJfdmlld3MgZm9yIHRoZSBzaWRlYmFyIElubmVyVG9waWNzVmlldy5cbiAgICAgICAgaWYgKHRoaXMuY3VycmVudGx5X3Nob3duX3ZpZXcpIHtcbiAgICAgICAgICAgIC8vIHRyeSBjYWxsaW5nIHRoZSBjbG9zZSBtZXRob2QgaWYgYXZhaWxhYmxlLCBvdGhlcndpc2UgcmVtb3ZlIGRpcmVjdGx5XG4gICAgICAgICAgICBpZiAoXy5pc0Z1bmN0aW9uKHRoaXMuY3VycmVudGx5X3Nob3duX3ZpZXcuY2xvc2UpKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jdXJyZW50bHlfc2hvd25fdmlldy5jbG9zZSgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICB0aGlzLmN1cnJlbnRseV9zaG93bl92aWV3LnJlbW92ZSgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuXG59KTtcblxudmFyIFNpZGViYXJWaWV3ID0gQmFzZVZpZXcuZXh0ZW5kKHtcbiAgICBlbDogXCIjc2lkZWJhci1jb250YWluZXJcIixcbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvc2lkZWJhci5oYW5kbGViYXJzXCIpLFxuXG4gICAgZXZlbnRzOiB7XG4gICAgICAgIFwiY2xpY2sgLnNpZGViYXItdGFiXCI6IFwidG9nZ2xlX3NpZGViYXJcIixcbiAgICAgICAgXCJjbGljayAuc2lkZWJhci1mYWRlXCI6IFwiY2hlY2tfZXh0ZXJuYWxfY2xpY2tcIixcbiAgICAgICAgXCJjbGljayAuc2lkZWJhci1iYWNrXCI6IFwic2lkZWJhcl9iYWNrX29uZV9sZXZlbFwiXG4gICAgfSxcblxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKG9wdGlvbnMpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuICAgICAgICB2YXIgbmF2YmFyQ29sbGFwc2VkID0gdHJ1ZTtcblxuICAgICAgICAvLyBGYW5jeSBhbGdvcml0aG0gdG8gcnVuIGEgcmVzaXplIHNpZGViYXIgd2hlbiB3aW5kb3cgd2lkdGggXG4gICAgICAgIC8vIGNoYW5nZXMgc2lnbmlmaWNhbnRseSAoMTAwcHggc3RlcHMpIHRvIGF2b2lkIHVubmVjZXNzYXJ5IGNvbXB1dGF0aW9uXG4gICAgICAgIHZhciB3aW5kb3dXaWR0aCA9ICQod2luZG93KS53aWR0aCgpO1xuICAgICAgICAkKHdpbmRvdykub24oXCJyZXNpemVcIiwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBuZXdXaW5kb3dXaWR0aCA9ICQod2luZG93KS53aWR0aCgpO1xuICAgICAgICAgICAgaWYgKE1hdGguZmxvb3IobmV3V2luZG93V2lkdGgvMTAwKSAhPSBNYXRoLmZsb29yKHdpbmRvd1dpZHRoLzEwMCkpIHtcbiAgICAgICAgICAgICAgICBzZWxmLnJlc2l6ZV9zaWRlYmFyKCk7XG4gICAgICAgICAgICAgICAgd2luZG93V2lkdGggPSAkKHdpbmRvdykud2lkdGgoKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCQod2luZG93KS53aWR0aCgpID4gNzY4KSB7XG4gICAgICAgICAgICAgICAgc2VsZi5zaG93X3NpZGViYXJfdGFiKCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlmIChuYXZiYXJDb2xsYXBzZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5zaG93X3NpZGViYXJfdGFiKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBzZWxmLmhpZGVfc2lkZWJhcl90YWIoKTsgICBcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuXG4gICAgICAgICQoXCIubmF2YmFyLWNvbGxhcHNlXCIpLm9uKFwic2hvdy5icy5jb2xsYXBzZVwiLCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHNlbGYuaGlkZV9zaWRlYmFyX3RhYigpO1xuICAgICAgICAgICAgbmF2YmFyQ29sbGFwc2VkID0gZmFsc2U7XG4gICAgICAgIH0pLm9uKFwiaGlkZS5icy5jb2xsYXBzZVwiLCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHNlbGYuc2hvd19zaWRlYmFyX3RhYigpO1xuICAgICAgICAgICAgbmF2YmFyQ29sbGFwc2VkID0gdHJ1ZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5lbnRpdHlfa2V5ID0gb3B0aW9ucy5lbnRpdHlfa2V5O1xuICAgICAgICB0aGlzLmVudGl0eV9jb2xsZWN0aW9uID0gb3B0aW9ucy5lbnRpdHlfY29sbGVjdGlvbjtcblxuICAgICAgICB0aGlzLmNoYW5uZWwgPSBvcHRpb25zLmNoYW5uZWw7XG5cbiAgICAgICAgdGhpcy5zdGF0ZV9tb2RlbCA9IG5ldyBCYWNrYm9uZS5Nb2RlbCh7XG4gICAgICAgICAgICBvcGVuOiBmYWxzZSxcbiAgICAgICAgICAgIGN1cnJlbnRfbGV2ZWw6IDAsXG4gICAgICAgICAgICBjaGFubmVsOiB0aGlzLmNoYW5uZWxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcblxuICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMuc3RhdGVfbW9kZWwsIFwiY2hhbmdlOm9wZW5cIiwgdGhpcy51cGRhdGVfc2lkZWJhcl92aXNpYmlsaXR5KTtcbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh0aGlzLnN0YXRlX21vZGVsLCBcImNoYW5nZTpjdXJyZW50X2xldmVsXCIsIHRoaXMucmVzaXplX3NpZGViYXIpO1xuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XG5cbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKCkpO1xuXG4gICAgICAgIHRoaXMuc2lkZWJhciA9IHRoaXMuJChcIi5zaWRlYmFyLXBhbmVsXCIpO1xuICAgICAgICB0aGlzLnNpZGViYXJUYWIgPSB0aGlzLiQoXCIuc2lkZWJhci10YWJcIik7XG4gICAgICAgIHRoaXMuc2lkZWJhckJhY2sgPSB0aGlzLiQoXCIuc2lkZWJhci1iYWNrXCIpO1xuXG4gICAgICAgIF8uZGVmZXIoZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICBzZWxmLnNob3dfc2lkZWJhcigpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLnRvcGljX25vZGVfdmlldyA9IG5ldyBUb3BpY0NvbnRhaW5lck91dGVyVmlldyh7XG4gICAgICAgICAgICBjaGFubmVsOiB0aGlzLmNoYW5uZWwsXG4gICAgICAgICAgICBtb2RlbDogdGhpcy5tb2RlbCxcbiAgICAgICAgICAgIGVudGl0eV9rZXk6IHRoaXMuZW50aXR5X2tleSxcbiAgICAgICAgICAgIGVudGl0eV9jb2xsZWN0aW9uOiB0aGlzLmVudGl0eV9jb2xsZWN0aW9uLFxuICAgICAgICAgICAgc3RhdGVfbW9kZWw6IHRoaXMuc3RhdGVfbW9kZWxcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMubGlzdGVuVG8odGhpcy50b3BpY19ub2RlX3ZpZXcsIFwiaGlkZVNpZGViYXJcIiwgdGhpcy5oaWRlX3NpZGViYXIpO1xuICAgICAgICB0aGlzLmxpc3RlblRvKHRoaXMudG9waWNfbm9kZV92aWV3LCBcInNob3dTaWRlYmFyXCIsIHRoaXMuc2hvd19zaWRlYmFyKTtcblxuICAgICAgICB0aGlzLiQoJy5zaWRlYmFyLWNvbnRlbnQnKS5hcHBlbmQodGhpcy50b3BpY19ub2RlX3ZpZXcuZWwpO1xuXG4gICAgICAgIHRoaXMuc2V0X3NpZGViYXJfYmFjaygpO1xuXG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH0sXG5cbiAgICByZXNpemVfc2lkZWJhcjogZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlX21vZGVsLmdldChcIm9wZW5cIikpIHtcbiAgICAgICAgICAgIGlmICgkKHdpbmRvdykud2lkdGgoKSA8IDEyNjApIHtcbiAgICAgICAgICAgICAgICB0aGlzLnJlc2l6ZV9mb3JfbmFycm93KCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIHRoaXMucmVzaXplX2Zvcl93aWRlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgcmVzaXplX2Zvcl9uYXJyb3c6IF8uZGVib3VuY2UoZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBjdXJyZW50X2xldmVsID0gdGhpcy5zdGF0ZV9tb2RlbC5nZXQoXCJjdXJyZW50X2xldmVsXCIpO1xuICAgICAgICB2YXIgY29sdW1uX3dpZHRoID0gdGhpcy4kKFwiLnRvcGljLWNvbnRhaW5lci1pbm5lclwiKS53aWR0aCgpO1xuICAgICAgICB2YXIgbGFzdF9jb2x1bW5fd2lkdGggPSB0aGlzLiQoXCIudG9waWMtY29udGFpbmVyLWlubmVyOmxhc3QtY2hpbGRcIikud2lkdGgoKTtcbiAgICAgICAgLy8gSGFjayB0byBnaXZlIHRoZSBsYXN0IGNoaWxkIG9mIC50b3BpYy1jb250YWluZXItaW5uZXIgdG8gYmUgMS41IHRpbWVzIHRoZSBcbiAgICAgICAgLy8gd2lkdGggb2YgdGhlaXIgcGFyZW50cy4gQWxzbywgc2lkZWJhciBvdmVyZmxvdyBvdXQgb2YgdGhlIGxlZnQgc2lkZSBvZiBzY3JlZW5cbiAgICAgICAgLy8gaXMgY29tcHV0ZWQgYW5kIHNldCBoZXJlLlxuXG4gICAgICAgIC8vIFRIRSBtYWdpYyB2YXJpYWJsZSB0aGF0IGNvbnRyb2xzIG51bWJlciBvZiB2aXNpYmxlIHBhbmVsc1xuICAgICAgICB2YXIgbnVtT2ZQYW5lbHNUb1Nob3cgPSA0O1xuXG4gICAgICAgIGlmICgkKHdpbmRvdykud2lkdGgoKSA8IDExMjApXG4gICAgICAgICAgICBudW1PZlBhbmVsc1RvU2hvdyA9IDM7XG5cbiAgICAgICAgaWYgKCQod2luZG93KS53aWR0aCgpIDwgOTIwKVxuICAgICAgICAgICAgbnVtT2ZQYW5lbHNUb1Nob3cgPSAyO1xuXG4gICAgICAgIGlmICgkKHdpbmRvdykud2lkdGgoKSA8IDYyMClcbiAgICAgICAgICAgIG51bU9mUGFuZWxzVG9TaG93ID0gMTtcblxuICAgICAgICAvLyBVc2VkIHRvIGdldCBsZWZ0IHZhbHVlIGluIG51bWJlciBmb3JtXG4gICAgICAgIHZhciBzaWRlYmFyUGFuZWxQb3NpdGlvbiA9IHRoaXMuc2lkZWJhci5wb3NpdGlvbigpO1xuICAgICAgICB2YXIgc2lkZWJhclBhbmVsTGVmdCA9IHNpZGViYXJQYW5lbFBvc2l0aW9uLmxlZnQ7XG5cbiAgICAgICAgdGhpcy53aWR0aCA9IChjdXJyZW50X2xldmVsIC0gMSkgKiBjb2x1bW5fd2lkdGggKyBsYXN0X2NvbHVtbl93aWR0aCArIDEwO1xuICAgICAgICB0aGlzLnNpZGViYXIud2lkdGgodGhpcy53aWR0aCk7XG4gICAgICAgIHZhciBzaWRlYmFyUGFuZWxOZXdMZWZ0ID0gLShjb2x1bW5fd2lkdGggKiAoY3VycmVudF9sZXZlbCAtIG51bU9mUGFuZWxzVG9TaG93KSkgKyB0aGlzLnNpZGViYXJCYWNrLndpZHRoKCk7XG4gICAgICAgIGlmIChzaWRlYmFyUGFuZWxOZXdMZWZ0ID4gMCkgc2lkZWJhclBhbmVsTmV3TGVmdCA9IDA7XG5cbiAgICAgICAgLy8gU2lnbmF0dXJlIGNvbG9yIGZsYXNoIChhbHNvIGhpZGVzIGEgc2xpZ2h0IFVJIGdsaXRjaClcbiAgICAgICAgdmFyIG9yaWdpbmFsQmFja0NvbG9yID0gdGhpcy5zaWRlYmFyQmFjay5jc3MoJ2JhY2tncm91bmQtY29sb3InKTtcbiAgICAgICAgdGhpcy5zaWRlYmFyQmFjay5jc3MoJ2JhY2tncm91bmQtY29sb3InLCB0aGlzLnNpZGViYXJUYWIuY3NzKCdiYWNrZ3JvdW5kLWNvbG9yJykpLmFuaW1hdGUoeydiYWNrZ3JvdW5kLWNvbG9yJzogb3JpZ2luYWxCYWNrQ29sb3J9KTtcbiAgICAgICAgXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgdGhpcy5zaWRlYmFyLmFuaW1hdGUoe1wibGVmdFwiOiBzaWRlYmFyUGFuZWxOZXdMZWZ0fSwgMTE1LCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHNlbGYuc2V0X3NpZGViYXJfYmFjaygpO1xuICAgICAgICB9KTtcblxuICAgICAgICB0aGlzLnNpZGViYXJUYWIuYW5pbWF0ZSh7bGVmdDogdGhpcy5zaWRlYmFyLndpZHRoKCkgKyBzaWRlYmFyUGFuZWxOZXdMZWZ0fSwgMTE1KTtcbiAgICB9LCAxMDApLFxuXG4gICAgLy8gUHJldHR5IG11Y2ggdGhlIGNvZGUgZm9yIHByZS1iYWNrLWJ1dHRvbiBzaWRlYmFyIHJlc2l6ZVxuICAgIHJlc2l6ZV9mb3Jfd2lkZTogXy5kZWJvdW5jZShmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIGN1cnJlbnRfbGV2ZWwgPSB0aGlzLnN0YXRlX21vZGVsLmdldChcImN1cnJlbnRfbGV2ZWxcIik7XG4gICAgICAgIHZhciBjb2x1bW5fd2lkdGggPSB0aGlzLiQoXCIudG9waWMtY29udGFpbmVyLWlubmVyXCIpLndpZHRoKCk7XG4gICAgICAgIHZhciBsYXN0X2NvbHVtbl93aWR0aCA9IDQwMDtcbiAgICAgICAgXG4gICAgICAgIHRoaXMud2lkdGggPSAoY3VycmVudF9sZXZlbC0xKSAqIGNvbHVtbl93aWR0aCArIGxhc3RfY29sdW1uX3dpZHRoICsgMTA7XG4gICAgICAgIHRoaXMuc2lkZWJhci53aWR0aCh0aGlzLndpZHRoKTtcbiAgICAgICAgdGhpcy5zaWRlYmFyLmNzcyh7bGVmdDogMH0pO1xuICAgICAgICB0aGlzLnNpZGViYXJUYWIuY3NzKHtsZWZ0OiB0aGlzLndpZHRofSk7XG4gICAgICAgIFxuICAgICAgICB0aGlzLnNldF9zaWRlYmFyX2JhY2soKTtcbiAgICB9LCAxMDApLFxuXG4gICAgY2hlY2tfZXh0ZXJuYWxfY2xpY2s6IGZ1bmN0aW9uKGV2KSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlX21vZGVsLmdldChcIm9wZW5cIikpIHtcbiAgICAgICAgICAgIHRoaXMuc3RhdGVfbW9kZWwuc2V0KFwib3BlblwiLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgdG9nZ2xlX3NpZGViYXI6IGZ1bmN0aW9uKGV2KSB7XG4gICAgICAgIHRoaXMuc3RhdGVfbW9kZWwuc2V0KFwib3BlblwiLCAhdGhpcy5zdGF0ZV9tb2RlbC5nZXQoXCJvcGVuXCIpKTtcblxuICAgICAgICAvLyBUT0RPIChydGliYmxlcyk6IEdldCByZW5kZXIgdG8gb25seSBydW4gYWZ0ZXIgYWxsIGxpc3RlblRvcyBoYXZlIGJlZW4gYm91bmQgYW5kIHJlbW92ZSB0aGlzLlxuICAgICAgICBpZiAoZXYgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgZXYucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfSxcblxuICAgIHVwZGF0ZV9zaWRlYmFyX3Zpc2liaWxpdHk6IF8uZGVib3VuY2UoZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmICh0aGlzLnN0YXRlX21vZGVsLmdldChcIm9wZW5cIikpIHtcbiAgICAgICAgICAgIC8vIFVzZWQgdG8gZ2V0IGxlZnQgdmFsdWUgaW4gbnVtYmVyIGZvcm1cbiAgICAgICAgICAgIHZhciBzaWRlYmFyUGFuZWxQb3NpdGlvbiA9IHRoaXMuc2lkZWJhci5wb3NpdGlvbigpO1xuICAgICAgICAgICAgdGhpcy5zaWRlYmFyLmNzcyh7bGVmdDogMH0pO1xuICAgICAgICAgICAgdGhpcy5yZXNpemVfc2lkZWJhcigpO1xuICAgICAgICAgICAgdGhpcy5zaWRlYmFyVGFiLmNzcyh7bGVmdDogdGhpcy5zaWRlYmFyLndpZHRoKCkgKyBzaWRlYmFyUGFuZWxQb3NpdGlvbi5sZWZ0fSkuaHRtbCgnPHNwYW4gY2xhc3M9XCJpY29uLWNpcmNsZS1sZWZ0XCI+PC9zcGFuPicpO1xuICAgICAgICAgICAgdGhpcy4kKFwiLnNpZGViYXItZmFkZVwiKS5zaG93KCk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnNpZGViYXIuY3NzKHtsZWZ0OiAtIHRoaXMud2lkdGh9KTtcbiAgICAgICAgICAgIHRoaXMuc2lkZWJhclRhYi5jc3Moe2xlZnQ6IDB9KS5odG1sKCc8c3BhbiBjbGFzcz1cImljb24tY2lyY2xlLXJpZ2h0XCI+PC9zcGFuPicpO1xuICAgICAgICAgICAgdGhpcy4kKFwiLnNpZGViYXItZmFkZVwiKS5oaWRlKCk7XG4gICAgICAgIH1cblxuICAgICAgICB0aGlzLnNldF9zaWRlYmFyX2JhY2soKTtcbiAgICB9LCAxMDApLFxuXG4gICAgc2V0X3NpZGViYXJfYmFjazogZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmICghdGhpcy5zdGF0ZV9tb2RlbC5nZXQoXCJvcGVuXCIpKSB7XG4gICAgICAgICAgICB0aGlzLnNpZGViYXJCYWNrLm9mZnNldCh7bGVmdDogLSh0aGlzLnNpZGViYXJCYWNrLndpZHRoKCkpfSk7XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIHRoaXMuc2lkZWJhckJhY2suaG92ZXIoXG4gICAgICAgICAgICBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAkKHRoaXMpLmFkZENsYXNzKFwic2lkZWJhci1iYWNrLWhvdmVyXCIpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgICQodGhpcykucmVtb3ZlQ2xhc3MoXCJzaWRlYmFyLWJhY2staG92ZXJcIik7XG4gICAgICAgICAgICB9KTtcblxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gVXNlZCB0byBnZXQgbGVmdCB2YWx1ZSBpbiBudW1iZXIgZm9ybVxuICAgICAgICB2YXIgc2lkZWJhclBhbmVsUG9zaXRpb24gPSB0aGlzLnNpZGViYXIucG9zaXRpb24oKTtcbiAgICAgICAgaWYgKHNpZGViYXJQYW5lbFBvc2l0aW9uLmxlZnQgIT09IDApIHtcbiAgICAgICAgICAgIHRoaXMuc2lkZWJhckJhY2sub2Zmc2V0KHtsZWZ0OiAwfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLnNpZGViYXJCYWNrLm9mZnNldCh7bGVmdDogLSh0aGlzLnNpZGViYXJCYWNrLndpZHRoKCkpfSk7XG4gICAgICAgIH1cblxuICAgICAgICAvLyBEaXNhYmxlIG9yIGVuYWJsZSB0aGUgYmFjayBidXR0b24gZGVwZW5kaW5nIG9uIHdoZXRoZXIgaXQgaXMgdmlzaWJsZSBvciBub3QuXG4gICAgICAgIGlmICh0aGlzLnNpZGViYXJCYWNrLnBvc2l0aW9uKCkubGVmdCA8PSAwKSB7XG4gICAgICAgICAgICB0aGlzLmRpc2FibGVfYmFja19idXR0b24oKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMuZW5hYmxlX2JhY2tfYnV0dG9uKCk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgZW5hYmxlX2JhY2tfYnV0dG9uOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5zaWRlYmFyQmFjay5maW5kKFwiYnV0dG9uXCIpLnJlbW92ZUF0dHIoXCJkaXNhYmxlZFwiKTtcbiAgICB9LFxuXG4gICAgZGlzYWJsZV9iYWNrX2J1dHRvbjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuc2lkZWJhckJhY2suZmluZChcImJ1dHRvblwiKS5hdHRyKFwiZGlzYWJsZWRcIiwgXCJkaXNhYmxlZFwiKTtcbiAgICB9LFxuXG4gICAgc2lkZWJhcl9iYWNrX29uZV9sZXZlbDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudG9waWNfbm9kZV92aWV3LmJhY2tfdG9fcGFyZW50KCk7XG4gICAgfSxcblxuICAgIHNob3dfc2lkZWJhcjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuc3RhdGVfbW9kZWwuc2V0KFwib3BlblwiLCB0cnVlKTtcbiAgICB9LFxuXG4gICAgaGlkZV9zaWRlYmFyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5zdGF0ZV9tb2RlbC5zZXQoXCJvcGVuXCIsIGZhbHNlKTtcbiAgICB9LFxuXG4gICAgc2hvd19zaWRlYmFyX3RhYjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuc2lkZWJhclRhYi5mYWRlSW4oMTE1KTtcbiAgICB9LFxuXG4gICAgaGlkZV9zaWRlYmFyX3RhYjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuc2lkZWJhclRhYi5mYWRlT3V0KDExNSk7XG4gICAgfSxcblxuICAgIG5hdmlnYXRlX3BhdGhzOiBmdW5jdGlvbihwYXRocywgY2FsbGJhY2spIHtcbiAgICAgICAgLy8gQWxsb3cgY2FsbGJhY2sgaGVyZSB0byBsZXQgdGhlICd0aXRsZScgb2YgdGhlIG5vZGUgYmUgcmV0dXJuZWQgdG8gdGhlIHJvdXRlclxuICAgICAgICAvLyBUaGlzIHdpbGwgYWxsb3cgdGhlIHRpdGxlIG9mIHRoZSBwYWdlIHRvIGJlIHVwZGF0ZWQgZHVyaW5nIG5hdmlnYXRpb24gZXZlbnRzXG4gICAgICAgIHRoaXMudG9waWNfbm9kZV92aWV3LmRlZmVyX25hdmlnYXRlX3BhdGhzKHBhdGhzLCBjYWxsYmFjayk7XG4gICAgfVxuXG59KTtcblxudmFyIFRvcGljQ29udGFpbmVySW5uZXJWaWV3ID0gQmFzZVZpZXcuZXh0ZW5kKHtcbiAgICBjbGFzc05hbWU6IFwidG9waWMtY29udGFpbmVyLWlubmVyXCIsXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoXCIuL2hidGVtcGxhdGVzL3NpZGViYXItY29udGVudC5oYW5kbGViYXJzXCIpLFxuXG4gICAgaW5pdGlhbGl6ZTogZnVuY3Rpb24ob3B0aW9ucykge1xuXG4gICAgICAgIF8uYmluZEFsbC5hcHBseShfLCBbdGhpc10uY29uY2F0KF8uZnVuY3Rpb25zKHRoaXMpKSk7XG5cbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgIHRoaXMuc3RhdGVfbW9kZWwgPSBvcHRpb25zLnN0YXRlX21vZGVsO1xuICAgICAgICB0aGlzLmVudGl0eV9rZXkgPSBvcHRpb25zLmVudGl0eV9rZXk7XG4gICAgICAgIHRoaXMuZW50aXR5X2NvbGxlY3Rpb24gPSBvcHRpb25zLmVudGl0eV9jb2xsZWN0aW9uO1xuICAgICAgICB0aGlzLmxldmVsID0gb3B0aW9ucy5sZXZlbDtcbiAgICAgICAgdGhpcy5fZW50cnlfdmlld3MgPSBbXTtcbiAgICAgICAgdGhpcy5oYXNfcGFyZW50ID0gb3B0aW9ucy5oYXNfcGFyZW50O1xuXG4gICAgICAgIHRoaXMuY29sbGVjdGlvbiA9IG5ldyB0aGlzLmVudGl0eV9jb2xsZWN0aW9uKHtwYXJlbnQ6IHRoaXMubW9kZWwuZ2V0KFwiaWRcIiksIGNoYW5uZWw6IHRoaXMuc3RhdGVfbW9kZWwuZ2V0KFwiY2hhbm5lbFwiKX0pO1xuXG4gICAgICAgIHRoaXMuY29sbGVjdGlvbi5mZXRjaCgpLnRoZW4odGhpcy5hZGRfYWxsX2VudHJpZXMpO1xuXG4gICAgICAgIHRoaXMuc3RhdGVfbW9kZWwuc2V0KFwiY3VycmVudF9sZXZlbFwiLCBvcHRpb25zLmxldmVsKTtcblxuICAgICAgICAvLyByZXNpemUgdGhlIHNjcm9sbGFibGUgcGFydCBvZiBzaWRlYmFyIHRvIHRoZSBwYWdlIGhlaWdodFxuICAgICAgICAkKHdpbmRvdykucmVzaXplKHNlbGYud2luZG93X3Jlc2l6ZV9jYWxsYmFjayk7XG5cbiAgICAgICAgLy8gV2hlbiBzY3JvbGxpbmcsIGluY3JlYXNlIHRoZSBoZWlnaHQgb2YgdGhlIGVsZW1lbnRcbiAgICAgICAgLy8gdW50aWwgaXQgZmlsbHMgdXAgdGhlIHNpZGViYXIgcGFuZWxcbiAgICAgICAgJCh3aW5kb3cpLnNjcm9sbChzZWxmLndpbmRvd19zY3JvbGxfY2FsbGJhY2spO1xuICAgIH0sXG5cbiAgICB3aW5kb3dfc2Nyb2xsX2NhbGxiYWNrOiBfLnRocm90dGxlKGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgc2lkZWJhckhlaWdodCA9ICQoXCIuc2lkZWJhci1wYW5lbFwiKS5oZWlnaHQoKTtcbiAgICAgICAgdmFyIGRlbHRhSGVpZ2h0ID0gJCh3aW5kb3cpLnNjcm9sbFRvcCgpICsgc2VsZi4kKFwiLnNsaW1TY3JvbGxEaXYsIC5zaWRlYmFyXCIpLmhlaWdodCgpO1xuICAgICAgICB2YXIgaGVpZ2h0ID0gTWF0aC5taW4oc2lkZWJhckhlaWdodCwgZGVsdGFIZWlnaHQpO1xuICAgICAgICBzZWxmLiQoXCIuc2xpbVNjcm9sbERpdiwgLnNpZGViYXJcIikuaGVpZ2h0KGhlaWdodCk7XG4gICAgfSwgMjAwKSxcblxuICAgIHdpbmRvd19yZXNpemVfY2FsbGJhY2s6IF8udGhyb3R0bGUoZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciBoZWlnaHQgPSAkKHdpbmRvdykuaGVpZ2h0KCk7XG4gICAgICAgIHNlbGYuJChcIi5zbGltU2Nyb2xsRGl2LCAuc2lkZWJhclwiKS5oZWlnaHQoaGVpZ2h0KTtcbiAgICB9LCAyMDApLFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgIHRoaXMuJGVsLmh0bWwodGhpcy50ZW1wbGF0ZSh0aGlzLm1vZGVsLmF0dHJpYnV0ZXMpKTtcblxuICAgICAgICAkKHRoaXMuJChcIi5zaWRlYmFyXCIpKS5zbGltU2Nyb2xsKHtcbiAgICAgICAgICAgIGNvbG9yOiBcIiMwODM1MDVcIixcbiAgICAgICAgICAgIG9wYWNpdHk6IDAuMixcbiAgICAgICAgICAgIHNpemU6IFwiNnB4XCIsXG4gICAgICAgICAgICBkaXN0YW5jZTogXCIxcHhcIixcbiAgICAgICAgICAgIGFsd2F5c1Zpc2libGU6IHRydWVcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gRW5zdXJlIHRoZXNlIGFyZSBjYWxsZWQgb25jZSBpbiBvcmRlciB0byBnZXQgdGhlIHJpZ2h0IHNpemUgaW5pdGlhbGx5LlxuICAgICAgICBfLmRlZmVyKCBmdW5jdGlvbigpIHtcbiAgICAgICAgICAgIHNlbGYud2luZG93X3Jlc2l6ZV9jYWxsYmFjaygpO1xuICAgICAgICAgICAgc2VsZi53aW5kb3dfc2Nyb2xsX2NhbGxiYWNrKCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH0sXG5cbiAgICBhZGRfbmV3X2VudHJ5OiBmdW5jdGlvbihlbnRyeSkge1xuICAgICAgICB2YXIgdmlldyA9IG5ldyBTaWRlYmFyRW50cnlWaWV3KHttb2RlbDogZW50cnl9KTtcbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh2aWV3LCBcImhpZGVTaWRlYmFyXCIsIHRoaXMuaGlkZV9zaWRlYmFyKTtcbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh2aWV3LCBcInNob3dTaWRlYmFyXCIsIHRoaXMuc2hvd19zaWRlYmFyKTtcbiAgICAgICAgdGhpcy5fZW50cnlfdmlld3MucHVzaCh2aWV3KTtcbiAgICAgICAgdGhpcy4kKFwiLnNpZGViYXJcIikuYXBwZW5kKHZpZXcucmVuZGVyKCkuJGVsKTtcbiAgICB9LFxuXG4gICAgYWRkX2FsbF9lbnRyaWVzOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcbiAgICAgICAgdGhpcy5jb2xsZWN0aW9uLmZvckVhY2godGhpcy5hZGRfbmV3X2VudHJ5LCB0aGlzKTtcbiAgICB9LFxuXG4gICAgc2hvdzogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuJGVsLnNob3coKTtcbiAgICB9LFxuXG4gICAgaGlkZTogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuJGVsLmhpZGUoKTtcbiAgICB9LFxuXG4gICAgaGlkZV9zaWRlYmFyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy50cmlnZ2VyKFwiaGlkZVNpZGViYXJcIik7XG4gICAgfSxcblxuICAgIHNob3dfc2lkZWJhcjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudHJpZ2dlcihcInNob3dTaWRlYmFyXCIpO1xuICAgIH0sXG5cbiAgICBkZWZlcnJlZF9ub2RlX2J5X3NsdWc6IGZ1bmN0aW9uKHNsdWcsIGNhbGxiYWNrKSB7XG4gICAgICAgIC8vIENvbnZlbmllbmNlIG1ldGhvZCB0byByZXR1cm4gYSBub2RlIGJ5IGEgcGFzc2VkIGluIHNsdWdcbiAgICAgICAgaWYgKHRoaXMuY29sbGVjdGlvbi5sb2FkZWQgPT09IHRydWUpIHtcbiAgICAgICAgICAgIHRoaXMubm9kZV9ieV9zbHVnKHNsdWcsIGNhbGxiYWNrKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHRoaXMubGlzdGVuVG9PbmNlKHRoaXMuY29sbGVjdGlvbiwgXCJzeW5jXCIsIGZ1bmN0aW9uKCkge3NlbGYubm9kZV9ieV9zbHVnKHNsdWcsIGNhbGxiYWNrKTt9KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBub2RlX2J5X3NsdWc6IGZ1bmN0aW9uKHNsdWcsIGNhbGxiYWNrKSB7XG4gICAgICAgIGNhbGxiYWNrKHRoaXMuY29sbGVjdGlvbi5maW5kV2hlcmUoe3NsdWc6IHNsdWd9KSk7XG4gICAgfSxcblxuICAgIGNsb3NlOiBmdW5jdGlvbigpIHtcbiAgICAgICAgXy5lYWNoKHRoaXMuX2VudHJ5X3ZpZXdzLCBmdW5jdGlvbih2aWV3KSB7XG4gICAgICAgICAgICB2aWV3Lm1vZGVsLnNldChcImFjdGl2ZVwiLCBmYWxzZSk7XG4gICAgICAgIH0pO1xuICAgICAgICB0aGlzLnJlbW92ZSgpO1xuICAgIH1cblxufSk7XG5cbnZhciBTaWRlYmFyRW50cnlWaWV3ID0gQmFzZVZpZXcuZXh0ZW5kKHtcblxuICAgIHRhZ05hbWU6IFwibGlcIixcblxuICAgIHRlbXBsYXRlOiByZXF1aXJlKFwiLi9oYnRlbXBsYXRlcy9zaWRlYmFyLWVudHJ5LmhhbmRsZWJhcnNcIiksXG5cbiAgICBldmVudHM6IHtcbiAgICAgICAgXCJjbGlja1wiOiBcImNsaWNrZWRcIlxuICAgIH0sXG5cbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbigpIHtcblxuICAgICAgICBfLmJpbmRBbGwodGhpcywgXCJyZW5kZXJcIik7XG5cbiAgICAgICAgdGhpcy5saXN0ZW5Ubyh0aGlzLm1vZGVsLCBcImNoYW5nZVwiLCB0aGlzLnJlbmRlcik7XG5cbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKHRoaXMubW9kZWwuYXR0cmlidXRlcykpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuXG4gICAgY2xpY2tlZDogZnVuY3Rpb24oZXYpIHtcbiAgICAgICAgZXYucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgaWYgKCF0aGlzLm1vZGVsLmdldChcImFjdGl2ZVwiKSkge1xuICAgICAgICAgICAgd2luZG93LmNoYW5uZWxfcm91dGVyLm5hdmlnYXRlKHRoaXMubW9kZWwuZ2V0KFwicGF0aFwiKSwge3RyaWdnZXI6IHRydWV9KTtcbiAgICAgICAgfSBlbHNlIGlmICh0aGlzLm1vZGVsLmdldChcImtpbmRcIikgIT09IFwiVG9waWNcIikge1xuICAgICAgICAgICAgdGhpcy50cmlnZ2VyKFwiaGlkZVNpZGViYXJcIik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cblxufSk7XG5cblxudmFyIFRvcGljQ29udGFpbmVyT3V0ZXJWaWV3ID0gQmFzZVZpZXcuZXh0ZW5kKHtcblxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKG9wdGlvbnMpIHtcblxuICAgICAgICB0aGlzLnJlbmRlciA9IF8uYmluZCh0aGlzLnJlbmRlciwgdGhpcyk7XG5cbiAgICAgICAgdGhpcy5zdGF0ZV9tb2RlbCA9IG9wdGlvbnMuc3RhdGVfbW9kZWw7XG5cbiAgICAgICAgdGhpcy5lbnRpdHlfa2V5ID0gb3B0aW9ucy5lbnRpdHlfa2V5O1xuICAgICAgICB0aGlzLmVudGl0eV9jb2xsZWN0aW9uID0gb3B0aW9ucy5lbnRpdHlfY29sbGVjdGlvbjtcblxuICAgICAgICB0aGlzLm1vZGVsID0gbmV3IE1vZGVscy5Ub3BpY05vZGUoe1wiaWRcIjogXCJyb290XCIsIFwidGl0bGVcIjogXCJLaGFuXCJ9KTtcblxuICAgICAgICB0aGlzLmlubmVyX3ZpZXdzID0gW107XG4gICAgICAgIHRoaXMucmVuZGVyKCk7XG4gICAgICAgIHRoaXMuY29udGVudF92aWV3ID0gbmV3IENvbnRlbnRBcmVhVmlldyh7XG4gICAgICAgICAgICBlbDogXCIjY29udGVudC1hcmVhXCJcbiAgICAgICAgfSk7XG5cbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5zaG93X25ld190b3BpYyh0aGlzLm1vZGVsKTtcbiAgICAgICAgdGhpcy50cmlnZ2VyKFwicmVuZGVyX2NvbXBsZXRlXCIpO1xuICAgIH0sXG5cbiAgICBzaG93X25ld190b3BpYzogZnVuY3Rpb24obm9kZSkge1xuXG4gICAgICAgIHZhciBuZXdfdG9waWMgPSB0aGlzLmFkZF9uZXdfdG9waWNfdmlldyhub2RlKTtcblxuICAgICAgICB0aGlzLiRlbC5hcHBlbmQobmV3X3RvcGljLmVsKTtcblxuICAgICAgICB0aGlzLnRyaWdnZXIoXCJpbm5lcl92aWV3X2FkZGVkXCIpO1xuXG4gICAgICAgIC8vIExpc3RlbmVyc1xuICAgICAgICB0aGlzLmxpc3RlblRvKG5ld190b3BpYywgJ2hpZGVTaWRlYmFyJywgdGhpcy5oaWRlX3NpZGViYXIpO1xuICAgICAgICB0aGlzLmxpc3RlblRvKG5ld190b3BpYywgJ3Nob3dTaWRlYmFyJywgdGhpcy5zaG93X3NpZGViYXIpO1xuICAgIH0sXG5cbiAgICBhZGRfbmV3X3RvcGljX3ZpZXc6IGZ1bmN0aW9uKG5vZGUpIHtcblxuICAgICAgICB0aGlzLnN0YXRlX21vZGVsLnNldChcImN1cnJlbnRfbGV2ZWxcIiwgdGhpcy5zdGF0ZV9tb2RlbC5nZXQoXCJjdXJyZW50X2xldmVsXCIpICsgMSk7XG5cbiAgICAgICAgdmFyIGRhdGEgPSB7XG4gICAgICAgICAgICBtb2RlbDogbm9kZSxcbiAgICAgICAgICAgIGhhc19wYXJlbnQ6IHRoaXMuaW5uZXJfdmlld3MubGVuZ3RoID49IDEsXG4gICAgICAgICAgICBlbnRpdHlfa2V5OiB0aGlzLmVudGl0eV9rZXksXG4gICAgICAgICAgICBlbnRpdHlfY29sbGVjdGlvbjogdGhpcy5lbnRpdHlfY29sbGVjdGlvbixcbiAgICAgICAgICAgIHN0YXRlX21vZGVsOiB0aGlzLnN0YXRlX21vZGVsLFxuICAgICAgICAgICAgbGV2ZWw6IHRoaXMuc3RhdGVfbW9kZWwuZ2V0KFwiY3VycmVudF9sZXZlbFwiKVxuICAgICAgICB9O1xuXG4gICAgICAgIHZhciBuZXdfdG9waWMgPSBuZXcgVG9waWNDb250YWluZXJJbm5lclZpZXcoZGF0YSk7XG5cbiAgICAgICAgdGhpcy5pbm5lcl92aWV3cy51bnNoaWZ0KG5ld190b3BpYyk7XG5cbiAgICAgICAgdGhpcy50cmlnZ2VyKFwibGVuZ3RoX1wiICsgdGhpcy5pbm5lcl92aWV3cy5sZW5ndGgpO1xuXG4gICAgICAgIHJldHVybiBuZXdfdG9waWM7XG4gICAgfSxcblxuICAgIGRlZmVyX25hdmlnYXRlX3BhdGhzOiBmdW5jdGlvbihwYXRocywgY2FsbGJhY2spIHtcbiAgICAgICAgaWYgKHRoaXMuaW5uZXJfdmlld3MubGVuZ3RoID09PSAwKXtcbiAgICAgICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgICAgIHRoaXMubGlzdGVuVG9PbmNlKHRoaXMsIFwicmVuZGVyX2NvbXBsZXRlXCIsIGZ1bmN0aW9uKCkge3NlbGYubmF2aWdhdGVfcGF0aHMocGF0aHMsIGNhbGxiYWNrKTt9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubmF2aWdhdGVfcGF0aHMocGF0aHMsIGNhbGxiYWNrKTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBuYXZpZ2F0ZV9wYXRoczogZnVuY3Rpb24ocGF0aHMsIGNhbGxiYWNrKSB7XG5cbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgIHZhciBjaGVja192aWV3cyA9IFtdO1xuICAgICAgICBmb3IgKHZhciBpID0gdGhpcy5pbm5lcl92aWV3cy5sZW5ndGggLSAyOyBpID49MDsgaS0tKSB7XG4gICAgICAgICAgICBjaGVja192aWV3cy5wdXNoKHRoaXMuaW5uZXJfdmlld3NbaV0pO1xuICAgICAgICB9XG4gICAgICAgIC8vIFNob3VsZCBvbmx5IGV2ZXIgcmVtb3ZlIGEgYnVuY2ggb2YgaW5uZXJfdmlld3Mgb25jZSBkdXJpbmcgdGhlIHdob2xlIGl0ZXJhdGlvblxuICAgICAgICB2YXIgcHJ1bmVkID0gZmFsc2U7XG4gICAgICAgIGZvciAoaSA9IDA7IGkgPCBwYXRocy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgdmFyIGNoZWNrX3ZpZXcgPSBjaGVja192aWV3c1tpXTtcbiAgICAgICAgICAgIGlmIChwYXRoc1tpXSE9PVwiXCIpIHtcbiAgICAgICAgICAgICAgICBpZiAoY2hlY2tfdmlldyE9PXVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoY2hlY2tfdmlldy5tb2RlbC5nZXQoXCJzbHVnXCIpPT1wYXRoc1tpXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjaGVja192aWV3Lm1vZGVsLnNldChcImFjdGl2ZVwiLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXBydW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlX3RvcGljX3ZpZXdzKGNoZWNrX3ZpZXdzLmxlbmd0aCAtIGkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBydW5lZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgdGhpcy5kZWZlcl9hZGRfdG9waWMocGF0aHNbaV0sIGkpO1xuICAgICAgICAgICAgfSBlbHNlIGlmICghcHJ1bmVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKGNoZWNrX3ZpZXchPT11bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgY2hlY2tfdmlldy5tb2RlbC5zZXQoXCJhY3RpdmVcIiwgZmFsc2UpO1xuICAgICAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZV90b3BpY192aWV3cyhjaGVja192aWV3cy5sZW5ndGggLSBpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKCFwcnVuZWQgJiYgKHBhdGhzLmxlbmd0aCA8IGNoZWNrX3ZpZXdzLmxlbmd0aCkpIHtcbiAgICAgICAgICAgIC8vIERvdWJsZSBjaGVjayB0aGF0IHBhdGhzIGFuZCBjaGVja192aWV3cyBhcmUgdGhlIHNhbWUgbGVuZ3RoXG4gICAgICAgICAgICB0aGlzLnJlbW92ZV90b3BpY192aWV3cyhjaGVja192aWV3cy5sZW5ndGggLSBwYXRocy5sZW5ndGgpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChjYWxsYmFjaykge1xuICAgICAgICAgICAgdGhpcy5zdG9wTGlzdGVuaW5nKHRoaXMsIFwiaW5uZXJfdmlld19hZGRlZFwiKTtcblxuICAgICAgICAgICAgdGhpcy5saXN0ZW5Ubyh0aGlzLCBcImlubmVyX3ZpZXdfYWRkZWRcIiwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2soc2VsZi5pbm5lcl92aWV3c1swXS5tb2RlbC5nZXQoXCJ0aXRsZVwiKSk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBkZWZlcl9hZGRfdG9waWM6IGZ1bmN0aW9uKHBhdGgsIHZpZXdfbGVuZ3RoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgaWYgKHRoaXMuaW5uZXJfdmlld3MubGVuZ3RoPT12aWV3X2xlbmd0aCArIDEpIHtcbiAgICAgICAgICAgIHRoaXMuYWRkX3RvcGljX2Zyb21faW5uZXJfdmlldyhwYXRoKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMubGlzdGVuVG9PbmNlKHRoaXMsIFwibGVuZ3RoX1wiICsgKHZpZXdfbGVuZ3RoICsgMSksIGZ1bmN0aW9uKCkge3NlbGYuYWRkX3RvcGljX2Zyb21faW5uZXJfdmlldyhwYXRoKTt9KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBhZGRfdG9waWNfZnJvbV9pbm5lcl92aWV3OiBmdW5jdGlvbihwYXRoKSB7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICB0aGlzLmlubmVyX3ZpZXdzWzBdLmRlZmVycmVkX25vZGVfYnlfc2x1ZyhwYXRoLCBmdW5jdGlvbihub2RlKXtcbiAgICAgICAgICAgIGlmIChub2RlIT09dW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgaWYgKG5vZGUuZ2V0KFwia2luZFwiKT09PVwiVG9waWNcIikge1xuICAgICAgICAgICAgICAgICAgICBzZWxmLnNob3dfbmV3X3RvcGljKG5vZGUpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuZW50cnlfcmVxdWVzdGVkKG5vZGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBub2RlLnNldChcImFjdGl2ZVwiLCB0cnVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSxcblxuICAgIHJlbW92ZV90b3BpY192aWV3czogZnVuY3Rpb24obnVtYmVyKSB7XG4gICAgICAgIGZvciAodmFyIGk9MDsgaSA8IG51bWJlcjsgaSsrKSB7XG4gICAgICAgICAgICBpZiAodGhpcy5pbm5lcl92aWV3c1swXSkge1xuICAgICAgICAgICAgICAgIHRoaXMuaW5uZXJfdmlld3NbMF0ubW9kZWwuc2V0KFwiYWN0aXZlXCIsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICBpZiAoXy5pc0Z1bmN0aW9uKHRoaXMuaW5uZXJfdmlld3NbMF0uY2xvc2UpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuaW5uZXJfdmlld3NbMF0uY2xvc2UoKTtcbiAgICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLmlubmVyX3ZpZXdzWzBdLnJlbW92ZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB0aGlzLmlubmVyX3ZpZXdzLnNoaWZ0KCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuc3RhdGVfbW9kZWwuZ2V0KFwiY29udGVudF9kaXNwbGF5ZWRcIikpIHtcbiAgICAgICAgICAgIG51bWJlci0tO1xuICAgICAgICAgICAgdGhpcy5zdGF0ZV9tb2RlbC5zZXQoXCJjb250ZW50X2Rpc3BsYXllZFwiLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5zdGF0ZV9tb2RlbC5zZXQoXCJjdXJyZW50X2xldmVsXCIsIHRoaXMuc3RhdGVfbW9kZWwuZ2V0KFwiY3VycmVudF9sZXZlbFwiKSAtIG51bWJlcik7XG4gICAgICAgIHRoaXMuc2hvd19zaWRlYmFyKCk7XG4gICAgfSxcblxuICAgIGJhY2tfdG9fcGFyZW50OiBmdW5jdGlvbigpIHtcbiAgICAgICAgd2luZG93LmNoYW5uZWxfcm91dGVyLnVybF9iYWNrKCk7XG4gICAgfSxcblxuICAgIGVudHJ5X3JlcXVlc3RlZDogZnVuY3Rpb24oZW50cnkpIHtcbiAgICAgICAgdmFyIGtpbmQgPSBlbnRyeS5nZXQoXCJraW5kXCIpIHx8IGVudHJ5LmdldChcImVudGl0eV9raW5kXCIpO1xuICAgICAgICB2YXIgaWQgPSBlbnRyeS5nZXQoXCJpZFwiKSB8fCBlbnRyeS5nZXQoXCJlbnRpdHlfaWRcIik7XG5cbiAgICAgICAgdGhpcy5jb250ZW50X3ZpZXcubW9kZWwgPSBlbnRyeTtcbiAgICAgICAgLy8gVGhlIHJhdGluZyBzdWJ2aWV3IGRlcGVuZHMgb24gdGhlIGNvbnRlbnRfdmlldy5tb2RlbCwgYnV0IHdlIGNhbid0IGp1c3QgbGlzdGVuIHRvIGV2ZW50cyBvbiB0aGUgbW9kZWxcbiAgICAgICAgLy8gdG8gdHJpZ2dlciBzaG93X3JhdGluZywgc2luY2UgdGhlIGFjdHVhbCBvYmplY3QgaXMgc3dhcHBlZCBvdXQgaGVyZS4gV2UgbXVzdCBjYWxsIGl0IGV4cGxpY2l0bHkuXG4gICAgICAgIHRoaXMuY29udGVudF92aWV3LnNob3dfcmF0aW5nKCk7XG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICB2YXIgdmlldyA9IG5ldyBDb250ZW50Vmlld3MuQ29udGVudFdyYXBwZXJWaWV3KHtcbiAgICAgICAgICAgIGlkOiBpZCxcbiAgICAgICAgICAgIGtpbmQ6IGtpbmQsXG4gICAgICAgICAgICBjb250ZXh0X2lkOiB0aGlzLm1vZGVsLmdldChcImlkXCIpLFxuICAgICAgICAgICAgY2hhbm5lbDogd2luZG93LmNoYW5uZWxfcm91dGVyLmNoYW5uZWxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgdGhpcy5jb250ZW50X3ZpZXcuc2hvd192aWV3KHZpZXcpO1xuXG4gICAgICAgIHRoaXMuaW5uZXJfdmlld3MudW5zaGlmdCh0aGlzLmNvbnRlbnRfdmlldyk7XG4gICAgICAgIHRoaXMudHJpZ2dlcihcImlubmVyX3ZpZXdfYWRkZWRcIik7XG4gICAgICAgIHRoaXMuc3RhdGVfbW9kZWwuc2V0KFwiY29udGVudF9kaXNwbGF5ZWRcIiwgdHJ1ZSk7XG4gICAgICAgIHRoaXMuaGlkZV9zaWRlYmFyKCk7XG4gICAgfSxcblxuICAgIGhpZGVfc2lkZWJhcjogZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMudHJpZ2dlcihcImhpZGVTaWRlYmFyXCIpO1xuICAgIH0sXG5cbiAgICBzaG93X3NpZGViYXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnRyaWdnZXIoXCJzaG93U2lkZWJhclwiKTtcbiAgICB9XG59KTtcblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gICAgU2lkZWJhclZpZXc6IFNpZGViYXJWaWV3LFxuICAgIFNpZGViYXJFbnRyeVZpZXc6IFNpZGViYXJFbnRyeVZpZXcsXG4gICAgVG9waWNDb250YWluZXJJbm5lclZpZXc6IFRvcGljQ29udGFpbmVySW5uZXJWaWV3LFxuICAgIFRvcGljQ29udGFpbmVyT3V0ZXJWaWV3OiBUb3BpY0NvbnRhaW5lck91dGVyVmlldyxcbiAgICBDb250ZW50QXJlYVZpZXc6IENvbnRlbnRBcmVhVmlld1xufTtcbiIsIi8qISBDb3B5cmlnaHQgKGMpIDIwMTEgUGlvdHIgUm9jaGFsYSAoaHR0cDovL3JvY2hhLmxhKVxuICogRHVhbCBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIChodHRwOi8vd3d3Lm9wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL21pdC1saWNlbnNlLnBocClcbiAqIGFuZCBHUEwgKGh0dHA6Ly93d3cub3BlbnNvdXJjZS5vcmcvbGljZW5zZXMvZ3BsLWxpY2Vuc2UucGhwKSBsaWNlbnNlcy5cbiAqXG4gKiBWZXJzaW9uOiAxLjMuNlxuICpcbiAqL1xuKGZ1bmN0aW9uKCQpIHtcblxuICAkLmZuLmV4dGVuZCh7XG4gICAgc2xpbVNjcm9sbDogZnVuY3Rpb24ob3B0aW9ucykge1xuXG4gICAgICB2YXIgZGVmYXVsdHMgPSB7XG5cbiAgICAgICAgLy8gd2lkdGggaW4gcGl4ZWxzIG9mIHRoZSB2aXNpYmxlIHNjcm9sbCBhcmVhXG4gICAgICAgIHdpZHRoIDogJ2F1dG8nLFxuXG4gICAgICAgIC8vIGhlaWdodCBpbiBwaXhlbHMgb2YgdGhlIHZpc2libGUgc2Nyb2xsIGFyZWFcbiAgICAgICAgaGVpZ2h0IDogJzI1MHB4JyxcblxuICAgICAgICAvLyB3aWR0aCBpbiBwaXhlbHMgb2YgdGhlIHNjcm9sbGJhciBhbmQgcmFpbFxuICAgICAgICBzaXplIDogJzdweCcsXG5cbiAgICAgICAgLy8gc2Nyb2xsYmFyIGNvbG9yLCBhY2NlcHRzIGFueSBoZXgvY29sb3IgdmFsdWVcbiAgICAgICAgY29sb3I6ICcjMDAwJyxcblxuICAgICAgICAvLyBzY3JvbGxiYXIgcG9zaXRpb24gLSBsZWZ0L3JpZ2h0XG4gICAgICAgIHBvc2l0aW9uIDogJ3JpZ2h0JyxcblxuICAgICAgICAvLyBkaXN0YW5jZSBpbiBwaXhlbHMgYmV0d2VlbiB0aGUgc2lkZSBlZGdlIGFuZCB0aGUgc2Nyb2xsYmFyXG4gICAgICAgIGRpc3RhbmNlIDogJzFweCcsXG5cbiAgICAgICAgLy8gZGVmYXVsdCBzY3JvbGwgcG9zaXRpb24gb24gbG9hZCAtIHRvcCAvIGJvdHRvbSAvICQoJ3NlbGVjdG9yJylcbiAgICAgICAgc3RhcnQgOiAndG9wJyxcblxuICAgICAgICAvLyBzZXRzIHNjcm9sbGJhciBvcGFjaXR5XG4gICAgICAgIG9wYWNpdHkgOiAuNCxcblxuICAgICAgICAvLyBlbmFibGVzIGFsd2F5cy1vbiBtb2RlIGZvciB0aGUgc2Nyb2xsYmFyXG4gICAgICAgIGFsd2F5c1Zpc2libGUgOiBmYWxzZSxcblxuICAgICAgICAvLyBjaGVjayBpZiB3ZSBzaG91bGQgaGlkZSB0aGUgc2Nyb2xsYmFyIHdoZW4gdXNlciBpcyBob3ZlcmluZyBvdmVyXG4gICAgICAgIGRpc2FibGVGYWRlT3V0IDogZmFsc2UsXG5cbiAgICAgICAgLy8gc2V0cyB2aXNpYmlsaXR5IG9mIHRoZSByYWlsXG4gICAgICAgIHJhaWxWaXNpYmxlIDogZmFsc2UsXG5cbiAgICAgICAgLy8gc2V0cyByYWlsIGNvbG9yXG4gICAgICAgIHJhaWxDb2xvciA6ICcjMzMzJyxcblxuICAgICAgICAvLyBzZXRzIHJhaWwgb3BhY2l0eVxuICAgICAgICByYWlsT3BhY2l0eSA6IC4yLFxuXG4gICAgICAgIC8vIHdoZXRoZXIgIHdlIHNob3VsZCB1c2UgalF1ZXJ5IFVJIERyYWdnYWJsZSB0byBlbmFibGUgYmFyIGRyYWdnaW5nXG4gICAgICAgIHJhaWxEcmFnZ2FibGUgOiB0cnVlLFxuXG4gICAgICAgIC8vIGRlZmF1dGx0IENTUyBjbGFzcyBvZiB0aGUgc2xpbXNjcm9sbCByYWlsXG4gICAgICAgIHJhaWxDbGFzcyA6ICdzbGltU2Nyb2xsUmFpbCcsXG5cbiAgICAgICAgLy8gZGVmYXV0bHQgQ1NTIGNsYXNzIG9mIHRoZSBzbGltc2Nyb2xsIGJhclxuICAgICAgICBiYXJDbGFzcyA6ICdzbGltU2Nyb2xsQmFyJyxcblxuICAgICAgICAvLyBkZWZhdXRsdCBDU1MgY2xhc3Mgb2YgdGhlIHNsaW1zY3JvbGwgd3JhcHBlclxuICAgICAgICB3cmFwcGVyQ2xhc3MgOiAnc2xpbVNjcm9sbERpdicsXG5cbiAgICAgICAgLy8gY2hlY2sgaWYgbW91c2V3aGVlbCBzaG91bGQgc2Nyb2xsIHRoZSB3aW5kb3cgaWYgd2UgcmVhY2ggdG9wL2JvdHRvbVxuICAgICAgICBhbGxvd1BhZ2VTY3JvbGwgOiBmYWxzZSxcblxuICAgICAgICAvLyBzY3JvbGwgYW1vdW50IGFwcGxpZWQgdG8gZWFjaCBtb3VzZSB3aGVlbCBzdGVwXG4gICAgICAgIHdoZWVsU3RlcCA6IDIwLFxuXG4gICAgICAgIC8vIHNjcm9sbCBhbW91bnQgYXBwbGllZCB3aGVuIHVzZXIgaXMgdXNpbmcgZ2VzdHVyZXNcbiAgICAgICAgdG91Y2hTY3JvbGxTdGVwIDogMjAwLFxuXG4gICAgICAgIC8vIHNldHMgYm9yZGVyIHJhZGl1c1xuICAgICAgICBib3JkZXJSYWRpdXM6ICc3cHgnLFxuXG4gICAgICAgIC8vIHNldHMgYm9yZGVyIHJhZGl1cyBvZiB0aGUgcmFpbFxuICAgICAgICByYWlsQm9yZGVyUmFkaXVzIDogJzdweCdcbiAgICAgIH07XG5cbiAgICAgIHZhciBvID0gJC5leHRlbmQoZGVmYXVsdHMsIG9wdGlvbnMpO1xuXG4gICAgICAvLyBkbyBpdCBmb3IgZXZlcnkgZWxlbWVudCB0aGF0IG1hdGNoZXMgc2VsZWN0b3JcbiAgICAgIHRoaXMuZWFjaChmdW5jdGlvbigpe1xuXG4gICAgICB2YXIgaXNPdmVyUGFuZWwsIGlzT3ZlckJhciwgaXNEcmFnZywgcXVldWVIaWRlLCB0b3VjaERpZixcbiAgICAgICAgYmFySGVpZ2h0LCBwZXJjZW50U2Nyb2xsLCBsYXN0U2Nyb2xsLFxuICAgICAgICBkaXZTID0gJzxkaXY+PC9kaXY+JyxcbiAgICAgICAgbWluQmFySGVpZ2h0ID0gMzAsXG4gICAgICAgIHJlbGVhc2VTY3JvbGwgPSBmYWxzZTtcblxuICAgICAgICAvLyB1c2VkIGluIGV2ZW50IGhhbmRsZXJzIGFuZCBmb3IgYmV0dGVyIG1pbmlmaWNhdGlvblxuICAgICAgICB2YXIgbWUgPSAkKHRoaXMpO1xuXG4gICAgICAgIC8vIGVuc3VyZSB3ZSBhcmUgbm90IGJpbmRpbmcgaXQgYWdhaW5cbiAgICAgICAgaWYgKG1lLnBhcmVudCgpLmhhc0NsYXNzKG8ud3JhcHBlckNsYXNzKSlcbiAgICAgICAge1xuICAgICAgICAgICAgLy8gc3RhcnQgZnJvbSBsYXN0IGJhciBwb3NpdGlvblxuICAgICAgICAgICAgdmFyIG9mZnNldCA9IG1lLnNjcm9sbFRvcCgpO1xuXG4gICAgICAgICAgICAvLyBmaW5kIGJhciBhbmQgcmFpbFxuICAgICAgICAgICAgYmFyID0gbWUuY2xvc2VzdCgnLicgKyBvLmJhckNsYXNzKTtcbiAgICAgICAgICAgIHJhaWwgPSBtZS5jbG9zZXN0KCcuJyArIG8ucmFpbENsYXNzKTtcblxuICAgICAgICAgICAgZ2V0QmFySGVpZ2h0KCk7XG5cbiAgICAgICAgICAgIC8vIGNoZWNrIGlmIHdlIHNob3VsZCBzY3JvbGwgZXhpc3RpbmcgaW5zdGFuY2VcbiAgICAgICAgICAgIGlmICgkLmlzUGxhaW5PYmplY3Qob3B0aW9ucykpXG4gICAgICAgICAgICB7XG4gICAgICAgICAgICAgIC8vIFBhc3MgaGVpZ2h0OiBhdXRvIHRvIGFuIGV4aXN0aW5nIHNsaW1zY3JvbGwgb2JqZWN0IHRvIGZvcmNlIGEgcmVzaXplIGFmdGVyIGNvbnRlbnRzIGhhdmUgY2hhbmdlZFxuICAgICAgICAgICAgICBpZiAoICdoZWlnaHQnIGluIG9wdGlvbnMgJiYgb3B0aW9ucy5oZWlnaHQgPT0gJ2F1dG8nICkge1xuICAgICAgICAgICAgICAgIG1lLnBhcmVudCgpLmNzcygnaGVpZ2h0JywgJ2F1dG8nKTtcbiAgICAgICAgICAgICAgICBtZS5jc3MoJ2hlaWdodCcsICdhdXRvJyk7XG4gICAgICAgICAgICAgICAgdmFyIGhlaWdodCA9IG1lLnBhcmVudCgpLnBhcmVudCgpLmhlaWdodCgpO1xuICAgICAgICAgICAgICAgIG1lLnBhcmVudCgpLmNzcygnaGVpZ2h0JywgaGVpZ2h0KTtcbiAgICAgICAgICAgICAgICBtZS5jc3MoJ2hlaWdodCcsIGhlaWdodCk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpZiAoJ3Njcm9sbFRvJyBpbiBvcHRpb25zKVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgLy8ganVtcCB0byBhIHN0YXRpYyBwb2ludFxuICAgICAgICAgICAgICAgIG9mZnNldCA9IHBhcnNlSW50KG8uc2Nyb2xsVG8pO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2UgaWYgKCdzY3JvbGxCeScgaW4gb3B0aW9ucylcbiAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIC8vIGp1bXAgYnkgdmFsdWUgcGl4ZWxzXG4gICAgICAgICAgICAgICAgb2Zmc2V0ICs9IHBhcnNlSW50KG8uc2Nyb2xsQnkpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGVsc2UgaWYgKCdkZXN0cm95JyBpbiBvcHRpb25zKVxuICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgLy8gcmVtb3ZlIHNsaW1zY3JvbGwgZWxlbWVudHNcbiAgICAgICAgICAgICAgICBiYXIucmVtb3ZlKCk7XG4gICAgICAgICAgICAgICAgcmFpbC5yZW1vdmUoKTtcbiAgICAgICAgICAgICAgICBtZS51bndyYXAoKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAvLyBzY3JvbGwgY29udGVudCBieSB0aGUgZ2l2ZW4gb2Zmc2V0XG4gICAgICAgICAgICAgIHNjcm9sbENvbnRlbnQob2Zmc2V0LCBmYWxzZSwgdHJ1ZSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICgkLmlzUGxhaW5PYmplY3Qob3B0aW9ucykpXG4gICAgICAgIHtcbiAgICAgICAgICAgIGlmICgnZGVzdHJveScgaW4gb3B0aW9ucylcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgIFx0cmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gb3B0aW9uYWxseSBzZXQgaGVpZ2h0IHRvIHRoZSBwYXJlbnQncyBoZWlnaHRcbiAgICAgICAgby5oZWlnaHQgPSAoby5oZWlnaHQgPT0gJ2F1dG8nKSA/IG1lLnBhcmVudCgpLmhlaWdodCgpIDogby5oZWlnaHQ7XG5cbiAgICAgICAgLy8gd3JhcCBjb250ZW50XG4gICAgICAgIHZhciB3cmFwcGVyID0gJChkaXZTKVxuICAgICAgICAgIC5hZGRDbGFzcyhvLndyYXBwZXJDbGFzcylcbiAgICAgICAgICAuY3NzKHtcbiAgICAgICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICAgICAgd2lkdGg6IG8ud2lkdGgsXG4gICAgICAgICAgICBoZWlnaHQ6IG8uaGVpZ2h0XG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gdXBkYXRlIHN0eWxlIGZvciB0aGUgZGl2XG4gICAgICAgIG1lLmNzcyh7XG4gICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICAgIHdpZHRoOiBvLndpZHRoLFxuICAgICAgICAgIGhlaWdodDogby5oZWlnaHRcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gY3JlYXRlIHNjcm9sbGJhciByYWlsXG4gICAgICAgIHZhciByYWlsID0gJChkaXZTKVxuICAgICAgICAgIC5hZGRDbGFzcyhvLnJhaWxDbGFzcylcbiAgICAgICAgICAuY3NzKHtcbiAgICAgICAgICAgIHdpZHRoOiBvLnNpemUsXG4gICAgICAgICAgICBoZWlnaHQ6ICcxMDAlJyxcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICAgICAgdG9wOiAwLFxuICAgICAgICAgICAgZGlzcGxheTogKG8uYWx3YXlzVmlzaWJsZSAmJiBvLnJhaWxWaXNpYmxlKSA/ICdibG9jaycgOiAnbm9uZScsXG4gICAgICAgICAgICAnYm9yZGVyLXJhZGl1cyc6IG8ucmFpbEJvcmRlclJhZGl1cyxcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IG8ucmFpbENvbG9yLFxuICAgICAgICAgICAgb3BhY2l0eTogby5yYWlsT3BhY2l0eSxcbiAgICAgICAgICAgIHpJbmRleDogOTBcbiAgICAgICAgICB9KTtcblxuICAgICAgICAvLyBjcmVhdGUgc2Nyb2xsYmFyXG4gICAgICAgIHZhciBiYXIgPSAkKGRpdlMpXG4gICAgICAgICAgLmFkZENsYXNzKG8uYmFyQ2xhc3MpXG4gICAgICAgICAgLmNzcyh7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBvLmNvbG9yLFxuICAgICAgICAgICAgd2lkdGg6IG8uc2l6ZSxcbiAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxuICAgICAgICAgICAgdG9wOiAwLFxuICAgICAgICAgICAgb3BhY2l0eTogby5vcGFjaXR5LFxuICAgICAgICAgICAgZGlzcGxheTogby5hbHdheXNWaXNpYmxlID8gJ2Jsb2NrJyA6ICdub25lJyxcbiAgICAgICAgICAgICdib3JkZXItcmFkaXVzJyA6IG8uYm9yZGVyUmFkaXVzLFxuICAgICAgICAgICAgQm9yZGVyUmFkaXVzOiBvLmJvcmRlclJhZGl1cyxcbiAgICAgICAgICAgIE1vekJvcmRlclJhZGl1czogby5ib3JkZXJSYWRpdXMsXG4gICAgICAgICAgICBXZWJraXRCb3JkZXJSYWRpdXM6IG8uYm9yZGVyUmFkaXVzLFxuICAgICAgICAgICAgekluZGV4OiA5OVxuICAgICAgICAgIH0pO1xuXG4gICAgICAgIC8vIHNldCBwb3NpdGlvblxuICAgICAgICB2YXIgcG9zQ3NzID0gKG8ucG9zaXRpb24gPT0gJ3JpZ2h0JykgPyB7IHJpZ2h0OiBvLmRpc3RhbmNlIH0gOiB7IGxlZnQ6IG8uZGlzdGFuY2UgfTtcbiAgICAgICAgcmFpbC5jc3MocG9zQ3NzKTtcbiAgICAgICAgYmFyLmNzcyhwb3NDc3MpO1xuXG4gICAgICAgIC8vIHdyYXAgaXRcbiAgICAgICAgbWUud3JhcCh3cmFwcGVyKTtcblxuICAgICAgICAvLyBhcHBlbmQgdG8gcGFyZW50IGRpdlxuICAgICAgICBtZS5wYXJlbnQoKS5hcHBlbmQoYmFyKTtcbiAgICAgICAgbWUucGFyZW50KCkuYXBwZW5kKHJhaWwpO1xuXG4gICAgICAgIC8vIG1ha2UgaXQgZHJhZ2dhYmxlIGFuZCBubyBsb25nZXIgZGVwZW5kZW50IG9uIHRoZSBqcXVlcnlVSVxuICAgICAgICBpZiAoby5yYWlsRHJhZ2dhYmxlKXtcbiAgICAgICAgICBiYXIuYmluZChcIm1vdXNlZG93blwiLCBmdW5jdGlvbihlKSB7XG4gICAgICAgICAgICB2YXIgJGRvYyA9ICQoZG9jdW1lbnQpO1xuICAgICAgICAgICAgaXNEcmFnZyA9IHRydWU7XG4gICAgICAgICAgICB0ID0gcGFyc2VGbG9hdChiYXIuY3NzKCd0b3AnKSk7XG4gICAgICAgICAgICBwYWdlWSA9IGUucGFnZVk7XG5cbiAgICAgICAgICAgICRkb2MuYmluZChcIm1vdXNlbW92ZS5zbGltc2Nyb2xsXCIsIGZ1bmN0aW9uKGUpe1xuICAgICAgICAgICAgICBjdXJyVG9wID0gdCArIGUucGFnZVkgLSBwYWdlWTtcbiAgICAgICAgICAgICAgYmFyLmNzcygndG9wJywgY3VyclRvcCk7XG4gICAgICAgICAgICAgIHNjcm9sbENvbnRlbnQoMCwgYmFyLnBvc2l0aW9uKCkudG9wLCBmYWxzZSk7Ly8gc2Nyb2xsIGNvbnRlbnRcbiAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAkZG9jLmJpbmQoXCJtb3VzZXVwLnNsaW1zY3JvbGxcIiwgZnVuY3Rpb24oZSkge1xuICAgICAgICAgICAgICBpc0RyYWdnID0gZmFsc2U7aGlkZUJhcigpO1xuICAgICAgICAgICAgICAkZG9jLnVuYmluZCgnLnNsaW1zY3JvbGwnKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH0pLmJpbmQoXCJzZWxlY3RzdGFydC5zbGltc2Nyb2xsXCIsIGZ1bmN0aW9uKGUpe1xuICAgICAgICAgICAgZS5zdG9wUHJvcGFnYXRpb24oKTtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIG9uIHJhaWwgb3ZlclxuICAgICAgICByYWlsLmhvdmVyKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgc2hvd0JhcigpO1xuICAgICAgICB9LCBmdW5jdGlvbigpe1xuICAgICAgICAgIGhpZGVCYXIoKTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gb24gYmFyIG92ZXJcbiAgICAgICAgYmFyLmhvdmVyKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgaXNPdmVyQmFyID0gdHJ1ZTtcbiAgICAgICAgfSwgZnVuY3Rpb24oKXtcbiAgICAgICAgICBpc092ZXJCYXIgPSBmYWxzZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgLy8gc2hvdyBvbiBwYXJlbnQgbW91c2VvdmVyXG4gICAgICAgIG1lLmhvdmVyKGZ1bmN0aW9uKCl7XG4gICAgICAgICAgaXNPdmVyUGFuZWwgPSB0cnVlO1xuICAgICAgICAgIHNob3dCYXIoKTtcbiAgICAgICAgICBoaWRlQmFyKCk7XG4gICAgICAgIH0sIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgaXNPdmVyUGFuZWwgPSBmYWxzZTtcbiAgICAgICAgICBoaWRlQmFyKCk7XG4gICAgICAgIH0pO1xuXG4gICAgICAgIC8vIHN1cHBvcnQgZm9yIG1vYmlsZVxuICAgICAgICBtZS5iaW5kKCd0b3VjaHN0YXJ0JywgZnVuY3Rpb24oZSxiKXtcbiAgICAgICAgICBpZiAoZS5vcmlnaW5hbEV2ZW50LnRvdWNoZXMubGVuZ3RoKVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIC8vIHJlY29yZCB3aGVyZSB0b3VjaCBzdGFydGVkXG4gICAgICAgICAgICB0b3VjaERpZiA9IGUub3JpZ2luYWxFdmVudC50b3VjaGVzWzBdLnBhZ2VZO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG5cbiAgICAgICAgbWUuYmluZCgndG91Y2htb3ZlJywgZnVuY3Rpb24oZSl7XG4gICAgICAgICAgLy8gcHJldmVudCBzY3JvbGxpbmcgdGhlIHBhZ2UgaWYgbmVjZXNzYXJ5XG4gICAgICAgICAgaWYoIXJlbGVhc2VTY3JvbGwpXG4gICAgICAgICAge1xuICBcdFx0ICAgICAgZS5vcmlnaW5hbEV2ZW50LnByZXZlbnREZWZhdWx0KCk7XG5cdFx0ICAgICAgfVxuICAgICAgICAgIGlmIChlLm9yaWdpbmFsRXZlbnQudG91Y2hlcy5sZW5ndGgpXG4gICAgICAgICAge1xuICAgICAgICAgICAgLy8gc2VlIGhvdyBmYXIgdXNlciBzd2lwZWRcbiAgICAgICAgICAgIHZhciBkaWZmID0gKHRvdWNoRGlmIC0gZS5vcmlnaW5hbEV2ZW50LnRvdWNoZXNbMF0ucGFnZVkpIC8gby50b3VjaFNjcm9sbFN0ZXA7XG4gICAgICAgICAgICAvLyBzY3JvbGwgY29udGVudFxuICAgICAgICAgICAgc2Nyb2xsQ29udGVudChkaWZmLCB0cnVlKTtcbiAgICAgICAgICAgIHRvdWNoRGlmID0gZS5vcmlnaW5hbEV2ZW50LnRvdWNoZXNbMF0ucGFnZVk7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcblxuICAgICAgICAvLyBzZXQgdXAgaW5pdGlhbCBoZWlnaHRcbiAgICAgICAgZ2V0QmFySGVpZ2h0KCk7XG5cbiAgICAgICAgLy8gY2hlY2sgc3RhcnQgcG9zaXRpb25cbiAgICAgICAgaWYgKG8uc3RhcnQgPT09ICdib3R0b20nKVxuICAgICAgICB7XG4gICAgICAgICAgLy8gc2Nyb2xsIGNvbnRlbnQgdG8gYm90dG9tXG4gICAgICAgICAgYmFyLmNzcyh7IHRvcDogbWUub3V0ZXJIZWlnaHQoKSAtIGJhci5vdXRlckhlaWdodCgpIH0pO1xuICAgICAgICAgIHNjcm9sbENvbnRlbnQoMCwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoby5zdGFydCAhPT0gJ3RvcCcpXG4gICAgICAgIHtcbiAgICAgICAgICAvLyBhc3N1bWUgalF1ZXJ5IHNlbGVjdG9yXG4gICAgICAgICAgc2Nyb2xsQ29udGVudCgkKG8uc3RhcnQpLnBvc2l0aW9uKCkudG9wLCBudWxsLCB0cnVlKTtcblxuICAgICAgICAgIC8vIG1ha2Ugc3VyZSBiYXIgc3RheXMgaGlkZGVuXG4gICAgICAgICAgaWYgKCFvLmFsd2F5c1Zpc2libGUpIHsgYmFyLmhpZGUoKTsgfVxuICAgICAgICB9XG5cbiAgICAgICAgLy8gYXR0YWNoIHNjcm9sbCBldmVudHNcbiAgICAgICAgYXR0YWNoV2hlZWwodGhpcyk7XG5cbiAgICAgICAgZnVuY3Rpb24gX29uV2hlZWwoZSlcbiAgICAgICAge1xuICAgICAgICAgIC8vIHVzZSBtb3VzZSB3aGVlbCBvbmx5IHdoZW4gbW91c2UgaXMgb3ZlclxuICAgICAgICAgIGlmICghaXNPdmVyUGFuZWwpIHsgcmV0dXJuOyB9XG5cbiAgICAgICAgICB2YXIgZSA9IGUgfHwgd2luZG93LmV2ZW50O1xuXG4gICAgICAgICAgdmFyIGRlbHRhID0gMDtcbiAgICAgICAgICBpZiAoZS53aGVlbERlbHRhKSB7IGRlbHRhID0gLWUud2hlZWxEZWx0YS8xMjA7IH1cbiAgICAgICAgICBpZiAoZS5kZXRhaWwpIHsgZGVsdGEgPSBlLmRldGFpbCAvIDM7IH1cblxuICAgICAgICAgIHZhciB0YXJnZXQgPSBlLnRhcmdldCB8fCBlLnNyY1RhcmdldCB8fCBlLnNyY0VsZW1lbnQ7XG4gICAgICAgICAgaWYgKCQodGFyZ2V0KS5jbG9zZXN0KCcuJyArIG8ud3JhcHBlckNsYXNzKS5pcyhtZS5wYXJlbnQoKSkpIHtcbiAgICAgICAgICAgIC8vIHNjcm9sbCBjb250ZW50XG4gICAgICAgICAgICBzY3JvbGxDb250ZW50KGRlbHRhLCB0cnVlKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBzdG9wIHdpbmRvdyBzY3JvbGxcbiAgICAgICAgICBpZiAoZS5wcmV2ZW50RGVmYXVsdCAmJiAhcmVsZWFzZVNjcm9sbCkgeyBlLnByZXZlbnREZWZhdWx0KCk7IH1cbiAgICAgICAgICBpZiAoIXJlbGVhc2VTY3JvbGwpIHsgZS5yZXR1cm5WYWx1ZSA9IGZhbHNlOyB9XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBzY3JvbGxDb250ZW50KHksIGlzV2hlZWwsIGlzSnVtcClcbiAgICAgICAge1xuICAgICAgICAgIHJlbGVhc2VTY3JvbGwgPSBmYWxzZTtcbiAgICAgICAgICB2YXIgZGVsdGEgPSB5O1xuICAgICAgICAgIHZhciBtYXhUb3AgPSBtZS5vdXRlckhlaWdodCgpIC0gYmFyLm91dGVySGVpZ2h0KCk7XG5cbiAgICAgICAgICBpZiAoaXNXaGVlbClcbiAgICAgICAgICB7XG4gICAgICAgICAgICAvLyBtb3ZlIGJhciB3aXRoIG1vdXNlIHdoZWVsXG4gICAgICAgICAgICBkZWx0YSA9IHBhcnNlSW50KGJhci5jc3MoJ3RvcCcpKSArIHkgKiBwYXJzZUludChvLndoZWVsU3RlcCkgLyAxMDAgKiBiYXIub3V0ZXJIZWlnaHQoKTtcblxuICAgICAgICAgICAgLy8gbW92ZSBiYXIsIG1ha2Ugc3VyZSBpdCBkb2Vzbid0IGdvIG91dFxuICAgICAgICAgICAgZGVsdGEgPSBNYXRoLm1pbihNYXRoLm1heChkZWx0YSwgMCksIG1heFRvcCk7XG5cbiAgICAgICAgICAgIC8vIGlmIHNjcm9sbGluZyBkb3duLCBtYWtlIHN1cmUgYSBmcmFjdGlvbmFsIGNoYW5nZSB0byB0aGVcbiAgICAgICAgICAgIC8vIHNjcm9sbCBwb3NpdGlvbiBpc24ndCByb3VuZGVkIGF3YXkgd2hlbiB0aGUgc2Nyb2xsYmFyJ3MgQ1NTIGlzIHNldFxuICAgICAgICAgICAgLy8gdGhpcyBmbG9vcmluZyBvZiBkZWx0YSB3b3VsZCBoYXBwZW5lZCBhdXRvbWF0aWNhbGx5IHdoZW5cbiAgICAgICAgICAgIC8vIGJhci5jc3MgaXMgc2V0IGJlbG93LCBidXQgd2UgZmxvb3IgaGVyZSBmb3IgY2xhcml0eVxuICAgICAgICAgICAgZGVsdGEgPSAoeSA+IDApID8gTWF0aC5jZWlsKGRlbHRhKSA6IE1hdGguZmxvb3IoZGVsdGEpO1xuXG4gICAgICAgICAgICAvLyBzY3JvbGwgdGhlIHNjcm9sbGJhclxuICAgICAgICAgICAgYmFyLmNzcyh7IHRvcDogZGVsdGEgKyAncHgnIH0pO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIC8vIGNhbGN1bGF0ZSBhY3R1YWwgc2Nyb2xsIGFtb3VudFxuICAgICAgICAgIHBlcmNlbnRTY3JvbGwgPSBwYXJzZUludChiYXIuY3NzKCd0b3AnKSkgLyAobWUub3V0ZXJIZWlnaHQoKSAtIGJhci5vdXRlckhlaWdodCgpKTtcbiAgICAgICAgICBkZWx0YSA9IHBlcmNlbnRTY3JvbGwgKiAobWVbMF0uc2Nyb2xsSGVpZ2h0IC0gbWUub3V0ZXJIZWlnaHQoKSk7XG5cbiAgICAgICAgICBpZiAoaXNKdW1wKVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGRlbHRhID0geTtcbiAgICAgICAgICAgIHZhciBvZmZzZXRUb3AgPSBkZWx0YSAvIG1lWzBdLnNjcm9sbEhlaWdodCAqIG1lLm91dGVySGVpZ2h0KCk7XG4gICAgICAgICAgICBvZmZzZXRUb3AgPSBNYXRoLm1pbihNYXRoLm1heChvZmZzZXRUb3AsIDApLCBtYXhUb3ApO1xuICAgICAgICAgICAgYmFyLmNzcyh7IHRvcDogb2Zmc2V0VG9wICsgJ3B4JyB9KTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICAvLyBzY3JvbGwgY29udGVudFxuICAgICAgICAgIG1lLnNjcm9sbFRvcChkZWx0YSk7XG5cbiAgICAgICAgICAvLyBmaXJlIHNjcm9sbGluZyBldmVudFxuICAgICAgICAgIG1lLnRyaWdnZXIoJ3NsaW1zY3JvbGxpbmcnLCB+fmRlbHRhKTtcblxuICAgICAgICAgIC8vIGVuc3VyZSBiYXIgaXMgdmlzaWJsZVxuICAgICAgICAgIHNob3dCYXIoKTtcblxuICAgICAgICAgIC8vIHRyaWdnZXIgaGlkZSB3aGVuIHNjcm9sbCBpcyBzdG9wcGVkXG4gICAgICAgICAgaGlkZUJhcigpO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gYXR0YWNoV2hlZWwodGFyZ2V0KVxuICAgICAgICB7XG4gICAgICAgICAgaWYgKHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHRhcmdldC5hZGRFdmVudExpc3RlbmVyKCdET01Nb3VzZVNjcm9sbCcsIF9vbldoZWVsLCBmYWxzZSApO1xuICAgICAgICAgICAgdGFyZ2V0LmFkZEV2ZW50TGlzdGVuZXIoJ21vdXNld2hlZWwnLCBfb25XaGVlbCwgZmFsc2UgKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIGRvY3VtZW50LmF0dGFjaEV2ZW50KFwib25tb3VzZXdoZWVsXCIsIF9vbldoZWVsKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGZ1bmN0aW9uIGdldEJhckhlaWdodCgpXG4gICAgICAgIHtcbiAgICAgICAgICAvLyBjYWxjdWxhdGUgc2Nyb2xsYmFyIGhlaWdodCBhbmQgbWFrZSBzdXJlIGl0IGlzIG5vdCB0b28gc21hbGxcbiAgICAgICAgICBiYXJIZWlnaHQgPSBNYXRoLm1heCgobWUub3V0ZXJIZWlnaHQoKSAvIG1lWzBdLnNjcm9sbEhlaWdodCkgKiBtZS5vdXRlckhlaWdodCgpLCBtaW5CYXJIZWlnaHQpO1xuICAgICAgICAgIGJhci5jc3MoeyBoZWlnaHQ6IGJhckhlaWdodCArICdweCcgfSk7XG5cbiAgICAgICAgICAvLyBoaWRlIHNjcm9sbGJhciBpZiBjb250ZW50IGlzIG5vdCBsb25nIGVub3VnaFxuICAgICAgICAgIHZhciBkaXNwbGF5ID0gYmFySGVpZ2h0ID09IG1lLm91dGVySGVpZ2h0KCkgPyAnbm9uZScgOiAnYmxvY2snO1xuICAgICAgICAgIGJhci5jc3MoeyBkaXNwbGF5OiBkaXNwbGF5IH0pO1xuICAgICAgICB9XG5cbiAgICAgICAgZnVuY3Rpb24gc2hvd0JhcigpXG4gICAgICAgIHtcbiAgICAgICAgICAvLyByZWNhbGN1bGF0ZSBiYXIgaGVpZ2h0XG4gICAgICAgICAgZ2V0QmFySGVpZ2h0KCk7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KHF1ZXVlSGlkZSk7XG5cbiAgICAgICAgICAvLyB3aGVuIGJhciByZWFjaGVkIHRvcCBvciBib3R0b21cbiAgICAgICAgICBpZiAocGVyY2VudFNjcm9sbCA9PSB+fnBlcmNlbnRTY3JvbGwpXG4gICAgICAgICAge1xuICAgICAgICAgICAgLy9yZWxlYXNlIHdoZWVsXG4gICAgICAgICAgICByZWxlYXNlU2Nyb2xsID0gby5hbGxvd1BhZ2VTY3JvbGw7XG5cbiAgICAgICAgICAgIC8vIHB1Ymxpc2ggYXBwcm9wb3JpYXRlIGV2ZW50XG4gICAgICAgICAgICBpZiAobGFzdFNjcm9sbCAhPSBwZXJjZW50U2Nyb2xsKVxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIHZhciBtc2cgPSAofn5wZXJjZW50U2Nyb2xsID09IDApID8gJ3RvcCcgOiAnYm90dG9tJztcbiAgICAgICAgICAgICAgICBtZS50cmlnZ2VyKCdzbGltc2Nyb2xsJywgbXNnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHJlbGVhc2VTY3JvbGwgPSBmYWxzZTtcbiAgICAgICAgICB9XG4gICAgICAgICAgbGFzdFNjcm9sbCA9IHBlcmNlbnRTY3JvbGw7XG5cbiAgICAgICAgICAvLyBzaG93IG9ubHkgd2hlbiByZXF1aXJlZFxuICAgICAgICAgIGlmKGJhckhlaWdodCA+PSBtZS5vdXRlckhlaWdodCgpKSB7XG4gICAgICAgICAgICAvL2FsbG93IHdpbmRvdyBzY3JvbGxcbiAgICAgICAgICAgIHJlbGVhc2VTY3JvbGwgPSB0cnVlO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgIH1cbiAgICAgICAgICBiYXIuc3RvcCh0cnVlLHRydWUpLmZhZGVJbignZmFzdCcpO1xuICAgICAgICAgIGlmIChvLnJhaWxWaXNpYmxlKSB7IHJhaWwuc3RvcCh0cnVlLHRydWUpLmZhZGVJbignZmFzdCcpOyB9XG4gICAgICAgIH1cblxuICAgICAgICBmdW5jdGlvbiBoaWRlQmFyKClcbiAgICAgICAge1xuICAgICAgICAgIC8vIG9ubHkgaGlkZSB3aGVuIG9wdGlvbnMgYWxsb3cgaXRcbiAgICAgICAgICBpZiAoIW8uYWx3YXlzVmlzaWJsZSlcbiAgICAgICAgICB7XG4gICAgICAgICAgICBxdWV1ZUhpZGUgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgIGlmICghKG8uZGlzYWJsZUZhZGVPdXQgJiYgaXNPdmVyUGFuZWwpICYmICFpc092ZXJCYXIgJiYgIWlzRHJhZ2cpXG4gICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBiYXIuZmFkZU91dCgnc2xvdycpO1xuICAgICAgICAgICAgICAgIHJhaWwuZmFkZU91dCgnc2xvdycpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCAxMDAwKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgfSk7XG5cbiAgICAgIC8vIG1haW50YWluIGNoYWluYWJpbGl0eVxuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICB9KTtcblxuICAkLmZuLmV4dGVuZCh7XG4gICAgc2xpbXNjcm9sbDogJC5mbi5zbGltU2Nyb2xsXG4gIH0pO1xuXG59KShqUXVlcnkpO1xuIiwidmFyIEJhY2tib25lID0gcmVxdWlyZShcImJhc2UvYmFja2JvbmVcIik7XG52YXIgZ2V0X3BhcmFtcyA9IHJlcXVpcmUoXCJ1dGlscy9nZXRfcGFyYW1zXCIpO1xudmFyIHNwcmludGYgPSByZXF1aXJlKFwic3ByaW50Zi1qc1wiKS5zcHJpbnRmO1xuXG4vLyBNb2RlbHNcbnZhciBUb3BpY05vZGUgPSBCYWNrYm9uZS5Nb2RlbC5leHRlbmQoe1xuXG4gICAgaW5pdGlhbGl6ZTogZnVuY3Rpb24ob3B0aW9ucykge1xuICAgICAgICBcbiAgICAgICAgaWYgKHRoaXMuZ2V0KFwiZW50aXR5X2tpbmRcIik9PT11bmRlZmluZWQgJiYgdGhpcy5nZXQoXCJraW5kXCIpIT09dW5kZWZpbmVkKXtcbiAgICAgICAgICAgIHRoaXMuc2V0KFwiZW50aXR5X2tpbmRcIiwgdGhpcy5nZXQoXCJraW5kXCIpKTtcbiAgICAgICAgfVxuICAgIH1cbn0pO1xuXG4vLyBDb2xsZWN0aW9uc1xudmFyIFRvcGljQ29sbGVjdGlvbiA9IEJhY2tib25lLkNvbGxlY3Rpb24uZXh0ZW5kKHtcbiAgICBtb2RlbDogVG9waWNOb2RlLFxuXG4gICAgaW5pdGlhbGl6ZTogZnVuY3Rpb24ob3B0aW9ucykge1xuXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcbiAgICAgICAgXG4gICAgICAgIHRoaXMucGFyZW50ID0gb3B0aW9ucy5wYXJlbnQ7XG5cbiAgICAgICAgdGhpcy5jaGFubmVsID0gb3B0aW9ucy5jaGFubmVsO1xuXG4gICAgICAgIHRoaXMubGlzdGVuVG9PbmNlKHRoaXMsIFwic3luY1wiLCBmdW5jdGlvbigpIHtzZWxmLmxvYWRlZCA9IHRydWU7fSk7XG4gICAgfSxcblxuICAgIHVybDogZnVuY3Rpb24oKSB7XG4gICAgICAgIHJldHVybiAoXCJBTExfVE9QSUNTX1VSTFwiIGluIHdpbmRvdyk/IGdldF9wYXJhbXMuc2V0R2V0UGFyYW0oc3ByaW50ZihBTExfVE9QSUNTX1VSTCwge2NoYW5uZWxfbmFtZTogdGhpcy5jaGFubmVsfSksIFwicGFyZW50XCIsIHRoaXMucGFyZW50KSA6IG51bGw7XG4gICAgfVxufSk7XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICAgIFRvcGljTm9kZTogVG9waWNOb2RlLFxuICAgIFRvcGljQ29sbGVjdGlvbjogVG9waWNDb2xsZWN0aW9uXG59OyIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCI7XG5cblxuICBidWZmZXIgKz0gXCI8ZGl2IGNsYXNzPVxcXCJzaWRlYmFyLXRhYlxcXCI+PC9kaXY+XFxuXFxuPG5hdiBjbGFzcz1cXFwic2lkZWJhci1wYW5lbFxcXCIgcm9sZT1cXFwibmF2aWdhdGlvblxcXCIgYXJpYS1sYWJlbD1cXFwiVG9waWMgc2lkZWJhciBtZW51XFxcIj5cXG4gICAgXFxuICAgIDxkaXYgY2xhc3M9XFxcInNpZGViYXItYmFja1xcXCI+XFxuICAgICAgICA8YnV0dG9uIGNsYXNzPVxcXCJzaW1wbGUtYnV0dG9uIGdyZWVuIGdseXBoaWNvbiBnbHlwaGljb24tYXJyb3ctbGVmdFxcXCI+PC9idXR0b24+XFxuICAgIDwvZGl2PlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJzaWRlYmFyLWNvbnRlbnRcXFwiPjwvZGl2PlxcbjwvbmF2PlxcblxcbjxkaXYgY2xhc3M9XFxcInNpZGViYXItZmFkZVxcXCI+PC9kaXY+XFxuXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnMsIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIGVzY2FwZUV4cHJlc3Npb249dGhpcy5lc2NhcGVFeHByZXNzaW9uLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgc2VsZj10aGlzO1xuXG5mdW5jdGlvbiBwcm9ncmFtMShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyO1xuICBidWZmZXIgKz0gXCJcXG48c3BhbiBjbGFzcz1cXFwic2lkZWJhci1lbnRyeSBzaWRlYmFyLWRpdmlkZXJcXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5lbnRpdHlfaWQpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAuZW50aXR5X2lkKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvc3Bhbj5cXG5cIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtMyhkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG48YSBjbGFzcz1cXFwic2lkZWJhci1lbnRyeSBzaWRlYmFyLWVudHJ5LWxpbmsgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmFjdGl2ZSksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSg0LCBwcm9ncmFtNCwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCIgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnMudW5sZXNzLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5hdmFpbGFibGUpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oNiwgcHJvZ3JhbTYsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxcIiBocmVmPVxcXCIjXFxcIiB0aXRsZT1cXFwiXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmRlc2NyaXB0aW9uKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIlxcXCI+XFxuICAgIDxkaXYgY2xhc3M9XFxcInNpZGViYXItZW50cnktaGVhZGVyXFxcIj5cXG5cXG4gICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzaWRlYmFyLWljb24gaWNvbi1cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMuZW50aXR5X2tpbmQpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAuZW50aXR5X2tpbmQpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiXFxcIiBkYXRhLWNvbnRlbnQtaWQ9XFxcIlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5pZCkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5pZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXFwiPjwvc3Bhbj5cXG4gICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzaWRlYmFyLXRpdGxlXFxcIiBkYXRhLWNvbnRlbnQtaWQ9XFxcIlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5pZCkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5pZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy50aXRsZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC50aXRsZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCI8L3NwYW4+XFxuICAgIDwvZGl2PlxcblxcbiAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVycy51bmxlc3MuY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLm9yZ2FuaXphdGlvbiksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5wcm9ncmFtKDEwLCBwcm9ncmFtMTAsIGRhdGEpLGZuOnNlbGYucHJvZ3JhbSg4LCBwcm9ncmFtOCwgZGF0YSksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgPHNwYW4gY2xhc3M9XFxcInNpZGViYXItZGVzY3JpcHRpb24gc2lkZWJhci10b3BpYy1kZXNjcmlwdGlvblxcXCIgZGF0YS1jb250ZW50LWlkPVxcXCJcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMuaWQpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAuaWQpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiXFxcIj5cIjtcbiAgc3RhY2sxID0gKGhlbHBlciA9IGhlbHBlcnMudHJ1bmNhdGUgfHwgKGRlcHRoMCAmJiBkZXB0aDAudHJ1bmNhdGUpLG9wdGlvbnM9e2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDEyLCBwcm9ncmFtMTIsIGRhdGEpLGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5kZXNjcmlwdGlvbiksIDEwMCwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcInRydW5jYXRlXCIsIChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKSwgMTAwLCBvcHRpb25zKSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCI8L3NwYW4+XFxuPC9hPlxcblwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5mdW5jdGlvbiBwcm9ncmFtNChkZXB0aDAsZGF0YSkge1xuICBcbiAgXG4gIHJldHVybiBcImFjdGl2ZS1lbnRyeVwiO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW02KGRlcHRoMCxkYXRhKSB7XG4gIFxuICBcbiAgcmV0dXJuIFwibWlzc2luZ1wiO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW04KGRlcHRoMCxkYXRhKSB7XG4gIFxuICBcbiAgcmV0dXJuIFwiXFxuICAgICAgICA8c3BhbiBjbGFzcz1cXFwic2lkZWJhci1zcGFjZS1ob2xkZXJcXFwiPiAgPC9zcGFuPlxcbiAgICBcIjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtMTAoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICA8c3BhbiBjbGFzcz1cXFwic2lkZWJhci1vcmdhbml6YXRpb25cXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJieTpcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJieTpcIiwgb3B0aW9ucykpKVxuICAgICsgXCIgXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLm9yZ2FuaXphdGlvbikgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5vcmdhbml6YXRpb24pOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiPC9zcGFuPlxcbiAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtMTIoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbiAgc3RhY2sxID0gKGhlbHBlciA9IGhlbHBlcnMuaWZjb25kIHx8IChkZXB0aDAgJiYgZGVwdGgwLmlmY29uZCksb3B0aW9ucz17aGFzaDp7fSxpbnZlcnNlOnNlbGYucHJvZ3JhbSgzLCBwcm9ncmFtMywgZGF0YSksZm46c2VsZi5wcm9ncmFtKDEsIHByb2dyYW0xLCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZW50aXR5X2tpbmQpLCBcIj09XCIsIFwiRGl2aWRlclwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsIChkZXB0aDAgJiYgZGVwdGgwLmVudGl0eV9raW5kKSwgXCI9PVwiLCBcIkRpdmlkZXJcIiwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IHJldHVybiBzdGFjazE7IH1cbiAgZWxzZSB7IHJldHVybiAnJzsgfVxuICB9KTtcbiIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgXG5cblxuICByZXR1cm4gXCI8dWwgY2xhc3M9XFxcInNpZGViYXJcXFwiPlxcblxcbjwvdWw+XCI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIjtcblxuXG4gIGJ1ZmZlciArPSBcIlxcbjxkaXYgY2xhc3M9XFxcImNvbnRlbnRcXFwiPjwvZGl2PlxcbjxkaXYgaWQ9XFxcInJhdGluZy1jb250YWluZXItd3JhcHBlclxcXCIgY2xhc3M9XFxcImNvbnRhaW5lclxcXCI+PC9kaXY+XCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwidmFyIEJhY2tib25lID0gcmVxdWlyZShcIi4uL2Jhc2UvYmFja2JvbmVcIik7XHJcbnZhciAkID0gcmVxdWlyZShcIi4uL2Jhc2UvalF1ZXJ5XCIpO1xyXG52YXIgXyA9IHJlcXVpcmUoXCJ1bmRlcnNjb3JlXCIpO1xyXG52YXIgQmFzZVZpZXcgPSByZXF1aXJlKFwiLi4vYmFzZS9iYXNldmlld1wiKTtcclxudmFyIEhhbmRsZWJhcnMgPSByZXF1aXJlKFwiLi4vYmFzZS9oYW5kbGViYXJzXCIpO1xyXG5cclxuLypcclxuICAgIENvbnRhaW5lciB2aWV3IGZvciBmZWVkYmFjayBmb3JtLlxyXG4gICAgU2VlIHRoZSBkZXNpZ24gZG9jdW1lbnQgaGVyZTogaHR0cHM6Ly9kb2NzLmdvb2dsZS5jb20vYS9sZWFybmluZ2VxdWFsaXR5Lm9yZy9kb2N1bWVudC9kLzFXXzJ2djFjWlU1d1pwX01ManZQeTZqSHdrUlZQV19pVEpoSEVwU09ZckNzL2VkaXQ/dXNwPWRyaXZlX3dlYlxyXG4qL1xyXG5tb2R1bGUuZXhwb3J0cyA9IEJhc2VWaWV3LmV4dGVuZCh7XHJcblxyXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoXCIuL2hidGVtcGxhdGVzL3JhdGluZy5oYW5kbGViYXJzXCIpLFxyXG5cclxuICAgIGV2ZW50czoge1xyXG4gICAgICAgIFwiY2xpY2sgLnJhdGluZy1kZWxldGVcIjogXCJkZWxldGVfY2FsbGJhY2tcIlxyXG4gICAgfSxcclxuXHJcbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbihvcHRpb25zKSB7XHJcbiAgICAgICAgLypcclxuICAgICAgICAgICAgUHJlcGFyZSBzZWxmIGFuZCBzdWJ2aWV3cy5cclxuICAgICAgICAqL1xyXG4gICAgICAgIHRoaXMubW9kZWwgPSBvcHRpb25zLm1vZGVsIHx8IG51bGw7XHJcbiAgICAgICAgXy5iaW5kQWxsKHRoaXMsIFwiZGVsZXRlX2NhbGxiYWNrXCIsIFwicmVuZGVyQWxsXCIsIFwicmVuZGVyU2VxdWVuY2VcIiwgXCJyZW5kZXJcIik7XHJcbiAgICAgICAgdGhpcy5xdWFsaXR5X2xhYmVsX3ZhbHVlcyA9IHtcclxuICAgICAgICAgICAgMTogIGdldHRleHQoXCJQb29yIHF1YWxpdHlcIiksXHJcbiAgICAgICAgICAgIDI6ICBnZXR0ZXh0KFwiU29tZXdoYXQgcG9vclwiKSxcclxuICAgICAgICAgICAgMzogIGdldHRleHQoXCJBdmVyYWdlXCIpLFxyXG4gICAgICAgICAgICA0OiAgZ2V0dGV4dChcIlNvbWV3aGF0IGhpZ2hcIiksXHJcbiAgICAgICAgICAgIDU6ICBnZXR0ZXh0KFwiSGlnaCBxdWFsaXR5XCIpXHJcbiAgICAgICAgfTtcclxuICAgICAgICB0aGlzLmRpZmZpY3VsdHlfbGFiZWxfdmFsdWVzID0ge1xyXG4gICAgICAgICAgICAxOiAgZ2V0dGV4dChcIlZlcnkgZWFzeVwiKSxcclxuICAgICAgICAgICAgMjogIGdldHRleHQoXCJFYXN5XCIpLFxyXG4gICAgICAgICAgICAzOiAgZ2V0dGV4dChcIkF2ZXJhZ2VcIiksXHJcbiAgICAgICAgICAgIDQ6ICBnZXR0ZXh0KFwiSGFyZFwiKSxcclxuICAgICAgICAgICAgNTogIGdldHRleHQoXCJWZXJ5IGhhcmRcIilcclxuICAgICAgICB9O1xyXG4gICAgfSxcclxuXHJcbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIC8qXHJcbiAgICAgICAgICAgIElmIHRoZSBtb2RlbCBpcyBuZXcgKG5ldmVyIGJlZW4gc3luY2VkKSBvciBlbXB0eSAoc3VjaCBhcyBpZiBpdCB3YXMgZGVsZXRlZCkgcmVuZGVyIGVhY2ggY29tcG9uZW50IGluXHJcbiAgICAgICAgICAgIHNlcXVlbmNlLiBPdGhlcndpc2UsIHJlbmRlciBhbGwgY29tcG9uZW50cyB0b2dldGhlciwgZm9yIHJldmlldy5cclxuICAgICAgICAqL1xyXG4gICAgICAgIGlmKCB0aGlzLm1vZGVsLmlzTmV3KCkgfHwgdGhpcy5tb2RlbC5nZXQoXCJxdWFsaXR5XCIpID09PSAwIHx8IHRoaXMubW9kZWwuZ2V0KFwiZGlmZmljdWx0eVwiKSA9PT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLnJlbmRlclNlcXVlbmNlKCk7XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgdGhpcy5yZW5kZXJBbGwoKTtcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIHJlbmRlclNlcXVlbmNlOiBmdW5jdGlvbigpIHtcclxuICAgICAgICAvKlxyXG4gICAgICAgICAgICBQcmVzZW50IGVhY2ggcmF0aW5nIHdpZGdldCBvbmUgYnkgb25lLCB3YWl0aW5nIGZvciB1c2VyIGludGVyYWN0aW9uIGJlZm9yZSBncm93aW5nIHRvIHNob3cgdGhlIG5leHQuXHJcbiAgICAgICAgICAgIFRoZW4gb25jZSB0aGUgdXNlciBoYXMgZmlsbGVkIG91dCB0aGUgcmF0aW5nIGNvbXBsZXRlbHksIGNhbGwgcmVuZGVyQWxsIHRvIGFsbG93IHJldmlldy9lZGl0aW5nLlxyXG4gICAgICAgICovXHJcbiAgICAgICAgdGhpcy4kZWwuaHRtbCh0aGlzLnRlbXBsYXRlKCkpO1xyXG4gICAgICAgIHRoaXMuJChcIi5yYXRpbmctZGVsZXRlXCIpLmhpZGUoKTtcclxuXHJcbiAgICAgICAgdGhpcy5zdGFyX3ZpZXdfcXVhbGl0eSA9IHRoaXMuYWRkX3N1YnZpZXcoU3RhclZpZXcsIHt0aXRsZTogZ2V0dGV4dChcIlF1YWxpdHlcIiksIGVsOiB0aGlzLiQoXCIjc3Rhci1jb250YWluZXItcXVhbGl0eVwiKSwgbW9kZWw6IHRoaXMubW9kZWwsIHJhdGluZ19hdHRyOiBcInF1YWxpdHlcIiwgbGFiZWxfdmFsdWVzOiB0aGlzLnF1YWxpdHlfbGFiZWxfdmFsdWVzfSk7XHJcblxyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICB2YXIgY2FsbGJhY2sgPSBmdW5jdGlvbigpIHtcclxuICAgICAgICAgICAgc2VsZi5zdGFyX3ZpZXdfZGlmZmljdWx0eSA9IHNlbGYuYWRkX3N1YnZpZXcoU3RhclZpZXcsIHt0aXRsZTogZ2V0dGV4dChcIkRpZmZpY3VsdHlcIiksIGVsOiBzZWxmLiQoXCIjc3Rhci1jb250YWluZXItZGlmZmljdWx0eVwiKSwgbW9kZWw6IHNlbGYubW9kZWwsIHJhdGluZ19hdHRyOiBcImRpZmZpY3VsdHlcIiwgbGFiZWxfdmFsdWVzOiB0aGlzLmRpZmZpY3VsdHlfbGFiZWxfdmFsdWVzfSk7XHJcbiAgICAgICAgICAgIHNlbGYuJChcIi5yYXRpbmctZGVsZXRlXCIpLnNob3coKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIC8vIElmIHRoZSBcInF1YWxpdHlcIiBpcyBhbHJlYWR5IHNldCwgZGlzcGxheSBcImRpZmZpY3VsdHlcIiBpbW1lZGlhdGVseS4gT3RoZXJ3aXNlIHdhaXQuXHJcbiAgICAgICAgaWYgKCF0aGlzLm1vZGVsLmdldChcInF1YWxpdHlcIikgfHwgcGFyc2VJbnQodGhpcy5tb2RlbC5nZXQoXCJxdWFsaXR5XCIpKSA9PT0gMCkge1xyXG4gICAgICAgICAgICB0aGlzLmxpc3RlblRvT25jZSh0aGlzLm1vZGVsLCBcImNoYW5nZTpxdWFsaXR5XCIsIGNhbGxiYWNrKTtcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICBjYWxsYmFjaygpO1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhpcy5saXN0ZW5Ub09uY2UodGhpcy5tb2RlbCwgXCJjaGFuZ2U6ZGlmZmljdWx0eVwiLCB0aGlzLnJlbmRlckFsbCk7XHJcblxyXG4gICAgfSxcclxuXHJcbiAgICByZW5kZXJBbGw6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIC8qXHJcbiAgICAgICAgICAgIFJlbmRlcnMgaXRzZWxmLCB0aGVuIGF0dGFjaGVzIGFsbCBzdWJ2aWV3cy5cclxuICAgICAgICAgICAgQ2FsbGVkIHdoZW46IDEpIFRoZSB2aWV3J3MgbW9kZWwgaXMgZmV0Y2hlZCBzdWNjZXNzZnVsbHkgb3JcclxuICAgICAgICAgICAgICAgICAgICAgICAgIDIpIFRoZSB2aWV3J3MgbW9kZWwgaXMgbm90IGZldGNoZWQsIGFuZCB0aGUgdXNlciBmaW5pc2hlcyBmaWxsaW5nIG91dCB0aGUgbmV3IGZvcm0uXHJcbiAgICAgICAgKi9cclxuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUoKSk7XHJcbiAgICAgICAgdmFyIHZpZXdzX2FuZF9vcHRzID0gW1xyXG4gICAgICAgICAgICBbXCJzdGFyX3ZpZXdfcXVhbGl0eVwiLCBTdGFyVmlldywge3RpdGxlOiBnZXR0ZXh0KFwiUXVhbGl0eVwiKSwgZWw6IHRoaXMuJChcIiNzdGFyLWNvbnRhaW5lci1xdWFsaXR5XCIpLCBtb2RlbDogdGhpcy5tb2RlbCwgcmF0aW5nX2F0dHI6IFwicXVhbGl0eVwiLCBsYWJlbF92YWx1ZXM6IHRoaXMucXVhbGl0eV9sYWJlbF92YWx1ZXN9XSxcclxuICAgICAgICAgICAgW1wic3Rhcl92aWV3X2RpZmZpY3VsdHlcIiwgU3RhclZpZXcsIHt0aXRsZTogZ2V0dGV4dChcIkRpZmZpY3VsdHlcIiksIGVsOiB0aGlzLiQoXCIjc3Rhci1jb250YWluZXItZGlmZmljdWx0eVwiKSwgbW9kZWw6IHRoaXMubW9kZWwsIHJhdGluZ19hdHRyOiBcImRpZmZpY3VsdHlcIiwgbGFiZWxfdmFsdWVzOiB0aGlzLmRpZmZpY3VsdHlfbGFiZWxfdmFsdWVzfV0sXHJcbiAgICAgICAgICAgIFtcInRleHRfdmlld1wiLCBUZXh0Vmlldywge2VsOiB0aGlzLiQoXCIjdGV4dC1jb250YWluZXJcIiksIG1vZGVsOiB0aGlzLm1vZGVsfV1cclxuICAgICAgICBdO1xyXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcclxuICAgICAgICBfLmVhY2godmlld3NfYW5kX29wdHMsIGZ1bmN0aW9uKGVsLCBpbmQsIGxpc3Qpe1xyXG4gICAgICAgICAgICBzZWxmW2VsWzBdXSA9IHNlbGYuYWRkX3N1YnZpZXcoZWxbMV0sIGVsWzJdKTtcclxuICAgICAgICB9KTtcclxuICAgIH0sXHJcblxyXG4gICAgZGVsZXRlX2NhbGxiYWNrOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB2YXIgc2VsZiA9IHRoaXM7XHJcbiAgICAgICAgdGhpcy4kZWwuaHRtbChcIkRlbGV0aW5nIHlvdXIgcmV2aWV3Li4uXCIpO1xyXG4gICAgICAgIC8vIERvbid0IHNpbXBseSBjbGVhciAmIGRlc3Ryb3kgdGhlIG1vZGVsLCB3ZSB3aXNoIHRvIHJlbWVtYmVyIHNvbWUgYXR0cmlidXRlcyAobGlrZSBjb250ZW50X2tpbmQgYW5kIHVzZXJfdXJpKVxyXG4gICAgICAgIHRoaXMubW9kZWwuc2F2ZSh7XHJcbiAgICAgICAgICAgIHF1YWxpdHk6IDAsXHJcbiAgICAgICAgICAgIGRpZmZpY3VsdHk6IDAsXHJcbiAgICAgICAgICAgIHRleHQ6IFwiXCJcclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICAgZXJyb3I6IGZ1bmN0aW9uKCl7XHJcbiAgICAgICAgICAgICAgICBjb25zb2xlLmxvZyhcImZhaWxlZCB0byBjbGVhciByYXRpbmcgbW9kZWwgYXR0cmlidXRlcy4uLlwiKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgc3VjY2VzczogZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgIHNlbGYucmVuZGVyU2VxdWVuY2UoKTtcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgcGF0Y2g6IHRydWVcclxuICAgICAgICB9KTtcclxuICAgIH1cclxufSk7XHJcblxyXG5cclxuLypcclxuICAgIFdpZGdldCB0byByYXRlIHNvbWV0aGluZyBmcm9tIDEgdG8gNSBzdGFycy5cclxuKi9cclxudmFyIFN0YXJWaWV3ID0gQmFzZVZpZXcuZXh0ZW5kKHtcclxuXHJcbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvc3Rhci5oYW5kbGViYXJzXCIpLFxyXG5cclxuICAgIGV2ZW50czoge1xyXG4gICAgICAgIFwiY2xpY2sgLnN0YXItcmF0aW5nLW9wdGlvblwiOiBcInJhdGVfdmFsdWVfY2FsbGJhY2tcIixcclxuICAgICAgICBcImNsaWNrIC5zdGFyLXJhdGluZy1vcHRpb24gPlwiOiBcInJhdGVfdmFsdWVfY2FsbGJhY2tcIixcclxuICAgICAgICBcIm1vdXNlZW50ZXIgLnN0YXItcmF0aW5nLW9wdGlvbiA+XCI6IFwibW91c2VfZW50ZXJfY2FsbGJhY2tcIixcclxuICAgICAgICBcIm1vdXNlZW50ZXIgLnN0YXItcmF0aW5nLW9wdGlvblwiOiBcIm1vdXNlX2VudGVyX2NhbGxiYWNrXCIsXHJcbiAgICAgICAgXCJtb3VzZWxlYXZlIC5zdGFyLXJhdGluZy1vcHRpb25cIjogXCJtb3VzZV9sZWF2ZV9jYWxsYmFja1wiXHJcbiAgICB9LFxyXG5cclxuICAgIGxhYmVsX3ZhbHVlczoge1xyXG4gICAgICAgIDE6IGdldHRleHQoXCJWZXJ5IExvd1wiKSxcclxuICAgICAgICAyOiBnZXR0ZXh0KFwiTG93XCIpLFxyXG4gICAgICAgIDM6IGdldHRleHQoXCJOb3JtYWxcIiksXHJcbiAgICAgICAgNDogZ2V0dGV4dChcIkhpZ2hcIiksXHJcbiAgICAgICAgNTogZ2V0dGV4dChcIlZlcnkgSGlnaFwiKVxyXG4gICAgfSxcclxuXHJcbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbihvcHRpb25zKSB7XHJcbiAgICAgICAgdGhpcy5tb2RlbCA9IG9wdGlvbnMubW9kZWwgfHwgbmV3IEJhY2tib25lLk1vZGVsKCk7XHJcbiAgICAgICAgdGhpcy50aXRsZSA9IG9wdGlvbnMudGl0bGUgfHwgXCJcIjtcclxuICAgICAgICB0aGlzLmxhYmVsX3ZhbHVlcyA9IG9wdGlvbnMubGFiZWxfdmFsdWVzIHx8IHRoaXMubGFiZWxfdmFsdWVzO1xyXG4gICAgICAgIHRoaXMucmF0aW5nX2F0dHIgPSBvcHRpb25zLnJhdGluZ19hdHRyIHx8IFwicmF0aW5nXCI7XHJcbiAgICAgICAgXy5iaW5kQWxsKHRoaXMsIFwicmF0ZV92YWx1ZV9jYWxsYmFja1wiLCBcInJhdGluZ19jaGFuZ2VcIik7XHJcblxyXG4gICAgICAgIHRoaXMubW9kZWwub24oXCJjaGFuZ2U6XCIrdGhpcy5yYXRpbmdfYXR0ciwgdGhpcy5yYXRpbmdfY2hhbmdlKTtcclxuXHJcbiAgICAgICAgdGhpcy5yZW5kZXIoKTtcclxuICAgIH0sXHJcblxyXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB2YXIgdGVtcGxhdGVfb3B0aW9ucyA9IHt9O1xyXG4gICAgICAgIF8uZXh0ZW5kKHRlbXBsYXRlX29wdGlvbnMsIHRoaXMubW9kZWwuYXR0cmlidXRlcywge3RpdGxlOiB0aGlzLnRpdGxlLCBsb3dlc3RfdmFsdWU6IHRoaXMubGFiZWxfdmFsdWVzWzFdLCBoaWdoZXN0X3ZhbHVlOiB0aGlzLmxhYmVsX3ZhbHVlc1s1XX0pO1xyXG4gICAgICAgIHRoaXMuJGVsLmh0bWwodGhpcy50ZW1wbGF0ZSh0ZW1wbGF0ZV9vcHRpb25zKSk7XHJcbiAgICAgICAgdGhpcy5yYXRpbmdfY2hhbmdlKCk7XHJcbiAgICB9LFxyXG5cclxuICAgIC8vIERlYm91bmNlZCB3aXRoIGltbWVkaWF0ZT10cnVlIG9wdGlvbiwgc28gdGhhdCBpdCdzIHRyaWdnZXJlZCBfYXQgbW9zdF8gb25jZSBwZXIgMTAwIG1zLCBzaW5jZSBpdFxyXG4gICAgLy8gICBjb3VsZCBiZSBjYWxsZWQgYnkgY2xpY2tpbmcgb24gYSBjaGlsZCBlbGVtZW50IGFzIHdlbGwuXHJcbiAgICByYXRlX3ZhbHVlX2NhbGxiYWNrOiBfLmRlYm91bmNlKGZ1bmN0aW9uKGV2KSB7XHJcbiAgICAgICAgLy8gVGhlIHRhcmdldCBldmVudCBjb3VsZCBiZSBlaXRoZXIgdGhlIC5zdGFyLXJhdGluZy1vcHRpb24gb3IgYSBjaGlsZCBlbGVtZW50LCBzbyB3aGF0ZXZlciB0aGUgY2FzZSBnZXQgdGhlXHJcbiAgICAgICAgLy8gcGFyZW50IC5zdGFyLXJhdGluZy1vcHRpb24gZWxlbWVudC5cclxuICAgICAgICB2YXIgdGFyZ2V0ID0gJChldi50YXJnZXQpLmhhc0NsYXNzKFwic3Rhci1yYXRpbmctb3B0aW9uXCIpID8gJChldi50YXJnZXQpIDogJChldi50YXJnZXQpLnBhcmVudHMoXCIuc3Rhci1yYXRpbmctb3B0aW9uXCIpWzBdO1xyXG4gICAgICAgIHZhciB2YWwgPSAkKHRhcmdldCkuYXR0cihcImRhdGEtdmFsXCIpO1xyXG4gICAgICAgIHRoaXMubW9kZWwuc2V0KHRoaXMucmF0aW5nX2F0dHIsIHZhbCk7XHJcbiAgICAgICAgdGhpcy5tb2RlbC5kZWJvdW5jZWRfc2F2ZSgpO1xyXG4gICAgfSwgMTAwLCB0cnVlKSxcclxuXHJcbiAgICBtb3VzZV9lbnRlcl9jYWxsYmFjazogZnVuY3Rpb24oZXYpIHtcclxuICAgICAgICAvLyBUaGUgdGFyZ2V0IGV2ZW50IGNvdWxkIGJlIGVpdGhlciB0aGUgLnN0YXItcmF0aW5nLW9wdGlvbiBvciBhIGNoaWxkIGVsZW1lbnQsIHNvIHdoYXRldmVyIHRoZSBjYXNlIGdldCB0aGVcclxuICAgICAgICAvLyBwYXJlbnQgLnN0YXItcmF0aW5nLW9wdGlvbiBlbGVtZW50LlxyXG4gICAgICAgIHZhciB0YXJnZXQgPSAkKGV2LnRhcmdldCkuaGFzQ2xhc3MoXCJzdGFyLXJhdGluZy1vcHRpb25cIikgPyAkKGV2LnRhcmdldCkgOiAkKGV2LnRhcmdldCkucGFyZW50cyhcIi5zdGFyLXJhdGluZy1vcHRpb25cIilbMF07XHJcbiAgICAgICAgdmFyIHZhbCA9ICQodGFyZ2V0KS5hdHRyKFwiZGF0YS12YWxcIik7XHJcbiAgICAgICAgdGhpcy4kKFwiLnJhdGluZy1sYWJlbFwiKS50ZXh0KHRoaXMubGFiZWxfdmFsdWVzW3ZhbF0pO1xyXG4gICAgfSxcclxuXHJcbiAgICBtb3VzZV9sZWF2ZV9jYWxsYmFjazogZnVuY3Rpb24oZXYpIHtcclxuICAgICAgICB0aGlzLiQoXCIucmF0aW5nLWxhYmVsXCIpLnRleHQoXCJcIik7XHJcbiAgICB9LFxyXG5cclxuICAgIHJhdGluZ19jaGFuZ2U6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIG9wdHMgPSB0aGlzLiQoXCIuc3Rhci1yYXRpbmctb3B0aW9uXCIpO1xyXG4gICAgICAgIF8uZWFjaChvcHRzLCBmdW5jdGlvbihvcHQsIGluZGV4LCBsaXN0KSB7XHJcbiAgICAgICAgICAgICRvcHQgPSAkKG9wdCk7XHJcbiAgICAgICAgICAgICRvcHQudG9nZ2xlQ2xhc3MoXCJhY3RpdmF0ZWRcIiwgcGFyc2VJbnQoJG9wdC5hdHRyKFwiZGF0YS12YWxcIikpIDw9IHBhcnNlSW50KHRoaXMubW9kZWwuZ2V0KHRoaXMucmF0aW5nX2F0dHIpKSk7XHJcbiAgICAgICAgfSwgdGhpcyk7XHJcbiAgICB9XHJcbn0pO1xyXG5cclxuXHJcbi8qXHJcbiAgICBXaWRnZXQgdG8gYWNjZXB0L2Rpc3BsYXkgZnJlZS1mb3JtIHRleHQgaW5wdXQuXHJcbiovXHJcbnZhciBUZXh0VmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XHJcblxyXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoXCIuL2hidGVtcGxhdGVzL3RleHQuaGFuZGxlYmFyc1wiKSxcclxuXHJcbiAgICBldmVudHM6IHtcclxuICAgICAgICBcImtleXVwIC5yYXRpbmctdGV4dC1mZWVkYmFja1wiOiBcInRleHRfY2hhbmdlZFwiXHJcbiAgICB9LFxyXG5cclxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKG9wdGlvbnMpIHtcclxuICAgICAgICB0aGlzLm1vZGVsID0gb3B0aW9ucy5tb2RlbCB8fCBuZXcgQmFja2JvbmUuTW9kZWwoKTtcclxuICAgICAgICBfLmJpbmRBbGwodGhpcywgXCJ0ZXh0X2NoYW5nZWRcIik7XHJcbiAgICAgICAgdGhpcy5tb2RlbC5vbihcImNoYW5nZTp0ZXh0XCIsIHRoaXMudGV4dF9jaGFuZ2VkKTtcclxuICAgICAgICB0aGlzLnJlbmRlcigpO1xyXG4gICAgfSxcclxuXHJcbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xyXG4gICAgICAgIHRoaXMuJGVsLmh0bWwodGhpcy50ZW1wbGF0ZSh0aGlzLm1vZGVsLmF0dHJpYnV0ZXMpKTtcclxuICAgICAgICByZXR1cm4gdGhpcztcclxuICAgIH0sXHJcblxyXG4gICAgdGV4dF9jaGFuZ2VkOiBmdW5jdGlvbigpIHtcclxuICAgICAgICB0aGlzLm1vZGVsLnNldChcInRleHRcIiwgdGhpcy4kKFwiLnJhdGluZy10ZXh0LWZlZWRiYWNrXCIpWzBdLnZhbHVlKTtcclxuICAgICAgICB0aGlzLm1vZGVsLmRlYm91bmNlZF9zYXZlKCk7XHJcbiAgICB9XHJcbn0pO1xyXG4iLCJ2YXIgQmFja2JvbmUgPSByZXF1aXJlKFwiLi4vYmFzZS9iYWNrYm9uZVwiKTtcclxuXHJcbnZhciBSYXRpbmdNb2RlbCA9IEJhY2tib25lLk1vZGVsLmV4dGVuZCh7XHJcbiAgICB1cmxSb290OiBcIi9hcGkvY29udGVudF9yYXRpbmdcIixcclxuXHJcbiAgICBpbml0aWFsaXplOiBmdW5jdGlvbigpe1xyXG4gICAgICAgIF8uYmluZEFsbCh0aGlzLCBcImRlYm91bmNlZF9zYXZlXCIpO1xyXG4gICAgfSxcclxuXHJcbiAgICBkZWJvdW5jZWRfc2F2ZTogXy5kZWJvdW5jZShmdW5jdGlvbigpe1xyXG4gICAgICAgIHRoaXMuc2F2ZSgpO1xyXG4gICAgfSwgMjAwMClcclxufSk7XHJcblxyXG52YXIgQ29udGVudFJhdGluZ0NvbGxlY3Rpb24gPSBCYWNrYm9uZS5Db2xsZWN0aW9uLmV4dGVuZCh7XHJcbiAgICBtb2RlbDogUmF0aW5nTW9kZWxcclxufSk7XHJcblxyXG5tb2R1bGUuZXhwb3J0cyA9IHtcclxuICAgIFwiUmF0aW5nTW9kZWxcIjogUmF0aW5nTW9kZWwsXHJcbiAgICBcIkNvbnRlbnRSYXRpbmdDb2xsZWN0aW9uXCI6IENvbnRlbnRSYXRpbmdDb2xsZWN0aW9uXHJcbn07XHJcbiIsIi8vIGhic2Z5IGNvbXBpbGVkIEhhbmRsZWJhcnMgdGVtcGxhdGVcbnZhciBIYW5kbGViYXJzQ29tcGlsZXIgPSByZXF1aXJlKCdoYnNmeS9ydW50aW1lJyk7XG5tb2R1bGUuZXhwb3J0cyA9IEhhbmRsZWJhcnNDb21waWxlci50ZW1wbGF0ZShmdW5jdGlvbiAoSGFuZGxlYmFycyxkZXB0aDAsaGVscGVycyxwYXJ0aWFscyxkYXRhKSB7XG4gIHRoaXMuY29tcGlsZXJJbmZvID0gWzQsJz49IDEuMC4wJ107XG5oZWxwZXJzID0gdGhpcy5tZXJnZShoZWxwZXJzLCBIYW5kbGViYXJzLmhlbHBlcnMpOyBkYXRhID0gZGF0YSB8fCB7fTtcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb24sIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCI7XG5cblxuICBidWZmZXIgKz0gXCI8ZGl2IGNsYXNzPVxcXCJjb250YWluZXJcXFwiPlxcclxcbiAgICA8ZGl2IGNsYXNzPVxcXCJyb3dcXFwiPlxcclxcbiAgICAgICAgPGxhYmVsIGNsYXNzPVxcXCJ0ZXh0LWZlZWRiYWNrLWxhYmVsIGNvbC1tZC0yIGNvbC1tZC1vZmZzZXQtMiBjb2wteHMtMTJcXFwiPjxoMz5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiWW91ciBjb21tZW50czpcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJZb3VyIGNvbW1lbnRzOlwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvaDM+PC9sYWJlbD5cXHJcXG4gICAgPC9kaXY+XFxyXFxuICAgIDxkaXYgY2xhc3M9XFxcInJvd1xcXCI+XFxyXFxuICAgICAgICA8dGV4dGFyZWEgY2xhc3M9XFxcImZvcm0tY29udHJvbCByYXRpbmctdGV4dC1mZWVkYmFjayBjb2wteHMtOCBjb2wteHMtb2Zmc2V0LTJcXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy50ZXh0KSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnRleHQpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiPC90ZXh0YXJlYT5cXHJcXG4gICAgPC9kaXY+XFxyXFxuPC9kaXY+XCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIGVzY2FwZUV4cHJlc3Npb249dGhpcy5lc2NhcGVFeHByZXNzaW9uO1xuXG5cbiAgYnVmZmVyICs9IFwiPGNlbnRlciBjbGFzcz1cXFwic3Rhci1yYXRpbmctaW5uZXItd3JhcHBlclxcXCI+XFxyXFxuICAgIDxoMj48c3BhbiBjbGFzcz1cXFwic3Rhci10aXRsZS1sYWJlbCBsYWJlbCBsYWJlbC1kZWZhdWx0XFxcIj5cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMudGl0bGUpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAudGl0bGUpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiPC9zcGFuPjwvaDI+XFxyXFxuXFxyXFxuICAgIDxkaXYgY2xhc3M9XFxcInJvdyByYXRpbmctcm93XFxcIj5cXHJcXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC1tZC0xIGNvbC1tZC1vZmZzZXQtMyBsb3dlc3QtbGFiZWxcXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5sb3dlc3RfdmFsdWUpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAubG93ZXN0X3ZhbHVlKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvZGl2PlxcclxcblxcclxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLW1kLTRcXFwiPlxcclxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInN0YXItcmF0aW5nLW9wdGlvbiBidG4gYnRuLXN0YXJcXFwiIGRhdGEtdmFsPVxcXCIxXFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tc3Rhci1lbXB0eVxcXCI+PC9zcGFuPlxcclxcbiAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInN0YXItcmF0aW5nLW9wdGlvbiBidG4gYnRuLXN0YXJcXFwiIGRhdGEtdmFsPVxcXCIyXFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tc3Rhci1lbXB0eVxcXCI+PC9zcGFuPlxcclxcbiAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInN0YXItcmF0aW5nLW9wdGlvbiBidG4gYnRuLXN0YXJcXFwiIGRhdGEtdmFsPVxcXCIzXFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tc3Rhci1lbXB0eVxcXCI+PC9zcGFuPlxcclxcbiAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInN0YXItcmF0aW5nLW9wdGlvbiBidG4gYnRuLXN0YXJcXFwiIGRhdGEtdmFsPVxcXCI0XFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tc3Rhci1lbXB0eVxcXCI+PC9zcGFuPlxcclxcbiAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInN0YXItcmF0aW5nLW9wdGlvbiBidG4gYnRuLXN0YXJcXFwiIGRhdGEtdmFsPVxcXCI1XFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcImdseXBoaWNvbiBnbHlwaGljb24tc3Rhci1lbXB0eVxcXCI+PC9zcGFuPlxcclxcbiAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgPC9kaXY+XFxyXFxuXFxyXFxuICAgICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wtbWQtMSBoaWdoZXN0LWxhYmVsXFxcIj5cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMuaGlnaGVzdF92YWx1ZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5oaWdoZXN0X3ZhbHVlKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvZGl2PlxcclxcbiAgICA8L2Rpdj5cXHJcXG5cXHJcXG4gICAgPGRpdiBjbGFzcz1cXFwicmF0aW5nLWxhYmVsIGNlbnRlci1ibG9ja1xcXCI+PC9kaXY+XFxyXFxuPC9jZW50ZXI+XCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIiwgaGVscGVyLCBvcHRpb25zLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb247XG5cblxuICBidWZmZXIgKz0gXCI8ZGl2IGlkPVxcXCJyYXRpbmctY29udGFpbmVyXFxcIiBjbGFzcz1cXFwicm93XFxcIj5cXHJcXG4gICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTEyXFxcIj5cXHJcXG4gICAgICAgIDxkaXYgY2xhc3M9XFxcInBhbmVsIHBhbmVsLWthbGl0ZS1yYXRpbmdcXFwiPlxcclxcbiAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInJvdyBwYW5lbC1oZWFkaW5nXFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLW1kLThcXFwiPlxcclxcbiAgICAgICAgICAgICAgICAgICAgPGgxIGNsYXNzPVxcXCJwYW5lbC10aXRsZVxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcIldoYXQgZGlkIHlvdSB0aGluaz9cIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJXaGF0IGRpZCB5b3UgdGhpbms/XCIsIG9wdGlvbnMpKSlcbiAgICArIFwiPC9oMT5cXHJcXG4gICAgICAgICAgICAgICAgICAgIDxzcGFuPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJZb3VyIGZlZWRiYWNrIHdpbGwgaGVscCB1cyBtYWtlIGJldHRlciBjb250ZW50IGZvciBmdXR1cmUgbGVhcm5lcnMhXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiWW91ciBmZWVkYmFjayB3aWxsIGhlbHAgdXMgbWFrZSBiZXR0ZXIgY29udGVudCBmb3IgZnV0dXJlIGxlYXJuZXJzIVwiLCBvcHRpb25zKSkpXG4gICAgKyBcIjwvc3Bhbj5cXHJcXG4gICAgICAgICAgICAgICAgPC9kaXY+XFxyXFxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbC1tZC0yIGNvbC1tZC1vZmZzZXQtMlxcXCI+XFxyXFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJidG4gYnRuLWRhbmdlciByYXRpbmctZGVsZXRlXFxcIj48c3BhbiBjbGFzcz1cXFwiZ2x5cGhpY29uIGdseXBoaWNvbi10cmFzaFxcXCI+PC9zcGFuPiBcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiRGVsZXRlIG15IHJldmlld1wiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIkRlbGV0ZSBteSByZXZpZXdcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L2Rpdj5cXHJcXG4gICAgICAgICAgICAgICAgPC9kaXY+XFxyXFxuICAgICAgICAgICAgPC9kaXY+XFxyXFxuICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwicGFuZWwtYm9keVxcXCI+XFxyXFxuICAgICAgICAgICAgICAgIDxkaXYgaWQ9XFxcInN0YXItY29udGFpbmVyLXF1YWxpdHlcXFwiPlxcclxcbiAgICAgICAgICAgICAgICAgICAgPCEtLXN0YXIuaGFuZGxlYmFycyB3aWxsIGJlIHJlbmRlcmVkIGhlcmUuLS0+XFxyXFxuICAgICAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgICAgICAgICA8ZGl2IGlkPVxcXCJzdGFyLWNvbnRhaW5lci1kaWZmaWN1bHR5XFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgICAgIDwhLS0gc3Rhci1jb250YWluZXItMi4gU2FtZSBkZWFsLiAtLT5cXHJcXG4gICAgICAgICAgICAgICAgPC9kaXY+XFxyXFxuICAgICAgICAgICAgICAgIDxkaXYgaWQ9XFxcInRleHQtY29udGFpbmVyXFxcIj5cXHJcXG4gICAgICAgICAgICAgICAgICAgIDwhLS10ZXh0LWNvbnRhaW5lci4gVXNlcyB0ZXh0LmhhbmRsZWJhcnMuLS0+XFxyXFxuICAgICAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgICAgIDwvZGl2PlxcclxcbiAgICAgICAgPC9kaXY+XFxyXFxuICAgIDwvZGl2PlxcclxcbjwvZGl2PlwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9KTtcbiIsInZhciBfID0gcmVxdWlyZShcInVuZGVyc2NvcmVcIik7XG52YXIgQmFzZVZpZXcgPSByZXF1aXJlKFwiYmFzZS9iYXNldmlld1wiKTtcbnZhciBIYW5kbGViYXJzID0gcmVxdWlyZShcImJhc2UvaGFuZGxlYmFyc1wiKTtcbnZhciBNb2RlbHMgPSByZXF1aXJlKFwiLi9tb2RlbHNcIik7XG52YXIgVmlkZW9Nb2RlbHMgPSByZXF1aXJlKFwidmlkZW8vbW9kZWxzXCIpO1xudmFyICRzY3JpcHQgPSByZXF1aXJlKFwic2NyaXB0anNcIik7XG5cbnZhciBDb250ZW50QmFzZVZpZXcgPSByZXF1aXJlKFwiLi9iYXNldmlld1wiKTtcbnZhciBFeGVyY2lzZU1vZGVscyA9IHJlcXVpcmUoXCJleGVyY2lzZXMvbW9kZWxzXCIpO1xuXG5yZXF1aXJlKFwiLi4vLi4vLi4vY3NzL2Rpc3RyaWJ1dGVkL2NvbnRlbnQubGVzc1wiKTtcblxudmFyIENvbnRlbnRXcmFwcGVyVmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICBldmVudHM6IHtcbiAgICAgICAgXCJjbGljayAuZG93bmxvYWQtbGlua1wiOiBcInNldF9mdWxsX3Byb2dyZXNzXCJcbiAgICB9LFxuXG4gICAgdGVtcGxhdGU6IHJlcXVpcmUoXCIuL2hidGVtcGxhdGVzL2NvbnRlbnQtd3JhcHBlci5oYW5kbGViYXJzXCIpLFxuXG4gICAgaW5pdGlhbGl6ZTogZnVuY3Rpb24ob3B0aW9ucykge1xuXG4gICAgICAgIF8uYmluZEFsbCh0aGlzLCBcInVzZXJfZGF0YV9sb2FkZWRcIiwgXCJzZXRfZnVsbF9wcm9ncmVzc1wiLCBcInJlbmRlclwiLCBcImFkZF9jb250ZW50X3ZpZXdcIiwgXCJzZXR1cF9jb250ZW50X2Vudmlyb25tZW50XCIpO1xuXG4gICAgICAgIHZhciBzZWxmID0gdGhpcztcblxuICAgICAgICAvLyBsb2FkIHRoZSBpbmZvIGFib3V0IHRoZSBjb250ZW50IGl0c2VsZlxuICAgICAgICBpZiAob3B0aW9ucy5raW5kID09IFwiRXhlcmNpc2VcIikge1xuICAgICAgICAgICAgdGhpcy5kYXRhX21vZGVsID0gbmV3IEV4ZXJjaXNlTW9kZWxzLkV4ZXJjaXNlRGF0YU1vZGVsKHtpZDogb3B0aW9ucy5pZCwgY2hhbm5lbDogb3B0aW9ucy5jaGFubmVsfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB0aGlzLmRhdGFfbW9kZWwgPSBuZXcgTW9kZWxzLkNvbnRlbnREYXRhTW9kZWwoe2lkOiBvcHRpb25zLmlkLCBjaGFubmVsOiBvcHRpb25zLmNoYW5uZWx9KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh0aGlzLmRhdGFfbW9kZWwuZ2V0KFwiaWRcIikpIHtcbiAgICAgICAgICAgIHRoaXMuZGF0YV9tb2RlbC5mZXRjaCgpLnRoZW4oZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAgd2luZG93LnN0YXR1c01vZGVsLmxvYWRlZC50aGVuKHNlbGYuc2V0dXBfY29udGVudF9lbnZpcm9ubWVudCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sXG5cbiAgICBzZXR1cF9jb250ZW50X2Vudmlyb25tZW50OiBmdW5jdGlvbigpIHtcblxuICAgICAgICAvLyBUaGlzIGlzIGEgaGFjayB0byBzdXBwb3J0IHRoZSBsZWdhY3kgVmlkZW9Mb2csIHNlcGFyYXRlIGZyb20gb3RoZXIgQ29udGVudExvZ1xuICAgICAgICAvLyBUT0RPLUJMT0NLRVIgKHJ0aWJibGVzKSAwLjE0OiBSZW1vdmUgdGhpc1xuXG4gICAgICAgIGlmICh0aGlzLmRhdGFfbW9kZWwuZ2V0KFwia2luZFwiKSA9PSBcIlZpZGVvXCIpIHtcbiAgICAgICAgICAgIExvZ0NvbGxlY3Rpb24gPSBWaWRlb01vZGVscy5WaWRlb0xvZ0NvbGxlY3Rpb247XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5kYXRhX21vZGVsLmdldChcImtpbmRcIikgPT0gXCJFeGVyY2lzZVwiKSB7XG4gICAgICAgICAgICBMb2dDb2xsZWN0aW9uID0gRXhlcmNpc2VNb2RlbHMuRXhlcmNpc2VMb2dDb2xsZWN0aW9uO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgTG9nQ29sbGVjdGlvbiA9IE1vZGVscy5Db250ZW50TG9nQ29sbGVjdGlvbjtcbiAgICAgICAgfVxuXG4gICAgICAgIHRoaXMubG9nX2NvbGxlY3Rpb24gPSBuZXcgTG9nQ29sbGVjdGlvbihbXSwge2NvbnRlbnRfbW9kZWw6IHRoaXMuZGF0YV9tb2RlbH0pO1xuXG4gICAgICAgIGlmICh3aW5kb3cuc3RhdHVzTW9kZWwuZ2V0KFwiaXNfbG9nZ2VkX2luXCIpKSB7XG5cbiAgICAgICAgICAgIHRoaXMubG9nX2NvbGxlY3Rpb24uZmV0Y2goKS50aGVuKHRoaXMudXNlcl9kYXRhX2xvYWRlZCk7XG5cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHRoaXMudXNlcl9kYXRhX2xvYWRlZCgpO1xuICAgICAgICB9XG5cbiAgICAgICAgdGhpcy5saXN0ZW5Ub09uY2Uod2luZG93LnN0YXR1c01vZGVsLCBcImNoYW5nZTppc19sb2dnZWRfaW5cIiwgdGhpcy5zZXR1cF9jb250ZW50X2Vudmlyb25tZW50KTtcblxuICAgIH0sXG5cbiAgICB1c2VyX2RhdGFfbG9hZGVkOiBmdW5jdGlvbigpIHtcbiAgICAgICAgdGhpcy5sb2dfbW9kZWwgPSB0aGlzLmxvZ19jb2xsZWN0aW9uLmdldF9maXJzdF9sb2dfb3JfbmV3X2xvZygpO1xuICAgICAgICB0aGlzLnJlbmRlcigpO1xuICAgIH0sXG5cbiAgICBzZXRfZnVsbF9wcm9ncmVzczogZnVuY3Rpb24oKSB7XG4gICAgICAgIGlmICh0aGlzLmRhdGFfbW9kZWwuZ2V0KFwia2luZFwiKSA9PT0gXCJEb2N1bWVudFwiICYmICEoXCJQREZKU1wiIGluIHdpbmRvdykpIHtcbiAgICAgICAgICAgIHRoaXMuY29udGVudF92aWV3LnNldF9wcm9ncmVzcygxKTtcbiAgICAgICAgICAgIHRoaXMuY29udGVudF92aWV3LmxvZ19tb2RlbC5zYXZlKCk7XG4gICAgICAgIH1cbiAgICB9LFxuXG4gICAgcmVuZGVyOiBmdW5jdGlvbigpIHtcblxuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUodGhpcy5kYXRhX21vZGVsLmF0dHJpYnV0ZXMpKTtcblxuICAgICAgICAvLyBEbyB0aGlzIHRvIHByZXZlbnQgYnJvd3NlcmlmeSBmcm9tIGJ1bmRsaW5nIHdoYXQgd2Ugd2FudCB0byBiZSBleHRlcm5hbCBkZXBlbmRlbmNpZXMuXG4gICAgICAgIHZhciBleHRlcm5hbCA9IHJlcXVpcmU7XG5cbiAgICAgICAgdmFyIHNlbGYgPSB0aGlzO1xuXG4gICAgICAgIHN3aXRjaCh0aGlzLmRhdGFfbW9kZWwuZ2V0KFwia2luZFwiKSkge1xuXG4gICAgICAgICAgICBjYXNlIFwiQXVkaW9cIjpcbiAgICAgICAgICAgICAgICAkc2NyaXB0KHdpbmRvdy5zZXNzaW9uTW9kZWwuZ2V0KFwiU1RBVElDX1VSTFwiKSArIFwianMvZGlzdHJpYnV0ZWQvYnVuZGxlcy9idW5kbGVfYXVkaW8uanNcIiwgZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5hZGRfY29udGVudF92aWV3KGV4dGVybmFsKFwiYXVkaW9cIikuQXVkaW9QbGF5ZXJWaWV3KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBcIkRvY3VtZW50XCI6XG4gICAgICAgICAgICAgICAgaWYgKFwiUERGSlNcIiBpbiB3aW5kb3cpIHtcbiAgICAgICAgICAgICAgICAgICAgJHNjcmlwdCh3aW5kb3cuc2Vzc2lvbk1vZGVsLmdldChcIlNUQVRJQ19VUkxcIikgKyBcImpzL2Rpc3RyaWJ1dGVkL2J1bmRsZXMvYnVuZGxlX2RvY3VtZW50LmpzXCIsIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZWxmLmFkZF9jb250ZW50X3ZpZXcoZXh0ZXJuYWwoXCJkb2N1bWVudFwiKS5QREZWaWV3ZXJWaWV3KTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5hZGRfY29udGVudF92aWV3KENvbnRlbnRCYXNlVmlldyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGJyZWFrO1xuXG4gICAgICAgICAgICBjYXNlIFwiVmlkZW9cIjpcbiAgICAgICAgICAgICAgICAkc2NyaXB0KHdpbmRvdy5zZXNzaW9uTW9kZWwuZ2V0KFwiU1RBVElDX1VSTFwiKSArIFwianMvZGlzdHJpYnV0ZWQvYnVuZGxlcy9idW5kbGVfdmlkZW8uanNcIiwgZnVuY3Rpb24oKXtcbiAgICAgICAgICAgICAgICAgICAgc2VsZi5hZGRfY29udGVudF92aWV3KGV4dGVybmFsKFwidmlkZW9cIikuVmlkZW9QbGF5ZXJWaWV3KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICAgICAgY2FzZSBcIkV4ZXJjaXNlXCI6XG4gICAgICAgICAgICAgICAgJHNjcmlwdCh3aW5kb3cuc2Vzc2lvbk1vZGVsLmdldChcIlNUQVRJQ19VUkxcIikgKyBcImpzL2Rpc3RyaWJ1dGVkL2J1bmRsZXMvYnVuZGxlX2V4ZXJjaXNlLmpzXCIsIGZ1bmN0aW9uKCl7XG4gICAgICAgICAgICAgICAgICAgIHNlbGYuYWRkX2NvbnRlbnRfdmlldyhleHRlcm5hbChcImV4ZXJjaXNlXCIpLkV4ZXJjaXNlUHJhY3RpY2VWaWV3KTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICBicmVhaztcblxuICAgICAgICB9XG4gICAgfSxcblxuICAgIGFkZF9jb250ZW50X3ZpZXc6IGZ1bmN0aW9uKENvbnRlbnRWaWV3KSB7XG5cbiAgICAgICAgdGhpcy5jb250ZW50X3ZpZXcgPSB0aGlzLmFkZF9zdWJ2aWV3KENvbnRlbnRWaWV3LCB7XG4gICAgICAgICAgICBkYXRhX21vZGVsOiB0aGlzLmRhdGFfbW9kZWwsXG4gICAgICAgICAgICBsb2dfbW9kZWw6IHRoaXMubG9nX21vZGVsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMuY29udGVudF92aWV3LnJlbmRlcigpO1xuXG4gICAgICAgIHRoaXMuJChcIi5jb250ZW50LXBsYXllci1jb250YWluZXJcIikuYXBwZW5kKHRoaXMuY29udGVudF92aWV3LmVsKTtcblxuICAgICAgICB0aGlzLnBvaW50c192aWV3ID0gdGhpcy5hZGRfc3VidmlldyhDb250ZW50UG9pbnRzVmlldywge1xuICAgICAgICAgICAgbW9kZWw6IHRoaXMubG9nX21vZGVsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHRoaXMucG9pbnRzX3ZpZXcucmVuZGVyKCk7XG5cbiAgICAgICAgdGhpcy4kKFwiLnBvaW50cy13cmFwcGVyXCIpLmFwcGVuZCh0aGlzLnBvaW50c192aWV3LmVsKTtcblxuICAgICAgICB0aGlzLmxvZ19tb2RlbC5zZXQoXCJ2aWV3c1wiLCB0aGlzLmxvZ19tb2RlbC5nZXQoXCJ2aWV3c1wiKSArIDEpO1xuICAgIH1cblxufSk7XG5cbnZhciBDb250ZW50UG9pbnRzVmlldyA9IEJhc2VWaWV3LmV4dGVuZCh7XG5cbiAgICB0ZW1wbGF0ZTogcmVxdWlyZShcIi4vaGJ0ZW1wbGF0ZXMvY29udGVudC1wb2ludHMuaGFuZGxlYmFyc1wiKSxcblxuICAgIGluaXRpYWxpemU6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLnN0YXJ0aW5nX3BvaW50cyA9IHRoaXMubW9kZWwuZ2V0KFwicG9pbnRzXCIpIHx8IDA7XG4gICAgICAgIHRoaXMubGlzdGVuVG8odGhpcy5tb2RlbCwgXCJjaGFuZ2VcIiwgdGhpcy5yZW5kZXIpO1xuICAgIH0sXG5cbiAgICByZW5kZXI6IGZ1bmN0aW9uKCkge1xuICAgICAgICB0aGlzLiRlbC5odG1sKHRoaXMudGVtcGxhdGUodGhpcy5tb2RlbC5hdHRyaWJ1dGVzKSk7XG4gICAgICAgIHdpbmRvdy5zdGF0dXNNb2RlbC51cGRhdGVfdG90YWxfcG9pbnRzKHRoaXMubW9kZWwuZ2V0KFwicG9pbnRzXCIpIC0gdGhpcy5zdGFydGluZ19wb2ludHMpO1xuICAgICAgICB0aGlzLnN0YXJ0aW5nX3BvaW50cyA9IHRoaXMubW9kZWwuZ2V0KFwicG9pbnRzXCIpO1xuICAgIH1cbn0pO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgICBDb250ZW50V3JhcHBlclZpZXc6IENvbnRlbnRXcmFwcGVyVmlldyxcbiAgICBDb250ZW50UG9pbnRzVmlldzogQ29udGVudFBvaW50c1ZpZXdcbn07XG4iLCJ2YXIgQ29udGVudE1vZGVscyA9IHJlcXVpcmUoXCJjb250ZW50L21vZGVsc1wiKTtcblxuXG52YXIgVmlkZW9Mb2dNb2RlbCA9IENvbnRlbnRNb2RlbHMuQ29udGVudExvZ01vZGVsLmV4dGVuZCh7XG5cbiAgICB1cmxSb290OiBmdW5jdGlvbigpIHtcbiAgICAgICAgcmV0dXJuIHdpbmRvdy5zZXNzaW9uTW9kZWwuZ2V0KFwiR0VUX1ZJREVPX0xPR1NfVVJMXCIpO1xuICAgIH1cblxufSk7XG5cbnZhciBWaWRlb0xvZ0NvbGxlY3Rpb24gPSBDb250ZW50TW9kZWxzLkNvbnRlbnRMb2dDb2xsZWN0aW9uLmV4dGVuZCh7XG5cbiAgICBtb2RlbDogVmlkZW9Mb2dNb2RlbCxcblxuICAgIG1vZGVsX2lkX2tleTogXCJ2aWRlb19pZFwiXG5cbn0pO1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcblx0VmlkZW9Mb2dNb2RlbDogVmlkZW9Mb2dNb2RlbCxcblx0VmlkZW9Mb2dDb2xsZWN0aW9uOiBWaWRlb0xvZ0NvbGxlY3Rpb25cbn07IiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnMsIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIGVzY2FwZUV4cHJlc3Npb249dGhpcy5lc2NhcGVFeHByZXNzaW9uLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgc2VsZj10aGlzO1xuXG5mdW5jdGlvbiBwcm9ncmFtMShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVxcXCJcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9ICgoc3RhY2sxID0gKGRlcHRoMCAmJiBkZXB0aDAuY29udGVudF91cmxzKSksc3RhY2sxID09IG51bGwgfHwgc3RhY2sxID09PSBmYWxzZSA/IHN0YWNrMSA6IHN0YWNrMS5zdHJlYW0pKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIlxcXCIgY2xhc3M9XFxcImJ0biBidG4tcHJpbWFyeSBkb3dubG9hZC1saW5rIHB1bGwtcmlnaHRcXFwiPlwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJPcGVuIFBERiBSZWFkZXJcIiwgb3B0aW9ucykgOiBoZWxwZXJNaXNzaW5nLmNhbGwoZGVwdGgwLCBcIl9cIiwgXCJPcGVuIFBERiBSZWFkZXJcIiwgb3B0aW9ucykpKVxuICAgICsgXCI8L2E+XFxuICAgICAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTMoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazE7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgPGgzPlxcbiAgICAgICAgICAgICAgICAgICAgICAgIDxzZWxlY3QgY2xhc3M9XFxcImNvbnRlbnQtbGFuZ3VhZ2Utc2VsZWN0b3JcXFwiPlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVycy5lYWNoLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC5hdmFpbGFiaWxpdHkpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW1XaXRoRGVwdGgoNCwgcHJvZ3JhbTQsIGRhdGEsIGRlcHRoMCksZGF0YTpkYXRhfSk7XG4gIGlmKHN0YWNrMSB8fCBzdGFjazEgPT09IDApIHsgYnVmZmVyICs9IHN0YWNrMTsgfVxuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgICAgICA8L3NlbGVjdD5cXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XFxuICAgICAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTQoZGVwdGgwLGRhdGEsZGVwdGgxKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8b3B0aW9uIHZhbHVlPVxcXCJcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoKHN0YWNrMSA9IChkYXRhID09IG51bGwgfHwgZGF0YSA9PT0gZmFsc2UgPyBkYXRhIDogZGF0YS5rZXkpKSx0eXBlb2Ygc3RhY2sxID09PSBmdW5jdGlvblR5cGUgPyBzdGFjazEuYXBwbHkoZGVwdGgwKSA6IHN0YWNrMSkpXG4gICAgKyBcIlxcXCIgXCI7XG4gIHN0YWNrMSA9IChoZWxwZXIgPSBoZWxwZXJzLmlmY29uZCB8fCAoZGVwdGgxICYmIGRlcHRoMS5pZmNvbmQpLG9wdGlvbnM9e2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDUsIHByb2dyYW01LCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKGRhdGEgPT0gbnVsbCB8fCBkYXRhID09PSBmYWxzZSA/IGRhdGEgOiBkYXRhLmtleSksIFwiPT1cIiwgKGRlcHRoMSAmJiBkZXB0aDEuc2VsZWN0ZWRfbGFuZ3VhZ2UpLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsIChkYXRhID09IG51bGwgfHwgZGF0YSA9PT0gZmFsc2UgPyBkYXRhIDogZGF0YS5rZXkpLCBcIj09XCIsIChkZXB0aDEgJiYgZGVwdGgxLnNlbGVjdGVkX2xhbmd1YWdlKSwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiPlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmxhbmd1YWdlX25hbWUpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAubGFuZ3VhZ2VfbmFtZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9vcHRpb24+XFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5mdW5jdGlvbiBwcm9ncmFtNShkZXB0aDAsZGF0YSkge1xuICBcbiAgXG4gIHJldHVybiBcInNlbGVjdGVkXCI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTcoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcIm9yZ2FuaXphdGlvblxcXCI+XCJcbiAgICArIGVzY2FwZUV4cHJlc3Npb24oKGhlbHBlciA9IGhlbHBlcnMuXyB8fCAoZGVwdGgwICYmIGRlcHRoMC5fKSxvcHRpb25zPXtoYXNoOnt9LGRhdGE6ZGF0YX0saGVscGVyID8gaGVscGVyLmNhbGwoZGVwdGgwLCBcImJ5OlwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcImJ5OlwiLCBvcHRpb25zKSkpXG4gICAgKyBcIiBcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMub3JnYW5pemF0aW9uKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLm9yZ2FuaXphdGlvbik7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuXG5mdW5jdGlvbiBwcm9ncmFtOShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbnRlbnQtZGVzY3JpcHRpb25cXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy5kZXNjcmlwdGlvbikgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5kZXNjcmlwdGlvbik7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCI8L2Rpdj5cXG4gICAgICAgICAgICAgICAgICAgIFwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbmZ1bmN0aW9uIHByb2dyYW0xMShkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCIsIHN0YWNrMSwgaGVscGVyLCBvcHRpb25zO1xuICBidWZmZXIgKz0gXCJcXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwicGFuZWwtZm9vdGVyXFxcIj5cXG4gICAgICAgICAgICAgICAgICAgIDxoMz5cXG4gICAgICAgICAgICAgICAgICAgICAgICBcIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiUmVsYXRlZCBjb250ZW50OlwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIlJlbGF0ZWQgY29udGVudDpcIiwgb3B0aW9ucykpKVxuICAgICsgXCJcXG4gICAgICAgICAgICAgICAgICAgIDwvaDM+XFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJyb3dcXFwiPlxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzLmVhY2guY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLnJlbGF0ZWRfY29udGVudCksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxMiwgcHJvZ3JhbTEyLCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XFxuICAgICAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgcmV0dXJuIGJ1ZmZlcjtcbiAgfVxuZnVuY3Rpb24gcHJvZ3JhbTEyKGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJjb2wteHMtNFxcXCI+XFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8YSBocmVmPVxcXCIvbGVhcm4vXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLnBhdGgpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAucGF0aCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXFwiIHRpdGxlPVxcXCJcIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMuZGVzY3JpcHRpb24pIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAuZGVzY3JpcHRpb24pOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiXFxcIiBjbGFzcz1cXFwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1yZWxhdGVkLWNvbnRlbnRcXFwiPlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcInJlbGF0ZWQtY29udGVudC1oZWFkZXJcXFwiPlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8c3BhbiBhcmlhLWhpZGRlbj1cXFwidHJ1ZVxcXCI+PGkgY2xhc3M9XFxcImljb24tXCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLmtpbmQpIHsgc3RhY2sxID0gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KTsgfVxuICBlbHNlIHsgaGVscGVyID0gKGRlcHRoMCAmJiBkZXB0aDAua2luZCk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCJcXFwiPjwvaT48L3NwYW4+XFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVxcXCJzci1vbmx5XFxcIj5cIjtcbiAgaWYgKGhlbHBlciA9IGhlbHBlcnMua2luZCkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5raW5kKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3M9XFxcInJlbGF0ZWQtY29udGVudC10aXRsZVxcXCI+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLnRpdGxlKSB7IHN0YWNrMSA9IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSk7IH1cbiAgZWxzZSB7IGhlbHBlciA9IChkZXB0aDAgJiYgZGVwdGgwLnRpdGxlKTsgc3RhY2sxID0gdHlwZW9mIGhlbHBlciA9PT0gZnVuY3Rpb25UeXBlID8gaGVscGVyLmNhbGwoZGVwdGgwLCB7aGFzaDp7fSxkYXRhOmRhdGF9KSA6IGhlbHBlcjsgfVxuICBidWZmZXIgKz0gZXNjYXBlRXhwcmVzc2lvbihzdGFjazEpXG4gICAgKyBcIjwvc3Bhbj5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJyZWxhdGVkLWNvbnRlbnQtYm9keVxcXCI+XFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxwPlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IChoZWxwZXIgPSBoZWxwZXJzLnRydW5jYXRlIHx8IChkZXB0aDAgJiYgZGVwdGgwLnRydW5jYXRlKSxvcHRpb25zPXtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxMywgcHJvZ3JhbTEzLCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZGVzY3JpcHRpb24pLCAxMDAsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJ0cnVuY2F0ZVwiLCAoZGVwdGgwICYmIGRlcHRoMC5kZXNjcmlwdGlvbiksIDEwMCwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvcD5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L2Rpdj5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvYT5cXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9kaXY+XFxuICAgICAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cbmZ1bmN0aW9uIHByb2dyYW0xMyhkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuZnVuY3Rpb24gcHJvZ3JhbTE1KGRlcHRoMCxkYXRhKSB7XG4gIFxuICB2YXIgYnVmZmVyID0gXCJcIiwgc3RhY2sxLCBoZWxwZXIsIG9wdGlvbnM7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJwYW5lbC1mb290ZXJcXFwiPlxcbiAgICAgICAgICAgICAgICAgICAgPGgzPlxcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKChoZWxwZXIgPSBoZWxwZXJzLl8gfHwgKGRlcHRoMCAmJiBkZXB0aDAuXyksb3B0aW9ucz17aGFzaDp7fSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgXCJUYWdzOlwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiX1wiLCBcIlRhZ3M6XCIsIG9wdGlvbnMpKSlcbiAgICArIFwiXFxuICAgICAgICAgICAgICAgICAgICA8L2gzPlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnMuZWFjaC5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAudGFncyksIHtoYXNoOnt9LGludmVyc2U6c2VsZi5ub29wLGZuOnNlbGYucHJvZ3JhbSgxNiwgcHJvZ3JhbTE2LCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICA8L2Rpdj5cXG4gICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cbmZ1bmN0aW9uIHByb2dyYW0xNihkZXB0aDAsZGF0YSkge1xuICBcbiAgdmFyIGJ1ZmZlciA9IFwiXCI7XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgICAgIDxhIGhyZWY9XFxcIi9zZWFyY2gvP3F1ZXJ5PVwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCh0eXBlb2YgZGVwdGgwID09PSBmdW5jdGlvblR5cGUgPyBkZXB0aDAuYXBwbHkoZGVwdGgwKSA6IGRlcHRoMCkpXG4gICAgKyBcIlxcXCI+XFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzPVxcXCJidG4gYnRuLXRhZ1xcXCI+XFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiXG4gICAgKyBlc2NhcGVFeHByZXNzaW9uKCh0eXBlb2YgZGVwdGgwID09PSBmdW5jdGlvblR5cGUgPyBkZXB0aDAuYXBwbHkoZGVwdGgwKSA6IGRlcHRoMCkpXG4gICAgKyBcIlxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L3NwYW4+XFxuICAgICAgICAgICAgICAgICAgICAgICAgPC9hPlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH1cblxuICBidWZmZXIgKz0gXCI8ZGl2IGNsYXNzPVxcXCJjb250YWluZXJcXFwiPlxcbiAgICA8ZGl2IGNsYXNzPVxcXCJyb3dcXFwiPlxcbiAgICAgICAgPGRpdiBjbGFzcz1cXFwiY29sLXhzLTEyXFxcIj5cXG4gICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJwYW5lbCBwYW5lbC1kZWZhdWx0XFxcIj5cXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwicGFuZWwtaGVhZGluZ1xcXCI+XFxuICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJwdWxsLXJpZ2h0XFxcIj5cXG4gICAgICAgICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJwb2ludHMtd3JhcHBlclxcXCI+PC9kaXY+XFxuICAgICAgICAgICAgICAgICAgICAgICAgXFxuICAgICAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IChoZWxwZXIgPSBoZWxwZXJzLmlmY29uZCB8fCAoZGVwdGgwICYmIGRlcHRoMC5pZmNvbmQpLG9wdGlvbnM9e2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDEsIHByb2dyYW0xLCBkYXRhKSxkYXRhOmRhdGF9LGhlbHBlciA/IGhlbHBlci5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAua2luZCksIFwiPT1cIiwgXCJEb2N1bWVudFwiLCBvcHRpb25zKSA6IGhlbHBlck1pc3NpbmcuY2FsbChkZXB0aDAsIFwiaWZjb25kXCIsIChkZXB0aDAgJiYgZGVwdGgwLmtpbmQpLCBcIj09XCIsIFwiRG9jdW1lbnRcIiwgb3B0aW9ucykpO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwiY2xlYXJcXFwiPjwvZGl2PlxcbiAgICAgICAgICAgICAgICAgICAgPC9kaXY+XFxuXFxuICAgICAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAuZHVic19hdmFpbGFibGUpLCB7aGFzaDp7fSxpbnZlcnNlOnNlbGYubm9vcCxmbjpzZWxmLnByb2dyYW0oMywgcHJvZ3JhbTMsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuXFxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzcz1cXFwidGl0bGVcXFwiPlwiO1xuICBpZiAoaGVscGVyID0gaGVscGVycy50aXRsZSkgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC50aXRsZSk7IHN0YWNrMSA9IHR5cGVvZiBoZWxwZXIgPT09IGZ1bmN0aW9uVHlwZSA/IGhlbHBlci5jYWxsKGRlcHRoMCwge2hhc2g6e30sZGF0YTpkYXRhfSkgOiBoZWxwZXI7IH1cbiAgYnVmZmVyICs9IGVzY2FwZUV4cHJlc3Npb24oc3RhY2sxKVxuICAgICsgXCI8L3NwYW4+XFxuICAgICAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAub3JnYW5pemF0aW9uKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDcsIHByb2dyYW03LCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcbiAgICAgICAgICAgICAgICAgICAgXCI7XG4gIHN0YWNrMSA9IGhlbHBlcnNbJ2lmJ10uY2FsbChkZXB0aDAsIChkZXB0aDAgJiYgZGVwdGgwLmRlc2NyaXB0aW9uKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDksIHByb2dyYW05LCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyBidWZmZXIgKz0gc3RhY2sxOyB9XG4gIGJ1ZmZlciArPSBcIlxcblxcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwiY2xlYXJcXFwiPjwvZGl2PlxcblxcbiAgICAgICAgICAgICAgICAgICAgPGRpdiBjbGFzcz1cXFwiYm9yZGVyd3JhcHBlclxcXCI+PC9kaXY+XFxuICAgICAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzPVxcXCJwYW5lbC1ib2R5XFxcIj5cXG4gICAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3M9XFxcImNvbnRlbnQtcGxheWVyLWNvbnRhaW5lclxcXCI+PC9kaXY+XFxuICAgICAgICAgICAgICAgIDwvZGl2PlxcbiAgICAgICAgICAgICAgICBcIjtcbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAucmVsYXRlZF9jb250ZW50KSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDExLCBwcm9ncmFtMTEsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgICAgIFwiO1xuICBzdGFjazEgPSBoZWxwZXJzWydpZiddLmNhbGwoZGVwdGgwLCAoZGVwdGgwICYmIGRlcHRoMC50YWdzKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDE1LCBwcm9ncmFtMTUsIGRhdGEpLGRhdGE6ZGF0YX0pO1xuICBpZihzdGFjazEgfHwgc3RhY2sxID09PSAwKSB7IGJ1ZmZlciArPSBzdGFjazE7IH1cbiAgYnVmZmVyICs9IFwiXFxuICAgICAgICAgICAgPC9kaXY+XFxuICAgICAgICA8L2Rpdj5cXG4gICAgPC9kaXY+XFxuPC9kaXY+XFxuXCI7XG4gIHJldHVybiBidWZmZXI7XG4gIH0pO1xuIiwiLy8gaGJzZnkgY29tcGlsZWQgSGFuZGxlYmFycyB0ZW1wbGF0ZVxudmFyIEhhbmRsZWJhcnNDb21waWxlciA9IHJlcXVpcmUoJ2hic2Z5L3J1bnRpbWUnKTtcbm1vZHVsZS5leHBvcnRzID0gSGFuZGxlYmFyc0NvbXBpbGVyLnRlbXBsYXRlKGZ1bmN0aW9uIChIYW5kbGViYXJzLGRlcHRoMCxoZWxwZXJzLHBhcnRpYWxzLGRhdGEpIHtcbiAgdGhpcy5jb21waWxlckluZm8gPSBbNCwnPj0gMS4wLjAnXTtcbmhlbHBlcnMgPSB0aGlzLm1lcmdlKGhlbHBlcnMsIEhhbmRsZWJhcnMuaGVscGVycyk7IGRhdGEgPSBkYXRhIHx8IHt9O1xuICB2YXIgc3RhY2sxLCBoZWxwZXJNaXNzaW5nPWhlbHBlcnMuaGVscGVyTWlzc2luZywgZXNjYXBlRXhwcmVzc2lvbj10aGlzLmVzY2FwZUV4cHJlc3Npb24sIGZ1bmN0aW9uVHlwZT1cImZ1bmN0aW9uXCIsIHNlbGY9dGhpcztcblxuZnVuY3Rpb24gcHJvZ3JhbTEoZGVwdGgwLGRhdGEpIHtcbiAgXG4gIHZhciBidWZmZXIgPSBcIlwiLCBzdGFjazEsIGhlbHBlciwgb3B0aW9ucztcbiAgYnVmZmVyICs9IFwiXFxuICAgIDxzcGFuIGNsYXNzPVxcXCJtb3RpdmF0aW9uYWwtZmVhdHVyZSBwb2ludHMtY29udGFpbmVyXFxcIj5cIlxuICAgICsgZXNjYXBlRXhwcmVzc2lvbigoaGVscGVyID0gaGVscGVycy5fIHx8IChkZXB0aDAgJiYgZGVwdGgwLl8pLG9wdGlvbnM9e2hhc2g6e30sZGF0YTpkYXRhfSxoZWxwZXIgPyBoZWxwZXIuY2FsbChkZXB0aDAsIFwiUG9pbnRzXCIsIG9wdGlvbnMpIDogaGVscGVyTWlzc2luZy5jYWxsKGRlcHRoMCwgXCJfXCIsIFwiUG9pbnRzXCIsIG9wdGlvbnMpKSlcbiAgICArIFwiOlxcbiAgICAgICAgPHNwYW4gY2xhc3M9XFxcInBvaW50c1xcXCI+XCI7XG4gIGlmIChoZWxwZXIgPSBoZWxwZXJzLnBvaW50cykgeyBzdGFjazEgPSBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pOyB9XG4gIGVsc2UgeyBoZWxwZXIgPSAoZGVwdGgwICYmIGRlcHRoMC5wb2ludHMpOyBzdGFjazEgPSB0eXBlb2YgaGVscGVyID09PSBmdW5jdGlvblR5cGUgPyBoZWxwZXIuY2FsbChkZXB0aDAsIHtoYXNoOnt9LGRhdGE6ZGF0YX0pIDogaGVscGVyOyB9XG4gIGJ1ZmZlciArPSBlc2NhcGVFeHByZXNzaW9uKHN0YWNrMSlcbiAgICArIFwiPC9zcGFuPjxicj5cXG4gICAgPC9zcGFuPlxcblwiO1xuICByZXR1cm4gYnVmZmVyO1xuICB9XG5cbiAgc3RhY2sxID0gaGVscGVyc1snaWYnXS5jYWxsKGRlcHRoMCwgKGRlcHRoMCAmJiBkZXB0aDAucG9pbnRzKSwge2hhc2g6e30saW52ZXJzZTpzZWxmLm5vb3AsZm46c2VsZi5wcm9ncmFtKDEsIHByb2dyYW0xLCBkYXRhKSxkYXRhOmRhdGF9KTtcbiAgaWYoc3RhY2sxIHx8IHN0YWNrMSA9PT0gMCkgeyByZXR1cm4gc3RhY2sxOyB9XG4gIGVsc2UgeyByZXR1cm4gJyc7IH1cbiAgfSk7XG4iLCIoZnVuY3Rpb24oKSB7IHZhciBoZWFkID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTsgdmFyIHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTsgc3R5bGUudHlwZSA9ICd0ZXh0L2Nzcyc7dmFyIGNzcyA9IFwiLnNpZGViYXItaWNvbntmb250LXNpemU6LjdlbTtwYWRkaW5nLXJpZ2h0OjEwcHg7YmFja2dyb3VuZC1jb2xvcjpyZ2JhKDIxOSwyMTksMjE5LDAuMTkpO2JvcmRlci1yYWRpdXM6M3B4O3BhZGRpbmc6N3B4fS5zaWRlYmFyLWljb24ucGFydGlhbHtvcGFjaXR5Oi40NX0uc2lkZWJhci1pY29uLmNvbXBsZXRle29wYWNpdHk6LjE1fS5zaWRlYmFyLXRpdGxlLmNvbXBsZXRle29wYWNpdHk6LjQ1fS5zaWRlYmFyLXBhbmVsey13ZWJraXQtdHJhbnNmb3JtOnRyYW5zbGF0ZVooMCk7YmFja2dyb3VuZDojNWFhNjg1O3otaW5kZXg6OTk5OTtwb3NpdGlvbjpmaXhlZDtoZWlnaHQ6MTAwJTtib3JkZXItcmlnaHQ6MXB4IHNvbGlkIHJnYmEoMCwwLDAsMC4zKTt0b3A6MDtib3R0b206MDtmb250LXNpemU6MTAwJX1kaXYuc2lkZWJhci1mYWRle3Bvc2l0aW9uOmFic29sdXRlO2xlZnQ6MDt0b3A6MDtiYWNrZ3JvdW5kLWNvbG9yOmJsYWNrOy1tb3otb3BhY2l0eTouNztvcGFjaXR5Oi43O2ZpbHRlcjphbHBoYShvcGFjaXR5PTcwKTt3aWR0aDoxMDAlO2hlaWdodDoxMDAlO3otaW5kZXg6OTk5OH0uc2lkZWJhci1wYW5lbCB1bHtsaXN0LXN0eWxlLXR5cGU6bm9uZTttYXJnaW4tbGVmdDotNDBweH0uc2lkZWJhci1wYW5lbCBsaXtib3JkZXItYm90dG9tOjFweCBzb2xpZCByZ2JhKDAsMCwwLDAuMyl9LnNpZGViYXItcGFuZWwgLnNpZGViYXItZW50cnl7ZGlzcGxheTpibG9jaztwYWRkaW5nOjEuMWVtIDFlbTtmb250LXNpemU6MS4yZW19Lm1pc3Npbmd7b3BhY2l0eTouNDtiYWNrZ3JvdW5kOiM5M2JmYWN9LnNpZGViYXItcGFuZWwgYTpsaW5rLC5zaWRlYmFyLXBhbmVsIGE6dmlzaXRlZHtjb2xvcjojZmZmO2Rpc3BsYXk6YmxvY2s7bWFyZ2luOjNweCAzcHggM3B4IDB9LnNpZGViYXItcGFuZWwgLmFjdGl2ZS1lbnRyeXtiYWNrZ3JvdW5kLWNvbG9yOnJnYmEoMCwwLDAsMC4zKX0uc2lkZWJhci1kaXZpZGVye2NvbG9yOiNiY2I7Zm9udC13ZWlnaHQ6Ym9sZGVyO2JhY2tncm91bmQ6cmdiYSgxMTYsMTE2LDExNiwwLjUpfS5zaWRlYmFyLXRhYnt6LWluZGV4OjEwMDAwO3Bvc2l0aW9uOmZpeGVkO2xlZnQ6MDt0b3A6NDAlO2JhY2tncm91bmQ6IzVhYTY4NTtjb2xvcjojZmZmO2ZvbnQtd2VpZ2h0OmJvbGQ7Zm9udC1zaXplOjEuOWVtO3BhZGRpbmc6MzBweCAxMHB4O3BhZGRpbmctbGVmdDoxNHB4O2JvcmRlci13aWR0aDoxcHggMXB4IDFweCAwO2JvcmRlci10b3AtcmlnaHQtcmFkaXVzOjVweDtib3JkZXItYm90dG9tLXJpZ2h0LXJhZGl1czo1cHg7Y3Vyc29yOnBvaW50ZXI7Ym94LXNoYWRvdzppbnNldCAzcHggMCA4cHggcmdiYSgwLDAsMCwwLjMpfS5zaWRlYmFyLXRhYjpob3ZlcntwYWRkaW5nLWxlZnQ6MjBweH0uc2lkZWJhci10YWIgYXtkaXNwbGF5OmJsb2NrO3RleHQtZGVjb3JhdGlvbjpub25lfS5zaWRlYmFyLW5hdi1jb250YWluZXIgLnRpdGxle2Rpc3BsYXk6YmxvY2s7ZmxvYXQ6bGVmdDt3aWR0aDoxNjBweDtwYWRkaW5nLWxlZnQ6MjZweDtwYWRkaW5nLXRvcDoyMHB4O3BhZGRpbmctYm90dG9tOjIwcHg7Ym9yZGVyLWxlZnQ6MnB4IHNvbGlkICM1ODc0NDg7Zm9udC1zaXplOjJlbTtmb250LXdlaWdodDpib2xkO2NvbG9yOiNjY2N9LnNpZGViYXItYmFja3toZWlnaHQ6MTAwJTt3aWR0aDoyZW07dGV4dC1hbGlnbjpjZW50ZXI7Y29sb3I6I2ZmZjtiYWNrZ3JvdW5kLWNvbG9yOiM0Njc0NzE7Zm9udC1zaXplOjEuNWVtO2JvcmRlci1yaWdodDoxcHggc29saWQgcmdiYSgwLDAsMCwwLjMpO3Bvc2l0aW9uOmFic29sdXRlO3otaW5kZXg6MTAwMDB9LnNpZGViYXItYmFjayBidXR0b257aGVpZ2h0OjNlbTtwYWRkaW5nOjA7d2lkdGg6MS44ZW07dG9wOjQwJX0uc2lkZWJhci1iYWNrLWhvdmVye2JhY2tncm91bmQtY29sb3I6IzNkNjY2MyAhaW1wb3J0YW50fS50b3BpYy1jb250YWluZXItaW5uZXJ7ZmxvYXQ6bGVmdDt3aWR0aDoyMDBweDtib3JkZXItcmlnaHQ6MXB4IHNvbGlkIHJnYmEoMCwwLDAsMC4zKX0udG9waWMtY29udGFpbmVyLWlubmVyOmxhc3QtY2hpbGR7d2lkdGg6NDAwcHh9LnRvcGljLWNvbnRhaW5lci1pbm5lciAuc2lkZWJhci10b3BpYy1kZXNjcmlwdGlvbntkaXNwbGF5Om5vbmU7Zm9udC1zaXplOi45ZW07bWFyZ2luLXRvcDoxNXB4fS50b3BpYy1jb250YWluZXItaW5uZXI6bGFzdC1jaGlsZCAuc2lkZWJhci1kZXNjcmlwdGlvbntkaXNwbGF5OmJsb2NrO2xpbmUtaGVpZ2h0OjEuMWVtO21hcmdpbi1ib3R0b206LTEwcHg7cGFkZGluZy10b3A6MTBweDtjb2xvcjojYWRkM2MyO3dvcmQtd3JhcDpicmVhay13b3JkfS50b3BpYy1jb250YWluZXItaW5uZXI6bGFzdC1jaGlsZCAuc2lkZWJhci1vcmdhbml6YXRpb257ZGlzcGxheTpibG9jaztsaW5lLWhlaWdodDoxLjFlbTttYXJnaW4tdG9wOi03cHg7Y29sb3I6I2FhYWNhYTt3b3JkLXdyYXA6YnJlYWstd29yZH0udG9waWMtY29udGFpbmVyLWlubmVyOmxhc3QtY2hpbGQgLnNpZGViYXItc3BhY2UtaG9sZGVye2Rpc3BsYXk6YmxvY2s7bGluZS1oZWlnaHQ6MS4xZW07bWFyZ2luLXRvcDotMTJweDtjb2xvcjojYTNjY2EzO3dvcmQtd3JhcDpicmVhay13b3JkfS5zaWRlYmFyLWVudHJ5LWhlYWRlcntkaXNwbGF5OnRhYmxlO21heC1oZWlnaHQ6Mi41ZW07bWFyZ2luLWJvdHRvbTotMTBweDttYXJnaW4tdG9wOi0xMHB4fS50b3BpYy1jb250YWluZXItaW5uZXI6bGFzdC1jaGlsZCAuc2lkZWJhci1lbnRyeS1oZWFkZXJ7ZGlzcGxheTp0YWJsZTttYXJnaW4tYm90dG9tOjEycHh9LnNpZGViYXItZW50cnktaGVhZGVyPi5zaWRlYmFyLWljb257aGVpZ2h0OjEwMCU7bWFyZ2luLXRvcDoycHh9LnNpZGViYXItZW50cnktaGVhZGVyPi5zaWRlYmFyLXRpdGxle2xpbmUtaGVpZ2h0OjFlbTtkaXNwbGF5OnRhYmxlLWNlbGw7dmVydGljYWwtYWxpZ246bWlkZGxlO3doaXRlLXNwYWNlOmluaGVyaXQ7dGV4dC1vdmVyZmxvdzppbmhlcml0O3BhZGRpbmctbGVmdDo4cHg7cGFkZGluZy10b3A6MDtwYWRkaW5nLWJvdHRvbTowfS50b3BpYy1jb250YWluZXItaW5uZXI6bGFzdC1jaGlsZCAuc2lkZWJhci1lbnRyeS1oZWFkZXI+LnNpZGViYXItdGl0bGV7ZGlzcGxheTp0YWJsZS1jZWxsO3ZlcnRpY2FsLWFsaWduOm1pZGRsZTt3aGl0ZS1zcGFjZTppbmhlcml0O3RleHQtb3ZlcmZsb3c6aW5oZXJpdDtwYWRkaW5nLXRvcDowO3BhZGRpbmctYm90dG9tOjB9LnRvcGljLWNvbnRhaW5lci1pbm5lcjpsYXN0LWNoaWxkIC5zaWRlYmFyLWVudHJ5LWhlYWRlcj4uc2lkZWJhci1pY29ue2hlaWdodDoxMDAlO21hcmdpbi10b3A6MnB4O2Rpc3BsYXk6dGFibGUtY2VsbDt2ZXJ0aWNhbC1hbGlnbjptaWRkbGV9QG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjc2OHB4KXsuc2lkZWJhci10YWJ7dG9wOjU1cHg7aGVpZ2h0OjJlbTtwYWRkaW5nOjlweH19QG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjcyMHB4KXsuc2lkZWJhci1wYW5lbHtmb250LXNpemU6ODUlfS50b3BpYy1jb250YWluZXItaW5uZXI6bGFzdC1jaGlsZHt3aWR0aDozMDBweH19QG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOjcyMHB4KXsuc2lkZWJhci1wYW5lbHtmb250LXNpemU6OTAlfS50b3BpYy1jb250YWluZXItaW5uZXI6bGFzdC1jaGlsZHt3aWR0aDozMDBweH19QG1lZGlhIG9ubHkgc2NyZWVuIGFuZCAobWluLXdpZHRoOjEwMDBweCl7LnNpZGViYXItcGFuZWx7Zm9udC1zaXplOjEwMCV9LnRvcGljLWNvbnRhaW5lci1pbm5lcjpsYXN0LWNoaWxke3dpZHRoOjQwMHB4fX1AbWVkaWEgb25seSBzY3JlZW4gYW5kIChtaW4td2lkdGg6MTMwMHB4KXsuc2lkZWJhci1wYW5lbHtmb250LXNpemU6MTA1JX0udG9waWMtY29udGFpbmVyLWlubmVyOmxhc3QtY2hpbGR7d2lkdGg6NDAwcHh9fVwiO2lmIChzdHlsZS5zdHlsZVNoZWV0KXsgc3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gY3NzOyB9IGVsc2UgeyBzdHlsZS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpKTsgfSBoZWFkLmFwcGVuZENoaWxkKHN0eWxlKTt9KCkpIiwiKGZ1bmN0aW9uKCkgeyB2YXIgaGVhZCA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlUYWdOYW1lKCdoZWFkJylbMF07IHZhciBzdHlsZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3N0eWxlJyk7IHN0eWxlLnR5cGUgPSAndGV4dC9jc3MnO3ZhciBjc3MgPSBcIi5jb250ZW50LXdyYXBwZXJ7Ym9yZGVyOjJweCBzb2xpZCAjZjBmMGYwO2JvcmRlci1yYWRpdXM6NXB4O3BhZGRpbmc6MjBweDtiYWNrZ3JvdW5kLWNvbG9yOiNmOGY4Zjh9LnBvaW50cy13cmFwcGVye2ZvbnQtc2l6ZToyMHB4O21hcmdpbi1ib3R0b206MTBweH0uZG93bmxvYWQtbGlua3ttYXJnaW4tYm90dG9tOjEwcHh9LnBhbmVsLWhlYWRpbmctcmlnaHQtY29sdW1ue2Zsb2F0OnJpZ2h0O3RleHQtYWxpZ246cmlnaHR9LnBvaW50cy13cmFwcGVyIHNwYW4ucG9pbnRzLWNvbnRhaW5lcnttYXJnaW46NXB4IDA7ZmxvYXQ6cmlnaHQ7YmFja2dyb3VuZC1jb2xvcjp3aGl0ZTtib3JkZXI6MnB4IHNvbGlkIHJnYmEoMjU1LDI1NSwyNTUsMC41KTtwb3NpdGlvbjpyZWxhdGl2ZTtjb2xvcjojNzdiMDVkO2ZvbnQtd2VpZ2h0OjQwMDtib3JkZXItcmFkaXVzOjRweH0uYnRuLmJ0bi1wcmltYXJ5LmRvd25sb2FkLWxpbmsucHVsbC1yaWdodHtmb250LXNpemU6MjBweDtmb250LXdlaWdodDo4MDA7cGFkZGluZzoxNXB4O21hcmdpbjoxNXB4O2NvbG9yOndoaXRlO2JhY2tncm91bmQtY29sb3I6IzVhYTY4NTtib3JkZXI6MnB4IHNvbGlkICM1YWE2ODV9LmJ0bi5idG4tcHJpbWFyeS5kb3dubG9hZC1saW5rLnB1bGwtcmlnaHQ6aG92ZXJ7YmFja2dyb3VuZC1jb2xvcjp3aGl0ZTtjb2xvcjojNzdiMDVkO2JvcmRlcjoycHggc29saWQgd2hpdGV9Lm9yZ2FuaXphdGlvbntkaXNwbGF5OmJsb2NrO21hcmdpbi10b3A6LTNweDttYXJnaW4tYm90dG9tOjVweDtjb2xvcjojNmQ3MjZiO3dvcmQtd3JhcDpicmVhay13b3JkO2ZvbnQtc2l6ZToyMHB4fS5idG4tcmVsYXRlZC1jb250ZW50e3RleHQtYWxpZ246bGVmdDt3aGl0ZS1zcGFjZTpub3JtYWw7YmFja2dyb3VuZC1jb2xvcjojOGRjNjNmO2JvcmRlci1jb2xvcjojOGRjNjNmfS5idG4tcmVsYXRlZC1jb250ZW50OmhvdmVye2JhY2tncm91bmQtY29sb3I6IzVhYTY4NTtib3JkZXItY29sb3I6IzVhYTY4NX0ucmVsYXRlZC1jb250ZW50LWhlYWRlcntmb250LXNpemU6MTRweDtwYWRkaW5nLWJvdHRvbTo1cHh9LnJlbGF0ZWQtY29udGVudC10aXRsZXtmb250LXdlaWdodDo0MDA7Zm9udC1zaXplOjEuMmVtO21hcmdpbi1sZWZ0OjEwcHg7cG9zaXRpb246cmVsYXRpdmU7dG9wOjVweH0ucGFuZWwtZm9vdGVyIGgze2NvbG9yOiM2ZDcyNmI7bWFyZ2luLXRvcDowO2ZvbnQtc2l6ZToyMHB4O2ZvbnQtd2VpZ2h0OjQwMH0uYnRuLXRhZ3tmb250LXNpemU6MS4yZW07Zm9udC13ZWlnaHQ6NDAwO2JhY2tncm91bmQtY29sb3I6IzhkYzYzZjtib3JkZXItY29sb3I6IzhkYzYzZjtjb2xvcjp3aGl0ZX0uYnRuLXRhZzpob3ZlcntiYWNrZ3JvdW5kLWNvbG9yOiM1YWE2ODU7Ym9yZGVyLWNvbG9yOiM1YWE2ODU7Y29sb3I6d2hpdGV9XCI7aWYgKHN0eWxlLnN0eWxlU2hlZXQpeyBzdHlsZS5zdHlsZVNoZWV0LmNzc1RleHQgPSBjc3M7IH0gZWxzZSB7IHN0eWxlLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGNzcykpOyB9IGhlYWQuYXBwZW5kQ2hpbGQoc3R5bGUpO30oKSkiLCIoZnVuY3Rpb24oKSB7IHZhciBoZWFkID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKVswXTsgdmFyIHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTsgc3R5bGUudHlwZSA9ICd0ZXh0L2Nzcyc7dmFyIGNzcyA9IFwiLnBhbmVsLWthbGl0ZS1yYXRpbmd7Ym9yZGVyLXN0eWxlOnNvbGlkO2JvcmRlci1jb2xvcjpncmV5O2JvcmRlci13aWR0aDoxcHg7cGFkZGluZzoxZW19LnBhbmVsLWthbGl0ZS1yYXRpbmcgLnBhbmVsLWhlYWRpbmd7Ym9yZGVyLWJvdHRvbS1zdHlsZTpzb2xpZDtib3JkZXItYm90dG9tLWNvbG9yOmJsYWNrO2JvcmRlci1ib3R0b20tcHg6NHB4fS5wYW5lbC1rYWxpdGUtcmF0aW5nIC5wYW5lbC1oZWFkaW5nIC5wYW5lbC10aXRsZXtmb250LXNpemU6MmVtfS5wYW5lbC1rYWxpdGUtcmF0aW5nIC5wYW5lbC1ib2R5e2JhY2tncm91bmQ6aW5oZXJpdH0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlcntwYWRkaW5nLXRvcDouNWVtO21hcmdpbjowIGF1dG99LnN0YXItcmF0aW5nLWlubmVyLXdyYXBwZXIgLmxvd2VzdC1sYWJlbCwuc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAuaGlnaGVzdC1sYWJlbHtwYWRkaW5nLXRvcDoxLjhlbX0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAucmF0aW5nLXJvdz5kaXZ7cGFkZGluZy1sZWZ0OjA7cGFkZGluZy1yaWdodDowfS5zdGFyLXJhdGluZy1pbm5lci13cmFwcGVyIC5idG4tc3Rhcntmb250LXNpemU6M2VtO2JvcmRlci1zdHlsZTpzb2xpZDtib3JkZXItd2lkdGg6MXB4O2JvcmRlci1jb2xvcjpibGFja30uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAuYnRuLXN0YXIgLmdseXBoaWNvbi1zdGFyLWVtcHR5e3RvcDo1cHg7bGVmdDoycHh9LnN0YXItcmF0aW5nLWlubmVyLXdyYXBwZXIgLmJ0bi1zdGFye2JhY2tncm91bmQ6I2ZmZn0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAuYnRuLXN0YXI6YWN0aXZle2JhY2tncm91bmQ6I2ZmNn0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAuYnRuLXN0YXIuYWN0aXZhdGVke2JhY2tncm91bmQ6I2M2MH0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAuYnRuLXN0YXIuYWN0aXZhdGVkOmFjdGl2ZXtiYWNrZ3JvdW5kOiM2MzB9LnN0YXItcmF0aW5nLWlubmVyLXdyYXBwZXIgLmJ0bi1zdGFyOmhvdmVye2JhY2tncm91bmQ6I2VlZX0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAuYnRuLXN0YXIuYWN0aXZhdGVkOmhvdmVye2JhY2tncm91bmQ6I2I1MH0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAuc3Rhci10aXRsZS1sYWJlbHtiYWNrZ3JvdW5kOmluaGVyaXQ7Y29sb3I6aW5oZXJpdH0uc3Rhci1yYXRpbmctaW5uZXItd3JhcHBlciAucmF0aW5nLWxhYmVse2hlaWdodDoxZW07Zm9udC1zaXplOjFlbX0jdGV4dC1jb250YWluZXIgLnJhdGluZy10ZXh0LWZlZWRiYWNre21heC13aWR0aDo2MCV9I3RleHQtY29udGFpbmVyIC50ZXh0LWZlZWRiYWNrLWxhYmVse3BhZGRpbmctbGVmdDowfVwiO2lmIChzdHlsZS5zdHlsZVNoZWV0KXsgc3R5bGUuc3R5bGVTaGVldC5jc3NUZXh0ID0gY3NzOyB9IGVsc2UgeyBzdHlsZS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpKTsgfSBoZWFkLmFwcGVuZENoaWxkKHN0eWxlKTt9KCkpIl19
