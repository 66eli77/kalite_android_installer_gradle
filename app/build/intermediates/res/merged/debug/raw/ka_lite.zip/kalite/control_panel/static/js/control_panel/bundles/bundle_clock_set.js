require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"clock_set":[function(require,module,exports){
var $ = require("base/jQuery");
var api = require("utils/api");

$(function() {
    $('#time_select').timepicker({
        disableFocus: true,
        showMeridian: false,
        minuteStep: 1
        });
    $('#date_select').datepicker({
        dateFormat: "dd-mm-yy",
        altField: "#standard-date",
        altFormat: "yy-mm-dd"
    });

    $("#date_select").datepicker('setDate', new Date());

    $('#set_time').click(
        function () {
            var data = {
                date_time: $('#standard-date').val() + " " + $('#time_select').val()
            };
            api.doRequest(TIME_SET_URL, data);
        });
});
},{"base/jQuery":45,"utils/api":124}]},{},["clock_set"])
//# sourceMappingURL=data:application/json;charset:utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm5vZGVfbW9kdWxlcy9mYWN0b3ItYnVuZGxlL25vZGVfbW9kdWxlcy9icm93c2VyLXBhY2svX3ByZWx1ZGUuanMiLCJrYWxpdGUvY29udHJvbF9wYW5lbC9zdGF0aWMvanMvY29udHJvbF9wYW5lbC9idW5kbGVfbW9kdWxlcy9jbG9ja19zZXQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsImZpbGUiOiJnZW5lcmF0ZWQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlc0NvbnRlbnQiOlsiKGZ1bmN0aW9uIGUodCxuLHIpe2Z1bmN0aW9uIHMobyx1KXtpZighbltvXSl7aWYoIXRbb10pe3ZhciBhPXR5cGVvZiByZXF1aXJlPT1cImZ1bmN0aW9uXCImJnJlcXVpcmU7aWYoIXUmJmEpcmV0dXJuIGEobywhMCk7aWYoaSlyZXR1cm4gaShvLCEwKTt2YXIgZj1uZXcgRXJyb3IoXCJDYW5ub3QgZmluZCBtb2R1bGUgJ1wiK28rXCInXCIpO3Rocm93IGYuY29kZT1cIk1PRFVMRV9OT1RfRk9VTkRcIixmfXZhciBsPW5bb109e2V4cG9ydHM6e319O3Rbb11bMF0uY2FsbChsLmV4cG9ydHMsZnVuY3Rpb24oZSl7dmFyIG49dFtvXVsxXVtlXTtyZXR1cm4gcyhuP246ZSl9LGwsbC5leHBvcnRzLGUsdCxuLHIpfXJldHVybiBuW29dLmV4cG9ydHN9dmFyIGk9dHlwZW9mIHJlcXVpcmU9PVwiZnVuY3Rpb25cIiYmcmVxdWlyZTtmb3IodmFyIG89MDtvPHIubGVuZ3RoO28rKylzKHJbb10pO3JldHVybiBzfSkiLCJ2YXIgJCA9IHJlcXVpcmUoXCJiYXNlL2pRdWVyeVwiKTtcbnZhciBhcGkgPSByZXF1aXJlKFwidXRpbHMvYXBpXCIpO1xuXG4kKGZ1bmN0aW9uKCkge1xuICAgICQoJyN0aW1lX3NlbGVjdCcpLnRpbWVwaWNrZXIoe1xuICAgICAgICBkaXNhYmxlRm9jdXM6IHRydWUsXG4gICAgICAgIHNob3dNZXJpZGlhbjogZmFsc2UsXG4gICAgICAgIG1pbnV0ZVN0ZXA6IDFcbiAgICAgICAgfSk7XG4gICAgJCgnI2RhdGVfc2VsZWN0JykuZGF0ZXBpY2tlcih7XG4gICAgICAgIGRhdGVGb3JtYXQ6IFwiZGQtbW0teXlcIixcbiAgICAgICAgYWx0RmllbGQ6IFwiI3N0YW5kYXJkLWRhdGVcIixcbiAgICAgICAgYWx0Rm9ybWF0OiBcInl5LW1tLWRkXCJcbiAgICB9KTtcblxuICAgICQoXCIjZGF0ZV9zZWxlY3RcIikuZGF0ZXBpY2tlcignc2V0RGF0ZScsIG5ldyBEYXRlKCkpO1xuXG4gICAgJCgnI3NldF90aW1lJykuY2xpY2soXG4gICAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBkYXRhID0ge1xuICAgICAgICAgICAgICAgIGRhdGVfdGltZTogJCgnI3N0YW5kYXJkLWRhdGUnKS52YWwoKSArIFwiIFwiICsgJCgnI3RpbWVfc2VsZWN0JykudmFsKClcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBhcGkuZG9SZXF1ZXN0KFRJTUVfU0VUX1VSTCwgZGF0YSk7XG4gICAgICAgIH0pO1xufSk7Il19
